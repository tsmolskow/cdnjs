﻿#

Import-Module Sharegate

$csvFile = "D:\Rupesh\Scripts\SharegateMigrationReports\Connect sites\input.csv" #Location Specific
$table = Import-Csv $csvFile -Delimiter ","
$fileName = "SourceConnectionLogs"
$filepath = "D:\Rupesh\Scripts\SharegateMigrationReports\Connect sites\"+$fileName+".txt" #Location Specific
$i = 1

if(Test-Path $filepath){
                
                $fileName = $fileName + "_" + [int]$i
                $filepath = ".\"+$fileName+".txt"
} 

New-Item -Path $filepath -ItemType file -Force

$cred = Get-Credential -Message "Credentials for Sites.."
$count =0

foreach ($row in $table) {
    try{
        Connect-Site -Url $row.SourceUrl -Username $cred.UserName -Password $cred.Password -AddToExplorer
        $count++
        $msg = "Site number : "+ $count + " with URL: " +$row.SourceUrl+ " connected"
        Write-Host $msg
        Add-Content -Path $filepath -Value $msg

    }
    catch
    {
        $logMsg = $cred.UserName +" does not have SCA rights to the site : "+ $row.SourceUrl + " Or user inserted incorrect credentials."
        Add-Content -Path $filepath -Value $logMsg
        Add-Content -Path $filepath -Value $_.Exception
    }
}