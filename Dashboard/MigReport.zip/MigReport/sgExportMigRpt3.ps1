﻿#sgExportMigRpt
#As of: 5/3/2021
#Notes: Dynamic file name, Password sent in clear, Needs for each loop to get all lists\libraries,
#Read from a SP List, Update to a SP List?

#SPO Login as Admin Without Prompt

cls

#Login and Password
$login = "EYTestAdmin@M365B742352.onmicrosoft.com"
$pwd = "Cognizantadmin123!"
$pwd = ConvertTo-SecureString $pwd -AsPlainText -Force

#Credentials
$credentials = New-Object -TypeName System.Management.Automation.PSCredential -argumentlist $login,$pwd

#Connect
Connect-SPOService -url "https://m365b742352-admin.sharepoint.com" -Credential $credentials

cls

#Import ShareGate Modules
Import-Module Sharegate	

#CSV List Input File
$csvFile = "F:\MigrationReport\Lists.csv"
#$csvFile = "F:\MigrationReport\Lists1.csv"
$errorLog = "F:\MigrationReport\errorLog.csv"
$table = Import-Csv $csvFile -Delimiter ","

#Set Variables
$srcSiteURL = "https://m365b742352.sharepoint.com/MigrateSubsite"
#$srcSiteURL = "https://m365b742352.sharepoint.com/sites/TestMigration0329"
$dstSiteURL = "http://spfarm.eastus2.cloudapp.azure.com/sites/TestMigration3/TM3Subsite1"

$srcSiteName = $srcSiteURL.Split("/")[-1]
$dstSiteName = $dstSiteURL.Split("/")[-1]

#Logon 
$userName1 = "EYTestAdmin@M365B742352.onmicrosoft.com"
$userName2 = "CONTOSO\migadmin"
$passWord1 = ConvertTo-SecureString "Cognizantadmin123!" -AsPlainText -Force
$passWord2 = ConvertTo-SecureString "Cognizantadmin123!" -AsPlainText -Force

#Setup Credentials to connect
$Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($userName1,(ConvertTo-SecureString $passWord1 -AsPlainText -Force))

#Set Log Report Path and File
$filePath = "F:\MigrationReport\s" + $srcSiteName + "_d" + $dstSiteName + "_dt" + $(get-date -f dd_MM_yyyy) +".xlsx"

#Connect Source Site
$srcSite = Connect-Site -Url $srcSiteURL -Username $userName1 -Password $passWord1

#Connect Destination Site
$dstSite = Connect-Site -Url $dstSiteURL -Username $userName2 -Password $passWord2

Write-Host "---- Looping Thru Lists ----"
foreach ($row in $table)
{
	try
    {
        $srcList = Get-List -Name $row.SourceList -Site $srcSite
        Write-Host "srcList " $row.SourceList
    }
    catch
    {
        $ErrorMessage = $_.Exception.Message
        Write-Host "Error has occurred:" $ErrorMessage
        $srcList + " " + $ErrorMessage + "`n" | Out-File -FilePath $errorLog -Append       
    }

    try
    {
	    $dstList = Get-List -Name $row.DestinationList -Site $dstSite
        Write-Host "dstList " $row.DestinationList
    }
    catch
    {
        $ErrorMessage = $_.Exception.Message
        Write-Host "Error has occurred:" $ErrorMessage
        $dstList + " " + $ErrorMessage + "`n" | Out-File -FilePath $errorLog -Append       
    }

    try
    {
        $copysettings = New-CopySettings -OnContentItemExists IncrementalUpdate
        $result = Copy-Content -SourceList $srcList -DestinationList $dstList -CopySettings $copysettings
    }
    catch
    {
        $ErrorMessage = $_.Exception.Message
        Write-Host "Error has occurred:" $ErrorMessage
        $ErrorMessage + "`n" | Out-File -FilePath $errorLog -Append       
    }
}

#Migrate List (1 List - For Testing)
#$srcList = Get-List -Name "TestLib1" -Site $srcSite
#$dstList = Get-List -Name "TestLib1" -Site $dstSite

#Copy All - Full Migration
#$result = Copy-List -All -SourceSite $srcSite -DestinationSite $dstSite

#Copy All - Incremental Migration
#$copysettings = New-CopySettings -OnContentItemExists IncrementalUpdate
#$result = Copy-Content -SourceList $srcList -DestinationList $dstList -CopySettings $copysettings

#Export Migration Report
Export-Report $result -Path $filePath -Overwrite
