Clear-Host| Remove-Module -Force

#Load XML Config File
$scriptRoot = Split-Path $MyInvocation.MyCommand.Path -Parent
$parentRoot = (Get-Item $scriptRoot).Parent.FullName
$configfolder = Join-Path $parentRoot.ToLower().Replace('\cts\','\ey\') "CTS-Mig-0Settings"
$xmlConfigPath = Join-Path $configfolder -ChildPath  "MigrationSettings.xml"
$configXmlfile = [xml]$(Get-Content $xmlConfigPath)

#Load Module files
$modulesPath = Join-Path $scriptRoot $configXmlfile.ConfigSettings.ModulesFile
Import-Module -Name $modulesPath

#Fetch SQL Credentials from Azure KeyVault
$MyAzurePath = $configXmlfile.ConfigSettings.AzureDirectory
Import-Module -Name "$MyAzurePath\Az.Accounts\1.9.3\Az.Accounts.psd1"
import-module -name "$MyAzurePath\Az.KeyVault\2.1.0\Az.KeyVault.psd1"
$azAppId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.ApplicationId
$azTenantId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.TenantId
$azCertificates = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.CertificateThumbprint
$azProdVault = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.ProdVaultName
$azOrchDbUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.OrchestrationUserId
$azOrchDbPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.OrchestrationPassword
$azQuestVault = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.QuestVaultName
$azQuestDbUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.QuestUserId
$azQuestDbPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.QuestPassword

##---------------- Connect and Fetching the MigrationOrchestration DB and Quest DB cretentials from Azure Key Vault -----------------------------##
Connect-AzAccount -ServicePrincipal -ApplicationId $azAppId -Tenant $azTenantId -CertificateThumbprint $azCertificates
$orchestratorSQLID = (Get-AzKeyVaultSecret -vaultName $azProdVault -name $azOrchDbUserId).SecretValueText
$orchestratorSQLPasswordText = (Get-AzKeyVaultSecret -vaultName $azProdVault -name $azOrchDbPassword).SecretValueText
$orchestratorSQLPassword = $orchestratorSQLPasswordText | ConvertTo-SecureString -AsPlainText -Force

$QuestSQLID = (Get-AzKeyVaultSecret -vaultName $azProdVault -name $azQuestDbUserId).SecretValueText
$QuestSQLPasswordText = (Get-AzKeyVaultSecret -vaultName $azProdVault -name $azQuestDbPassword).SecretValueText
$QuestSQLPassword = $QuestSQLPasswordText | ConvertTo-SecureString -AsPlainText -Force

#Fetching SQL Server Details
$sqlServerInstance = $configXmlfile.ConfigSettings.SqlDbServer
$sqlDatabase = $configXmlfile.ConfigSettings.SqlDatabase
$sprocStatusChange = $configXmlfile.ConfigSettings.StoredProcedures.ChangeStatus
$sqlQuestServerInstance = $configXmlfile.ConfigSettings.JobDatabaseDetails.GetJobDbServer
$sqlQuestDatabase = $configXmlfile.ConfigSettings.JobDatabaseDetails.JobDbName
$sprocSitesForMigrationProgress = $configXmlfile.ConfigSettings.StoredProcedures.GetMigrationProgressSites.Name
$inputParameters = $configXmlfile.ConfigSettings.StoredProcedures.GetMigrationProgressSites.InputParameters
$outputParameters = $configXmlfile.ConfigSettings.StoredProcedures.GetMigrationProgressSites.OutputParameters
$JobFilterKeyWords = $configXmlfile.ConfigSettings.JobLogFiltersKeyword
$global:GlobalViewCount = $null

$sprocExcepLogging = $configXmlfile.ConfigSettings.StoredProcedures.ExceptionLogging.Name
$sprocExcepLogsInputParameters = $configXmlfile.ConfigSettings.StoredProcedures.ExceptionLogging.InputParameters
$sprocExcepLogsDynamicParameters = $configXmlfile.ConfigSettings.StoredProcedures.ExceptionLogging.DynamicInputParameters

#Fetch Job Database Details
$qDBServer = $sqlQuestServerInstance
$qDBName =  $sqlQuestDatabase
$qDBUserName = $QuestSQLID
$qDBPassword = $configXmlfile.ConfigSettings.JobDatabaseDetails.JobHashPassword

#Fetch Source Credentials

 
#Fetch Target Credentials
$TargetDetails = $configXmlfile.ConfigSettings.TargetDetails
$tcUserName = $configXmlfile.ConfigSettings.TargetDetails.UserId
$tcPassword = $configXmlfile.ConfigSettings.TargetDetails.HashPassword
$trgOuthToken = $configXmlfile.ConfigSettings.TargetDetails.TargetTokenInformation
$AzureAppClientIdToken = $configXmlfile.ConfigSettings.AzureAppClientId

##---------------- Adds registered Metalogix PowerShell snap-ins to the current session -----------------------------------------------##
if ( $PsVersionTable.PSVersion.Major -lt 3 ) { Write-Host "Windows PowerShell Version 3.0 or later needs to be installed in order to execute Content Matrix PowerShell scripts."; exit; }
if ( (Get-PSSnapin -Name Metalogix.System.Commands -ErrorAction SilentlyContinue) -eq $null ) { add-pssnapin Metalogix.System.Commands | out-null }
if ( (Get-PSSnapin -Name Metalogix.SharePoint.Migration.Commands -ErrorAction SilentlyContinue) -eq $null ) { add-pssnapin Metalogix.SharePoint.Migration.Commands | out-null }

if (Get-Command Set-MetalogixJobPrerequisites -ErrorAction SilentlyContinue){ Set-MetalogixJobPrerequisites -Value "Content Matrix Console - SharePoint Edition" }

##---------------- Set default resolvers ----------------------------------------------------------------------------------------------##
Set-MetalogixDefaultResolverSetting -Name "NodeLocation" -Value "Metalogix.Explorer.PersistentConnectionsResolver, Metalogix.Explorer, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03"
Set-MetalogixDefaultResolverSetting -Name "ResourceTableResourceTableLink" -Value "Metalogix.Core.ConfigVariables.ResourceDatabaseTableResolver, Metalogix.Core, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03"
Set-MetalogixDefaultResolverSetting -Name "DataResolverDataRepositoryLink" -Value "Metalogix.Client.ClientDataRepositoryResolver, Metalogix.Client, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03"
Set-MetalogixDefaultResolverSetting -Name "ResourceDatabaseTableResolverDatabase" -Value "Data Source=$qDBServer;Initial Catalog=$qDBName;Integrated Security=False;User ID=$qDBUserName;Password=$qDBPassword"

#Set Stored Procedure Dynamic Input parameter values for Exception logs
function ExceptionLogs-InputParameters ($CurrentSiteObject,$exceptionMessage, $ExceptionStacktrace, $itemname){
    try {
    
        $sprocExcepLogsDynamicParameters = foreach($item in $sprocExcepLogsDynamicParameters.Item) {    
            Switch($item.Name) {
				"@SiteId" { if($CurrentSiteObject -ne $null){$item.Value = [String]$CurrentSiteObject.SiteID;}else{$item.Value = "NULL"} break }
                "@BatchId" { if($CurrentSiteObject -ne $null){$item.Value = [String]$CurrentSiteObject.BatchID;}else{$item.Value = "NULL"} break }
				"@operation" { $item.Value = $MyInvocation.ScriptName.Split("\")[-1]; break }
				"@Itemname" { $item.Value = $itemname; break }
				"@source" { if($CurrentSiteObject -ne $null){$item.Value = $CurrentSiteObject.OriginalURL;}else{$item.Value = "NULL"} break }
                "@target" { if($CurrentSiteObject -ne $null){$item.Value = $CurrentSiteObject.TargetURL;}else{$item.Value = "NULL"} break }
				"@information" { $item.Value =$exceptionMessage;  break }
                "@details" { $item.Value = $ExceptionStacktrace ; break }       
            }
        }
    }
    catch {

        Write-Host $_.Exception.Message -ForegroundColor Red        
    }
}


function MigrationJobTracker (){
try{
	$CurrentSiteObject = $null
	$DataMigrationInProgress = Execute-StrdProcWithParametersReturnTable $orchestratorSQLID $orchestratorSQLPassword $sqlServerInstance $sqlDatabase $sprocSitesForMigrationProgress $inputParameters $outputParameters	
	if($DataMigrationInProgress[1] -ne 0)
	{
	$global:GlobalViewCount = $DataMigrationInProgress[1]
	$DataMigrationInProgress | Select-Object -Skip 2 | ForEach-Object {
	$CurrentSiteObject = $_;
	$FlagStatus = $_.HasIncremental;
	$Sql_getJob = "Select JobId,Status,StatusMessage,Finished from JobHistory where JobId = '"+$_.JobId+"'"
	$QuestStatusOfJobId = Fetch-Content $QuestSQLID $QuestSQLPassword $sqlQuestServerInstance $sqlQuestDatabase $Sql_getJob
	if($QuestStatusOfJobId[0] -ne 0)
	{
			if($QuestStatusOfJobId[1].Status -eq "Done" -and $QuestStatusOfJobId[1].Finished -ne "NULL")
			{
					
					
					if($FlagStatus -eq 0)
					{
					LogJobItemsToOrchestarionDb $_.fk_Site $_.fk_Batch $_.JobId $_.JobTitle $CurrentSiteObject
					$FlagStatus = checkForBatchFail $CurrentSiteObject $_.JobId
					}
					if($FlagStatus -ne 0)
					{
					$sqlQuery_GetSubJob = "Select * from Mig_Sites_Migration_SubJobInstances where JobTitle = '"+$_.JobTitle+"' and IncStatus = 0"
					$GetSubJob = Fetch-Content $orchestratorSQLID $orchestratorSQLPassword $sqlServerInstance $sqlDatabase $sqlQuery_GetSubJob
					if($GetSubJob[0] -ne 0)
					{
                        $count =  $GetSubJob[0]   
						$GetSubJob | Select-Object -Skip 1 | ForEach-Object {
							$Sql_subgetJob = "Select JobId,Status,StatusMessage,Finished from JobHistory where JobId = '"+$_.SubJobID+"'"
							$QuestStatusOfsubJobId = Fetch-Content $QuestSQLID $QuestSQLPassword $sqlQuestServerInstance $sqlQuestDatabase $Sql_subgetJob
							if($QuestStatusOfsubJobId[0] -ne 0)
							{
								if($QuestStatusOfsubJobId[1].Status -eq "Done" -and $QuestStatusOfsubJobId[1].Finished -ne "NULL")
								{
									$sqlQuery_updateflag = "Update Mig_Sites_Migration_SubJobInstances set IncStatus = 1 where SubJobID = '"+$_.SubJobID+"'"
									$res = Fetch-Content $orchestratorSQLID $orchestratorSQLPassword $sqlServerInstance $sqlDatabase $sqlQuery_updateflag
									$sqlQuery_updateDefectStatus = "Update Mig_Sites_MigrationJobFailures SET DefectStatus = 'Closed' where Status='Failed' and Operation Like 'Migration Job status' and JobID = '"+$CurrentSiteObject.JobId+"'"
									$res = Fetch-Content $orchestratorSQLID $orchestratorSQLPassword $sqlServerInstance $sqlDatabase $sqlQuery_updateDefectStatus
                                    $count--    
								}
								if($QuestStatusOfsubJobId[1].Status -eq "Failed" -and $QuestStatusOfsubJobId[1].Finished -ne "NULL")
								{
									$sqlQuery_updateflag = "Update Mig_Sites_Migration_SubJobInstances set IncStatus = -1 where SubJobID = '"+$_.SubJobID+"'"
									$res = Fetch-Content $orchestratorSQLID $orchestratorSQLPassword $sqlServerInstance $sqlDatabase $sqlQuery_updateflag
                                    $count--
								}
							}
                            if($count -eq 0)
                            {
                            ChangeStatusToPostMigration $CurrentSiteObject.fk_Site $CurrentSiteObject.fk_Batch
                            }
						}
					}
					else{
					ChangeStatusToPostMigration $_.fk_Site $_.fk_Batch
					}
					}
					else{ if($FlagStatus -eq 0){
					ChangeStatusToPostMigration $_.fk_Site $_.fk_Batch 
					}}
			}
			if($QuestStatusOfJobId[1].Status -eq "Failed" -and $QuestStatusOfJobId[1].Finished -ne "NULL")
			{
					Write-Host "Call fatal Procedure"
					LogJobItemsToOrchestarionDb $_.fk_Site $_.fk_Batch $_.JobId $_.JobTitle $CurrentSiteObject
					$sqlQuery_Fatal = "EXEC "+$sprocStatusChange+" @fk_Site=" + $_.fk_Site +", @fk_Batch=" + $_.fk_Batch +", @JobStep=400, @Status=600, @sys_EndActual=1"
					#Update SQL record - Status to Fatal Error
					Execute-SqlQuery $orchestratorSQLID $orchestratorSQLPassword $sqlServerInstance $sqlDatabase $sqlQuery_Fatal
					Write-Host "Marking this site as Fatal -Error in SQL DB" -ForegroundColor Red
					Write-Host "`n"
			}
			
	}
	else{
					Write-Host "No Such JobId $_.JobId exist in Quest Database";
                    
	}
	
	}#End of ForEach-Object
	
	}#end of If
	else
	{
		$global:GlobalViewCount = 0;
		break;
	}
	}#end of try
catch {
		Write-Host $_.Exception.Message -ForegroundColor Red
        Write-Host "`n"
        $ExceptionMessage = $("At Line : "+$_.Exception.ErrorRecord.InvocationInfo.ScriptLineNumber+" Char : "+$_.Exception.ErrorRecord.InvocationInfo.OffsetInLine+" Error : "+$_.Exception.Message).Replace('"','`"')
		$ExceptionStacktrace = $_.Exception.ErrorRecord.ScriptStackTrace
		ExceptionLogs-InputParameters $CurrentSiteObject $ExceptionMessage $ExceptionStacktrace "MigrationJobTracker"
		$inputParam = $sprocExcepLogsInputParameters,$sprocExcepLogsDynamicParameters
		Execute-StrdProcWithParametersReturnTable $orchestratorSQLID $orchestratorSQLPassword $sqlServerInstance $sqlDatabase $sprocExcepLogging $inputParam $null 
		break;
	} 
}

function ChangeStatusToPostMigration($fk_Site, $fk_batch)
{
					Write-Host "Call Procedure"
					Start-Sleep -Seconds 2
					$sqlQuery_Complete = "EXEC "+$sprocStatusChange+" @fk_Site=" + $fk_Site +", @fk_Batch=" + $fk_batch +", @JobStep=400, @Status=400, @sys_EndActual=1"
					#Update SQL record - Status to Complete        
					Execute-SqlQuery $orchestratorSQLID $orchestratorSQLPassword $sqlServerInstance $sqlDatabase $sqlQuery_Complete
					Write-Host "Marking "  $fk_Site  " site as Migration - Completed in SQL DB" -ForegroundColor Blue
					Write-Host "`n"

					Start-Sleep -Seconds 2
					$sqlQuery_Scheduled = "EXEC "+$sprocStatusChange+" @fk_Site=" + $fk_Site +", @fk_Batch=" + $fk_batch+", @JobStep=425, @Status=1000"
					#Update SQL record - Status to Scheduled and Sent for Testing
					Execute-SqlQuery $orchestratorSQLID $orchestratorSQLPassword $sqlServerInstance $sqlDatabase $sqlQuery_Scheduled
					Write-Host "Marking "  $fk_Site  "site as Post Migration - Ready to Proceed in SQL DB" -ForegroundColor Blue
					Write-Host "`n"
}

function LogJobItemsToOrchestarionDb($SiteId, $BatchId, $JobId, $JobTitle, $CurrentSiteObject)
{
	try{
	$today = Get-Date
	$timeFormat = $today.ToString('yyyy-MM-dd hh:mm:ss')
	$sqlQuery_jobLogItem = "select "+$SiteId+" as fk_Site, "+$BatchId+" as fk_Batch, JobID, Status, Operation, ItemName, Source, Target, Information, Details, 0 as ID, 400 as fk_jobStep, 'Open' as DefectStatus, '"+$timeFormat+"' as Createddate, '"+$JobTitle+"' as JobTitle from JobLogItems where Status='Failed' and JobID='"+$JobId+"'"
	#$JobFilterKeyWords = $configXmlfile.ConfigSettings.JobLogFiltersKeyword 
    if($JobFilterKeyWords.ChildNodes.count -ne 0){
	$JobFilterKeyWords.SelectNodes("keyword") | ForEach-Object {
	$sqlQuery_jobLogItem += " and "+$_.ColName+" "+$_.Operation+" "+$_.pattern
	}}
	$DatajobLogItem = Fetch-Content $QuestSQLID $QuestSQLPassword $sqlQuestServerInstance $sqlQuestDatabase $sqlQuery_jobLogItem
	if($DatajobLogItem[0] -ne 0)
	{	$dataTable = $DatajobLogItem | Select-Object -Skip 1
		Execute-BulkSqlQuery $orchestratorSQLID $orchestratorSQLPassword $sqlServerInstance $sqlDatabase "Mig_Sites_MigrationJobFailures" $dataTable $DatajobLogItem[0]
	}
	}
	catch{
		Write-Host $_.Exception.Message -ForegroundColor Red
        Write-Host "`n"
        $ExceptionMessage = $("At Line : "+$_.Exception.ErrorRecord.InvocationInfo.ScriptLineNumber+" Char : "+$_.Exception.ErrorRecord.InvocationInfo.OffsetInLine+" Error : "+$_.Exception.Message).Replace('"','`"')
		$ExceptionStacktrace = $_.Exception.ErrorRecord.ScriptStackTrace
		ExceptionLogs-InputParameters $CurrentSiteObject $ExceptionMessage $ExceptionStacktrace "LogJobItemsToOrchestarionDb"
		$inputParam = $sprocExcepLogsInputParameters,$sprocExcepLogsDynamicParameters
		Execute-StrdProcWithParametersReturnTable $orchestratorSQLID $orchestratorSQLPassword $sqlServerInstance $sqlDatabase $sprocExcepLogging $inputParam $null 
	}
}

function ListIncrementalMigration($CurrentSiteObject, $trgURL)
{
	try{
				$trgURL1=$trgURL
				$relativePath = $trgURL1.Replace($CurrentSiteObject.targetUrl,"");
				$ListPath = $relativePath.Split("/");
if($ListPath -gt 1)
{
				if($ListPath[1] -ne "Lists")
				{
				$path = "/"+$ListPath[1] 
				$dispUrl = "/"+$ListPath[1]
				}
				else
				{
				$path = "/"+$ListPath[2] 
				$dispUrl = "/Lists/"+$ListPath[2]
				}
				
				$_SourceType = $CurrentSiteObject.SourceType
				$_originalURL= $CurrentSiteObject.originalUrl
				$_targetURL = $CurrentSiteObject.targetUrl
				$_SQLserverName = $CurrentSiteObject.fqn
				$_SourceType = $CurrentSiteObject.SourceType
				$scDBName = $CurrentSiteObject.databaseName
				$_port = $CurrentSiteObject.port
				$scDBServer = $_SQLserverName+", "+$_port
		        
				
		        $_srcUrl = $_originalURL.Replace("https://","")
		        $_srcUrlValues = $_srcUrl.Split("/")
		        $_dn = $_srcUrlValues[0]  # Host Header
				$_tempSiteID = "%2F"+$_srcUrlValues[1]+"%2F"+$_srcUrlValues[2] 
		        $_OriginalsiteID = "/"+$_srcUrlValues[1]+"/"+$_srcUrlValues[2]
		        $scPath = $path
		        $scDisplayUrl = $_dn+"."+$scDBName+$_OriginalsiteID+$dispUrl
		        $scUrl = $_OriginalsiteID
				
				$scDBUserName = $null
				$scDBPassword = $null
				#Fetch Source Credentials
				if($_SourceType -eq 'Extranet')
				{
				$SourceDetails = $configXmlfile.ConfigSettings.ExtranetSourceDetails
				$scDBUserName = $SourceDetails.UserId
				$scDBPassword = $SourceDetails.HashPassword
				}
				if($_SourceType -eq 'Intranet')
				{
				$SourceDetails = $configXmlfile.ConfigSettings.IntranetSourceDetails
				$scDBUserName = $SourceDetails.UserId
				$scDBPassword = $SourceDetails.HashPassword
				}
				
		        
			## ---------------------------------- Load source --------------------------------------------- ###					

$SourceCollection = New-MetalogixSerializableObjectCollection "<IXMLAbleList IXMLAbleType=`"Metalogix.Explorer.NodeCollection, Metalogix.Explorer, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`"><NodeCollection><Location Path=`"$scPath`" DisplayUrl=`"$scDisplayUrl`"><Connection NodeType=`"Metalogix.SharePoint.SPSite, Metalogix.SharePoint, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" SharePointVersion=`"`" UnderlyingAdapterType=`"DB`" ShowAllSites=`"True`" AdapterType=`"DB`" Server=`"$scDBServer`" Database=`"$scDBName`" Url=`"$_OriginalsiteID`" HostHeader=`"$_dn`" UserName=`"$scDBUserName`" SavePassword=`"True`" Password=`"$scDBPassword`" /></Location></NodeCollection></IXMLAbleList>" -ErrorAction Stop

			## ------------------------------------------------------------------------------------------ ###	        	

		        $tcPath = $path
		        $tcDisplayUrl = $_targetURL+$dispUrl 
		        $tcRootSiteUrl = $_targetURL 
		     
				
			## ---------------------------------- Load target --------------------------------------------- ###
			
$TargetCollection = New-MetalogixSerializableObjectCollection "<IXMLAbleList IXMLAbleType=`"Metalogix.Explorer.NodeCollection, Metalogix.Explorer, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`"><NodeCollection><Location Path=`"$tcPath`" DisplayUrl=`"$tcDisplayUrl`"><Connection NodeType=`"Metalogix.SharePoint.SPWeb, Metalogix.SharePoint, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" SharePointVersion=`"`" UnderlyingAdapterType=`"CSOM`" ShowAllSites=`"True`" AdapterType=`"CSOM`" Url=`"$tcRootSiteUrl`" UserName=`"$tcUserName`" SavePassword=`"True`" Password=`"$tcPassword`" ReadOnly=`"False`" AuthenticationType=`"Metalogix.SharePoint.Adapters.CSOM2013.Authentication.Office365StandADFSInitializer`" IsOAuthAuthentication=`"True`"><TokenInformation AzureAppClientId=`"$AzureAppClientIdToken`">$trgOuthToken</TokenInformation></Connection></Location></NodeCollection></IXMLAbleList>" -ErrorAction Stop

foreach($Target in $TargetCollection) {
						$migration = $null
						$today = Get-Date
		        		$timeFormat = $today.ToString('MM-dd-yyyy_hh-mm-ss')
						$jobName = [String]$CurrentSiteObject.fk_Site+"_"+[String]$CurrentSiteObject.fk_Batch+"_INC_"+$timeFormat
						
    $migration = $SourceCollection | Copy-MLAllListItems -Target $Target  -CopyFolderPermissions -CopyListItems -UseAzureOffice365Upload -EncryptAzureMigrationJobs -IsAzurePrivateContainer "True" -ClearRoleAssignments -CopyItemPermissions -CheckModifiedDatesForItemsDocuments -UpdateItems "All" -ReattachPageLayouts -CopyVersions -CopySubFolders -PreserveItemIDs -MigrationMode "Incremental" -VerboseLog -LogSkippedItems -ForceRefresh -CorrectingLinks -LinkCorrectionScope "SiteCollection" -AllowDBUserWriting -MapGroupsByName -OverwriteGroups -MapMissingUsersToLoginName "" -OverrideCheckouts -Transformers ( New-MetalogixSerializableObject "Metalogix.Transformers.TransformerCollection" "Metalogix.Actions" "<TransformerCollection><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.ContentTypeFieldMapper, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.ManagedMetadataItemValueMapper, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.DeletionPropagator, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.ReferencedListItemDataUpdater, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.DocumentSetsApplicator, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.ContentTypesApplicator, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.ListItemColumnMapper, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.WorkflowDataUpdater, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.PublishingDataUpdater, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.InfopathItemContentXml, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.MapUsers, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.WebPartsProcessor, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /></TransformerCollection>" -Enumerate) -agentdatabase "Data Source=$qDBServer;Initial Catalog=$qDBName;Integrated Security=False;User ID=$qDBUserName;Password=$qDBPassword" -RunRemotely -jobtitle $jobName
}
 if($migration -ne $null){
	$JobID = [string]$migration.Split("'")[1]
	$JobTitle = $CurrentSiteObject.JobTitle
	$sql_insertSubJob = "Insert into Mig_Sites_Migration_SubJobInstances (JobTitle,SubJobID,SubJobTitle) values('"+$JobTitle+"', '"+$JobID+"','"+$jobName+"')"
	$res = Fetch-Content $orchestratorSQLID $orchestratorSQLPassword $sqlServerInstance $sqlDatabase $sql_insertSubJob
 
 }
 }
	}
	catch{
		Write-Host $_.Exception.Message -ForegroundColor Red
        Write-Host "`n"
        $ExceptionMessage = $("At Line : "+$_.Exception.ErrorRecord.InvocationInfo.ScriptLineNumber+" Char : "+$_.Exception.ErrorRecord.InvocationInfo.OffsetInLine+" Error : "+$_.Exception.Message).Replace('"','`"')
		$ExceptionStacktrace = $_.Exception.ErrorRecord.ScriptStackTrace
        ExceptionLogs-InputParameters $CurrentSiteObject $ExceptionMessage $ExceptionStacktrace "ListIncrementalMigration" 
		$inputParam = $sprocExcepLogsInputParameters,$sprocExcepLogsDynamicParameters
		Execute-StrdProcWithParametersReturnTable $orchestratorSQLID $orchestratorSQLPassword $sqlServerInstance $sqlDatabase $sprocExcepLogging $inputParam $null  
	}
}

function checkForBatchFail($CurrentSiteObject, $JobId)
{
	try{
	$flg = 0;
	$sqlQuery_BatchFail = "select distinct Target from Mig_Sites_MigrationJobFailures where Status='Failed' and Operation Like 'Migration Job status' and JobID='"+$JobId+"'"
	$DataTargetURls = Fetch-Content $orchestratorSQLID $orchestratorSQLPassword $sqlServerInstance $sqlDatabase $sqlQuery_BatchFail
	if($DataTargetURls[0] -ne 0)
	{	$DataTargetURls | Select-Object -Skip 1 | ForEach-Object {
			$trgURL = $_.Target;
			ListIncrementalMigration $CurrentSiteObject $trgURL
		}
		$sqlQuery_updateflag = "Update Mig_Sites_Migration_JobInstances set HasIncremental = 1 where JobId = '"+$JobId+"'"
		$res = Fetch-Content $orchestratorSQLID $orchestratorSQLPassword $sqlServerInstance $sqlDatabase $sqlQuery_updateflag
		$flg = 1;
	}
	return $flg;
	}
	catch{
		Write-Host $_.Exception.Message -ForegroundColor Red
        Write-Host "`n"
        $ExceptionMessage = $("At Line : "+$_.Exception.ErrorRecord.InvocationInfo.ScriptLineNumber+" Char : "+$_.Exception.ErrorRecord.InvocationInfo.OffsetInLine+" Error : "+$_.Exception.Message).Replace('"','`"')
		$ExceptionStacktrace = $_.Exception.ErrorRecord.ScriptStackTrace
        ExceptionLogs-InputParameters $CurrentSiteObject $ExceptionMessage $ExceptionStacktrace "checkForBatchFail" 
		$inputParam = $sprocExcepLogsInputParameters,$sprocExcepLogsDynamicParameters
		Execute-StrdProcWithParametersReturnTable $orchestratorSQLID $orchestratorSQLPassword $sqlServerInstance $sqlDatabase $sprocExcepLogging $inputParam $null 
	}
}


MigrationJobTracker
<#
do
{	

Start-Sleep -Seconds 5
}
while($global:GlobalViewCount -ne 0)
#>