﻿#Build SQL ConnectionString
function Get-SqlConnectionString {
    Param(
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $userId,
        [Parameter(Mandatory = $true)] $password,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $server,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $database
    )
    try { 
        $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($password)
        $dbPassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
        return "Server=$server;Database=$database;timeout=1800;UId=$userId; Pwd=$dbPassword"
    }
    catch {
        Write-Host "Failed in generating SQL Connection: " $_.Exception.Message -ForegroundColor Red
    }
}


#Build Input/Output parameters for StoredProcedure
function Format-StrdProcParameters {
    Param(
        [Parameter(Mandatory = $true)] $inputParameters,
        [Parameter(Mandatory = $false)] $outputParameters,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $inputString
    )
    try {
        [String]$ioParameters = $null
        $counter = 0
        $inputParameters.SelectNodes("Item") | ForEach-Object {
		
            $counter++
            $parameter = "$" + "$param" + $counter
            if($_.Type.ToLower().Trim() -eq "string") {
                $ioParameters += "$parameter = New-Object System.Data.SqlClient.SqlParameter `n"
                $ioParameters += "$parameter.ParameterName = `"$($_.Name)`" `n"
                $ioParameters += "$parameter.Direction = [System.Data.ParameterDirection]::Input `n"
				if($_.Value -ne "NULL"){
                $ioParameters += "$parameter.Value = `"$($_.Value)`" `n"
				}
				else
				{
				$ioParameters += "$parameter.Value = [DbNull]:: Value `n"
				}
            } 
			if($_.Type.ToLower().Trim() -eq "int32") {
				$ioParameters += "$parameter = New-Object System.Data.SqlClient.SqlParameter `n"
                $ioParameters += "$parameter.ParameterName = `"$($_.Name)`" `n"
                $ioParameters += "$parameter.Direction = [System.Data.ParameterDirection]::Input `n"
				$ioParameters += "$parameter.DbType = [System.Data.DbType]::Int32 `n"
				if($_.Value -ne "NULL"){
                $ioParameters += "$parameter.Value = $($_.Value) `n"   
				}
				else
				{
				$ioParameters += "$parameter.Value = [DbNull]:: Value `n"
				}				
            }	
				$ioParameters += "$" + "$inputString.Parameters.Add($parameter) `n"			
        
		
        
		}
		
		if($outputParameters -ne $null) {
        $outputParameters.SelectNodes("Item") | ForEach-Object {
            $counter++
            $parameter = "$" + "param" + $counter
            if($_.Type.ToLower().Trim() -eq "string") {
                $ioParameters += "$parameter = New-Object System.Data.SqlClient.SqlParameter `n"
                $ioParameters += "$parameter.ParameterName = `"$($_.Name)`" `n"
                $ioParameters += "$parameter.Direction = [System.Data.ParameterDirection]::Output `n"
                $ioParameters += "$parameter.DbType = [System.Data.DbType]::String `n"
                $ioParameters += "$parameter.Size = $($_.CharLength) `n"
            }
            if($_.Type.ToLower().Trim() -eq "int32") {
                $ioParameters += "$parameter = New-Object System.Data.SqlClient.SqlParameter `n"
                $ioParameters += "$parameter.ParameterName = `"$($_.Name)`" `n"
                $ioParameters += "$parameter.Direction = [System.Data.ParameterDirection]::Output `n"
                $ioParameters += "$parameter.DbType = [System.Data.DbType]::Int32 `n"       
            }
			if($_.Type.ToLower().Trim() -eq "Byte") {
                $ioParameters += "$parameter = New-Object System.Data.SqlClient.SqlParameter `n"
                $ioParameters += "$parameter.ParameterName = `"$($_.Name)`" `n"
                $ioParameters += "$parameter.Direction = [System.Data.ParameterDirection]::Output `n"
                $ioParameters += "$parameter.DbType = [System.Data.DbType]::Byte `n"       
            }
            $ioParameters += "$" +"$inputString.Parameters.Add($parameter) | Out-Null `n"
        }
		}
        return $ioParameters
    }
    catch {
        Write-Host "Failed in BuildStoredProcedureParameters: " $_.Exception.Message -ForegroundColor Red
    }    
}




#Execute SQL Query
function Execute-SqlQuery {
    Param(
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $dboUserId,
        [Parameter(Mandatory = $true)] $dboPassword,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $sqlServer,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $sqlDatabase,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $sqlQuery
    )
    try {
        $sqlConnection = New-Object System.Data.SqlClient.SqlConnection
        $sqlConnection.ConnectionString = Get-SqlConnectionString $dboUserId $dboPassword $sqlServer $sqlDatabase
        $sqlCommand = New-Object System.Data.SQLClient.SQLCommand
        $sqlCommand.CommandText = $sqlQuery
        $sqlCommand.Connection = $sqlConnection
        $sqlConnection.Open()
        $sqlCommand.ExecuteNonQuery() | Out-Null        
        $sqlConnection.Close()
        return $true
    }
    catch {
        Write-Host "Failed in executing Query $($sqlQuery): `n" $_.Exception.Message -ForegroundColor Red
        return $_.Exception.Message
    }
    finally {
        $sqlConnection.Dispose()
        $sqlCommand.Dispose()
    }
}


#Execute Stored Procedure with Input/Output parameters
function Execute-StrdProcWithParameters {
    Param(
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $dboUserId,
        [Parameter(Mandatory = $true)] $dboPassword,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $sqlServer,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $sqlDatabase,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $storedProcedure,        
        [Parameter(Mandatory = $true)] $inputParameters,
        [Parameter(Mandatory = $false)] $outputParameters
    )
    try {
        $sqlConnection = New-Object System.Data.SqlClient.SqlConnection
	    $sqlConnection.ConnectionString = Get-SqlConnectionString $dboUserId $dboPassword $sqlServer $sqlDatabase        
        $sqlCommand = New-Object System.Data.SqlClient.SqlCommand
        $sqlCommand.CommandText = $storedProcedure
        $sqlCommand.Connection = $sqlConnection
        $sqlCommand.CommandType = [System.Data.CommandType]::StoredProcedure
                
        #Build the Inuput/Output parameters
        $strParameters = Format-StrdProcParameters $inputParameters $outputParameters "sqlCommand"
        Invoke-Expression $strParameters
        
        $sqlConnection.Open()
        $sqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter  
        $sqlAdapter.SelectCommand = $sqlCommand 
        $sqlAdapter.SelectCommand.CommandTimeout=300  
        
        #Creating Dataset  
        $dataSet = New-Object System.Data.DataSet  
        $sqlAdapter.Fill($dataSet)
        $sqlConnection.Close()
        $formatResponse = $null
        $sqlCommand.Parameters | ForEach-Object {            
            $formatResponse += "$($_.ParameterName.Split('@')[1]) = $($_.Value)" | ConvertFrom-StringData
        }        
        return $formatResponse      
    }
    catch {
        Write-Host "$($_.Exception.Message) `n" -ForegroundColor Red
    }
    finally {
        $sqlConnection.Dispose()
        $sqlCommand.Dispose()
    }
}

function Fetch-Content{
		Param(
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $dboUserId,
        [Parameter(Mandatory = $true)] $dboPassword,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $sqlServer,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $sqlDatabase,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $sqlQuery
		)
    try {
        $sqlConnection = New-Object System.Data.SqlClient.SqlConnection
        $sqlConnection.ConnectionString = Get-SqlConnectionString $dboUserId $dboPassword $sqlServer $sqlDatabase
        $sqlConnection.Open()
        $sqlCommand = New-Object System.Data.SqlClient.SqlCommand  
        $sqlCommand.CommandText = $sqlQuery  
        $sqlCommand.Connection = $sqlConnection  
        $sqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter  
        $sqlAdapter.SelectCommand = $sqlCommand   
        #Creating Dataset  
        $dataSet = New-Object System.Data.DataSet  
        $sqlAdapter.Fill($dataSet)        
        $sqlConnection.Close()
        return $dataSet.Tables[0]
    }
    catch {
        Write-Host "$($_.Exception.Message)" -ForegroundColor Red
        Write-Host "`n"
    }   
	finally {
        $sqlConnection.Dispose()
        $sqlCommand.Dispose()
    }	
}


#Execute SQL Query
function Execute-BulkSqlQuery {
    Param(
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $dboUserId,
        [Parameter(Mandatory = $true)] $dboPassword,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $sqlServer,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $sqlDatabase,
        [Parameter(Mandatory = $true)] [string]$TableName, 
        [Parameter(Mandatory = $true)] $Data, 
        [Parameter(Mandatory = $false)] [Int32]$BatchSize=50000, 
        [Parameter(Mandatory = $false)] [Int32]$QueryTimeout=0, 
        [Parameter(Mandatory = $false)] [Int32]$ConnectionTimeout=15 
    
    )
    try {
        $sqlConnection = New-Object System.Data.SqlClient.SqlConnection
        $sqlConnectionString = Get-SqlConnectionString $dboUserId $dboPassword $sqlServer $sqlDatabase
        $sqlConnection.ConnectionString = $sqlConnectionString
        $sqlCommand = New-Object System.Data.SQLClient.SQLCommand
        $sqlCommand.Connection = $sqlConnection
        $sqlConnection.Open()
        $bulkCopy = new-object ("Data.SqlClient.SqlBulkCopy") $sqlConnectionString
        $bulkCopy.DestinationTableName = $TableName 
        $bulkCopy.BatchSize = $BatchSize 
        $bulkCopy.BulkCopyTimeout = $QueryTimeOut 
        $bulkCopy.WriteToServer($Data) 
        $sqlConnection.Close()
        return $true
    }
    catch {
        Write-Host "Failed in executing Query $($sqlQuery): `n" $_.Exception.Message -ForegroundColor Red
        return $_.Exception.Message
    }
    finally {
        $sqlConnection.Dispose()
        $sqlCommand.Dispose()
    }
} 

function Execute-StrdProcWithParametersReturnTable {
    Param(
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $dboUserId,
        [Parameter(Mandatory = $true)] $dboPassword,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $sqlServer,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $sqlDatabase,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $storedProcedure,        
        [Parameter(Mandatory = $true)] $inputParameters,
        [Parameter(Mandatory = $false)] $outputParameters
    )
    try {
        $sqlConnection = New-Object System.Data.SqlClient.SqlConnection
	    $sqlConnection.ConnectionString = Get-SqlConnectionString $dboUserId $dboPassword $sqlServer $sqlDatabase        
        $sqlCommand = New-Object System.Data.SqlClient.SqlCommand
        $sqlCommand.CommandText = $storedProcedure
        $sqlCommand.Connection = $sqlConnection
        $sqlCommand.CommandType = [System.Data.CommandType]::StoredProcedure
                
        #Build the Inuput/Output parameters
        $strParameters = Format-StrdProcParameters $inputParameters $outputParameters "sqlCommand"
        Invoke-Expression $strParameters
        
        $sqlConnection.Open()
        $sqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter  
        $sqlAdapter.SelectCommand = $sqlCommand 
        $sqlAdapter.SelectCommand.CommandTimeout=300  
        
        #Creating Dataset  
        $dataSet = New-Object System.Data.DataSet  
        $sqlAdapter.Fill($dataSet)
        $sqlConnection.Close()
        $formatResponse = $null
        $sqlCommand.Parameters | ForEach-Object {            
            #$formatResponse += "$($_.ParameterName.Split('@')[1]) = $($_.Value)" | ConvertFrom-StringData
        }        
        return $dataSet.Tables[0]      
    }
    catch {
        Write-Host "$($_.Exception.Message) `n" -ForegroundColor Red
    }
    finally {
        $sqlConnection.Dispose()
        $sqlCommand.Dispose()
    }
}
