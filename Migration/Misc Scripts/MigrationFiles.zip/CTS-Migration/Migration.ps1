﻿Clear-Host| Remove-Module -Force

#Load XML Config File
$scriptRoot = Split-Path $MyInvocation.MyCommand.Path -Parent
$parentRoot = (Get-Item $scriptRoot).Parent.FullName
$configfolder = Join-Path $parentRoot.ToLower().Replace('\cts\','\ey\') "CTS-Mig-0Settings"
$xmlConfigPath = Join-Path $configfolder -ChildPath  "MigrationSettings.xml"
$configXmlfile = [xml]$(Get-Content $xmlConfigPath)


#Load Module files
$modulesPath = Join-Path $scriptRoot $configXmlfile.ConfigSettings.ModulesFile
Import-Module -Name $modulesPath


#Fetching SQL Server Details
$sqlServerInstance = $configXmlfile.ConfigSettings.SqlDbServer
$sqlDatabase = $configXmlfile.ConfigSettings.SqlDatabase
$sprocSitesForMigration = $configXmlfile.ConfigSettings.StoredProcedures.GetMigrationSites.Name
$sprocStatusChange = $configXmlfile.ConfigSettings.StoredProcedures.ChangeStatus
$inputParameters = $configXmlfile.ConfigSettings.StoredProcedures.GetMigrationSites.InputParameters
$outputParameters = $configXmlfile.ConfigSettings.StoredProcedures.GetMigrationSites.OutputParameters
$sprocMigrationJobInsert = $configXmlfile.ConfigSettings.StoredProcedures.MigrationJobInsert
$Inparam = $configXmlfile.ConfigSettings.StoredProcedures.MigrationJobInsert.InputParameters
$Outparam = $configXmlfile.ConfigSettings.StoredProcedures.MigrationJobInsert.OutputParameters

#Fetch SQL Credentials from Azure KeyVault
$MyAzurePath = $configXmlfile.ConfigSettings.AzureDirectory
Import-Module -Name "$MyAzurePath\Az.Accounts\1.9.3\Az.Accounts.psd1"
import-module -name "$MyAzurePath\Az.KeyVault\2.1.0\Az.KeyVault.psd1"
$azAppId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.ApplicationId
$azTenantId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.TenantId
$azCertificates = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.CertificateThumbprint
$azProdVault = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.ProdVaultName
$azOrchDbUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.OrchestrationUserId
$azOrchDbPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.OrchestrationPassword
$azQuestDbUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.QuestUserId
$azQuestDbPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.QuestPassword

##---------------- Connect and Fetching the MigrationOrchestration DB cretentials from Azure Key Vault -----------------------------##
Connect-AzAccount -ServicePrincipal -ApplicationId $azAppId -Tenant $azTenantId -CertificateThumbprint $azCertificates
$orchestratorSQLID = (Get-AzKeyVaultSecret -vaultName $azProdVault -name $azOrchDbUserId).SecretValueText
$orchestratorSQLPasswordText = (Get-AzKeyVaultSecret -vaultName $azProdVault -name $azOrchDbPassword).SecretValueText
$orchestratorSQLPassword = $orchestratorSQLPasswordText | ConvertTo-SecureString -AsPlainText -Force
$QuestSQLID = (Get-AzKeyVaultSecret -vaultName $azProdVault -name $azQuestDbUserId).SecretValueText
$QuestSQLPasswordText = (Get-AzKeyVaultSecret -vaultName $azProdVault -name $azQuestDbPassword).SecretValueText
$QuestSQLPassword = $QuestSQLPasswordText | ConvertTo-SecureString -AsPlainText -Force

#Fetch Job Database Details
$JobDatabaseDetails = $configXmlfile.ConfigSettings.JobDatabaseDetails
$qDBServer = $JobDatabaseDetails.GetJobDbServer
$qDBName = $JobDatabaseDetails.JobDbName
$qDBUserName = $QuestSQLID
$qDBPassword = $JobDatabaseDetails.JobHashPassword

#Fetch Source Credentials
	#source crededential depend on its type
 
#Fetch Target Credentials
$TargetDetails = $configXmlfile.ConfigSettings.TargetDetails
$tcUserName = $configXmlfile.ConfigSettings.TargetDetails.UserId
$tcPassword = $configXmlfile.ConfigSettings.TargetDetails.HashPassword
$trgOuthToken = $configXmlfile.ConfigSettings.TargetDetails.TargetTokenInformation
$AzureAppClientIdToken = $configXmlfile.ConfigSettings.AzureAppClientId


##---------------- Adds registered Metalogix PowerShell snap-ins to the current session -----------------------------------------------##
if ( $PsVersionTable.PSVersion.Major -lt 3 ) { Write-Host "Windows PowerShell Version 3.0 or later needs to be installed in order to execute Content Matrix PowerShell scripts."; exit; }
if ( (Get-PSSnapin -Name Metalogix.System.Commands -ErrorAction SilentlyContinue) -eq $null ) { add-pssnapin Metalogix.System.Commands | out-null }
if ( (Get-PSSnapin -Name Metalogix.SharePoint.Migration.Commands -ErrorAction SilentlyContinue) -eq $null ) { add-pssnapin Metalogix.SharePoint.Migration.Commands | out-null }

if (Get-Command Set-MetalogixJobPrerequisites -ErrorAction SilentlyContinue){ Set-MetalogixJobPrerequisites -Value "Content Matrix Console - SharePoint Edition" }

##---------------- Set default resolvers ----------------------------------------------------------------------------------------------##
Set-MetalogixDefaultResolverSetting -Name "NodeLocation" -Value "Metalogix.Explorer.PersistentConnectionsResolver, Metalogix.Explorer, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03"
Set-MetalogixDefaultResolverSetting -Name "ResourceTableResourceTableLink" -Value "Metalogix.Core.ConfigVariables.ResourceDatabaseTableResolver, Metalogix.Core, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03"
Set-MetalogixDefaultResolverSetting -Name "DataResolverDataRepositoryLink" -Value "Metalogix.Client.ClientDataRepositoryResolver, Metalogix.Client, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03"
Set-MetalogixDefaultResolverSetting -Name "ResourceDatabaseTableResolverDatabase" -Value "Data Source=$qDBServer;Initial Catalog=$qDBName;Integrated Security=False;User ID=$qDBUserName;Password=$qDBPassword"

$global:GlobalsiteID = $null
$global:GlobalbatchID = $null
$global:totalSites = 0
$global:PushedCount = 0
$global:fatalCount = 0
$constEnvPath = $env:Path

$sprocExcepLogging = $configXmlfile.ConfigSettings.StoredProcedures.ExceptionLogging.Name
$sprocExcepLogsInputParameters = $configXmlfile.ConfigSettings.StoredProcedures.ExceptionLogging.InputParameters
$sprocExcepLogsDynamicParameters = $configXmlfile.ConfigSettings.StoredProcedures.ExceptionLogging.DynamicInputParameters

#Set Stored Procedure Dynamic Input parameter values for Exception logs
function ExceptionLogs-InputParameters ($CurrentSiteObject,$exceptionMessage, $ExceptionStacktrace, $itemname){
    try {
    
        $sprocExcepLogsDynamicParameters = foreach($item in $sprocExcepLogsDynamicParameters.Item) {    
            Switch($item.Name) {
				"@SiteId" { if($CurrentSiteObject -ne $null){$item.Value = [String]$CurrentSiteObject.SiteID;}else{$item.Value = "NULL"} break }
                "@BatchId" { if($CurrentSiteObject -ne $null){$item.Value = [String]$CurrentSiteObject.BatchID;}else{$item.Value = "NULL"} break }
				"@operation" { $item.Value = $MyInvocation.ScriptName.Split("\")[-1]; break }
				"@Itemname" { $item.Value = $itemname; break }
				"@source" { if($CurrentSiteObject -ne $null){$item.Value = $CurrentSiteObject.OriginalURL;}else{$item.Value = "NULL"} break }
                "@target" { if($CurrentSiteObject -ne $null){$item.Value = $CurrentSiteObject.TargetURL;}else{$item.Value = "NULL"} break }
				"@information" { $item.Value =$exceptionMessage;  break }
                "@details" { $item.Value = $ExceptionStacktrace ; break }       
            }
        }
    }
    catch {
        Write-Host $_.Exception.Message -ForegroundColor Red        
    }
}

##Execute Migration
function InitiateNextSiteMigration () {
    try {       
		$getMigrationSiteDetails = Execute-StrdProcWithParameters $orchestratorSQLID $orchestratorSQLPassword $sqlServerInstance $sqlDatabase $sprocSitesForMigration $inputParameters $outputParameters
        $_originalURL = [String]$getMigrationSiteDetails.OriginalURL
        $_targetURL = [String]$getMigrationSiteDetails.TargetURL
		$_siteID =  [Int]$getMigrationSiteDetails.SiteID
	    $_batchID = [Int]$getMigrationSiteDetails.BatchID
		$_SQLserverName = [String]$getMigrationSiteDetails.SQLServerName
        $_SQLDBName = [String]$getMigrationSiteDetails.SQLDBName
		$_IPAddress =  [String]$getMigrationSiteDetails.IPAddress
	    $_port = $getMigrationSiteDetails.Port
		$_SourceType = [String]$getMigrationSiteDetails.SourceType
		Write-Host "OriginalURL:" $_originalURL -ForegroundColor Blue
        Write-Host "TargetURL:" $_targetURL -ForegroundColor Blue
        Write-Host "SiteID:" $_siteID -ForegroundColor Blue
        Write-Host "BatchID:" $_batchID -ForegroundColor Blue  
		Write-Host "SQLServerName:" $_SQLserverName -ForegroundColor Blue
        Write-Host "SQLDBName:" $_SQLDBName -ForegroundColor Blue
        Write-Host "IPAddress:" $_IPAddress -ForegroundColor Blue
        Write-Host "Port:" $_port -ForegroundColor Blue 
		Write-Host "SourceType:" $_SourceType -ForegroundColor Blue
		$global:GlobalsiteID = $_siteID
		$global:GlobalbatchID =$_batchID
		
		try{	
			if($_siteID -ne -1 -and $_batchID -ne -1){
				$global:totalSites++
				$scDBServer = $_SQLserverName+", "+$_port
		        $scDBName = $_SQLDBName
		        $_srcUrl = $_originalURL.Replace("https://","")
		        $_srcUrlValues = $_srcUrl.Split("/")
		        $_dn = $_srcUrlValues[0]  # Host Header
				$_tempSiteID = "%2F"+$_srcUrlValues[1]+"%2F"+$_srcUrlValues[2] 
		        $_OriginalsiteID = "/"+$_srcUrlValues[1]+"/"+$_srcUrlValues[2]
		        $scPath = "/"+$_dn+"."+$scDBName+$_dn+$_tempSiteID
		        $scDisplayUrl = $_dn+"."+$scDBName+$_OriginalsiteID
		        $scUrl = $_OriginalsiteID
				
				$scDBUserName = $null
				$scDBPassword = $null
				#Fetch Source Cresdentials
				if($_SourceType -eq 'Extranet')
				{
				$SourceDetails = $configXmlfile.ConfigSettings.ExtranetSourceDetails
				$scDBUserName = $SourceDetails.UserId
				$scDBPassword = $SourceDetails.HashPassword
				}
				if($_SourceType -eq 'Intranet')
				{
				$SourceDetails = $configXmlfile.ConfigSettings.IntranetSourceDetails
				$scDBUserName = $SourceDetails.UserId
				$scDBPassword = $SourceDetails.HashPassword
				}
				
				
		        
			## ---------------------------------- Load source --------------------------------------------- ###					

$SourceCollection = New-MetalogixSerializableObjectCollection "<IXMLAbleList IXMLAbleType=`"Metalogix.Explorer.NodeCollection, Metalogix.Explorer, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`"><NodeCollection><Location Path=`"`" DisplayUrl=`"$scDisplayUrl`"><Connection NodeType=`"Metalogix.SharePoint.SPSite, Metalogix.SharePoint, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" SharePointVersion=`"15.0.5259.1001`" UnderlyingAdapterType=`"DB`" ShowAllSites=`"True`" AdapterType=`"DB`" Server=`"$scDBServer`" Database=`"$scDBName`" Url=`"$_OriginalsiteID`" HostHeader=`"$_dn`" UserName=`"$scDBUserName`" SavePassword=`"True`" Password=`"$scDBPassword`" /></Location></NodeCollection></IXMLAbleList>" -ErrorAction Stop

			## ------------------------------------------------------------------------------------------ ###	        	

		        $tcPath = ""
		        $tcDisplayUrl = $_targetURL 
		        $tcRootSiteUrl = $_targetURL 
		     
				
			## ---------------------------------- Load target --------------------------------------------- ###
			
$TargetCollection = New-MetalogixSerializableObjectCollection "<IXMLAbleList IXMLAbleType=`"Metalogix.Explorer.NodeCollection, Metalogix.Explorer, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`"><NodeCollection><Location Path=`"`" DisplayUrl=`"$tcDisplayUrl`"><Connection NodeType=`"Metalogix.SharePoint.SPWeb, Metalogix.SharePoint, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" SharePointVersion=`"2147483647.0.0.0`" UnderlyingAdapterType=`"CSOM`" ShowAllSites=`"True`" AdapterType=`"CSOM`" Url=`"$tcRootSiteUrl`" UserName=`"$tcUserName`" SavePassword=`"True`" Password=`"$tcPassword`" ReadOnly=`"False`" AuthenticationType=`"Metalogix.SharePoint.Adapters.CSOM2013.Authentication.Office365StandADFSInitializer`" IsOAuthAuthentication=`"True`"><TokenInformation AzureAppClientId=`"$AzureAppClientIdToken`">$trgOuthToken</TokenInformation></Connection></Location></NodeCollection></IXMLAbleList>" -ErrorAction Stop

		       ## ------------------------------------------------------------------------------------------ ###
				# Run the action
                
		        foreach($Target in $TargetCollection) {		            
		             			$migration = $null
								
						$today = Get-Date
		        		$timeFormat = $today.ToString('MM-dd-yyyy_hh-mm-ss')
						$jobName = [String]$_siteID+"_"+[String]$_batchID+"_"+$timeFormat
				
		                ## -------------------------- Content Migration --------------------------------------------- ###

$migration = $SourceCollection | Copy-MLAllSharePointSiteContent -Target $Target  -CopyPermissionLevels -CopySitePermissions -CopyLists -UpdateSites "Permissions","PermissionLevels" -CopySiteFeatures -MergeSiteFeatures -AutoUpgradeClassicToModernTeamSites "False" -CopyGlobalNavigation -CopyCurrentNavigation -CopyListPermissions -ListFilterExpression ( New-MetalogixSerializableObject "Metalogix.Data.Filters.IFilterExpression" "Metalogix.Actions" "<And IsImplicitGroup=`"True`"><And IsImplicitGroup=`"True`"><And IsImplicitGroup=`"True`"><And IsImplicitGroup=`"True`"><And IsImplicitGroup=`"True`"><And IsImplicitGroup=`"True`"><And IsImplicitGroup=`"True`"><And IsImplicitGroup=`"True`"><And IsImplicitGroup=`"True`"><And IsImplicitGroup=`"True`"><And IsImplicitGroup=`"True`"><And IsImplicitGroup=`"True`"><And IsImplicitGroup=`"True`"><And IsImplicitGroup=`"True`"><And IsImplicitGroup=`"True`"><And IsImplicitGroup=`"True`"><And IsImplicitGroup=`"True`"><And IsImplicitGroup=`"True`"><And IsImplicitGroup=`"True`"><And IsImplicitGroup=`"True`"><FilterExpression><NotContains Property=`"Url`" CaseSensitive=`"True`" BaseFilter=`"False`" Pattern=`"IWConvertedForms`" CultureInfoName=`"en-US`"><AppliesToTypes><Type>Metalogix.SharePoint.SPList</Type></AppliesToTypes></NotContains></FilterExpression><FilterExpression><NotContains Property=`"DisplayName`" CaseSensitive=`"True`" BaseFilter=`"False`" Pattern=`"Site Assets`" CultureInfoName=`"en-US`"><AppliesToTypes><Type>Metalogix.SharePoint.SPList</Type></AppliesToTypes></NotContains></FilterExpression></And><FilterExpression><NotContains Property=`"DisplayName`" CaseSensitive=`"True`" BaseFilter=`"False`" Pattern=`"Engagement Library Status`" CultureInfoName=`"en-US`"><AppliesToTypes><Type>Metalogix.SharePoint.SPList</Type></AppliesToTypes></NotContains></FilterExpression></And><FilterExpression><NotContains Property=`"DisplayName`" CaseSensitive=`"True`" BaseFilter=`"False`" Pattern=`"App Links`" CultureInfoName=`"en-US`"><AppliesToTypes><Type>Metalogix.SharePoint.SPList</Type></AppliesToTypes></NotContains></FilterExpression></And><FilterExpression><NotContains Property=`"DisplayName`" CaseSensitive=`"True`" BaseFilter=`"False`" Pattern=`"Contacts`" CultureInfoName=`"en-US`"><AppliesToTypes><Type>Metalogix.SharePoint.SPList</Type></AppliesToTypes></NotContains></FilterExpression></And><FilterExpression><NotContains Property=`"DisplayName`" CaseSensitive=`"True`" BaseFilter=`"False`" Pattern=`"Site Pages`" CultureInfoName=`"en-US`"><AppliesToTypes><Type>Metalogix.SharePoint.SPList</Type></AppliesToTypes></NotContains></FilterExpression></And><FilterExpression><NotContains Property=`"DisplayName`" CaseSensitive=`"True`" BaseFilter=`"False`" Pattern=`"Web Part Gallery`" CultureInfoName=`"en-US`"><AppliesToTypes><Type>Metalogix.SharePoint.SPList</Type></AppliesToTypes></NotContains></FilterExpression></And><FilterExpression><NotContains Property=`"DisplayName`" CaseSensitive=`"True`" BaseFilter=`"False`" Pattern=`"MicroFeed`" CultureInfoName=`"en-US`"><AppliesToTypes><Type>Metalogix.SharePoint.SPList</Type></AppliesToTypes></NotContains></FilterExpression></And><FilterExpression><NotContains Property=`"DisplayName`" CaseSensitive=`"True`" BaseFilter=`"False`" Pattern=`"Style Library`" CultureInfoName=`"en-US`"><AppliesToTypes><Type>Metalogix.SharePoint.SPList</Type></AppliesToTypes></NotContains></FilterExpression></And><FilterExpression><NotContains Property=`"DisplayName`" CaseSensitive=`"True`" BaseFilter=`"False`" Pattern=`"Master Page Gallery`" CultureInfoName=`"en-US`"><AppliesToTypes><Type>Metalogix.SharePoint.SPList</Type></AppliesToTypes></NotContains></FilterExpression></And><FilterExpression><NotContains Property=`"DisplayName`" CaseSensitive=`"True`" BaseFilter=`"False`" Pattern=`"Form Templates`" CultureInfoName=`"en-US`"><AppliesToTypes><Type>Metalogix.SharePoint.SPList</Type></AppliesToTypes></NotContains></FilterExpression></And><FilterExpression><NotContains Property=`"DisplayName`" CaseSensitive=`"True`" BaseFilter=`"False`" Pattern=`"appdata`" CultureInfoName=`"en-US`"><AppliesToTypes><Type>Metalogix.SharePoint.SPList</Type></AppliesToTypes></NotContains></FilterExpression></And><FilterExpression><NotContains Property=`"DisplayName`" CaseSensitive=`"True`" BaseFilter=`"False`" Pattern=`"Composed Looks`" CultureInfoName=`"en-US`"><AppliesToTypes><Type>Metalogix.SharePoint.SPList</Type></AppliesToTypes></NotContains></FilterExpression></And><FilterExpression><NotContains Property=`"DisplayName`" CaseSensitive=`"True`" BaseFilter=`"False`" Pattern=`"List Template Gallery`" CultureInfoName=`"en-US`"><AppliesToTypes><Type>Metalogix.SharePoint.SPList</Type></AppliesToTypes></NotContains></FilterExpression></And><FilterExpression><NotContains Property=`"DisplayName`" CaseSensitive=`"True`" BaseFilter=`"False`" Pattern=`"Search Config List`" CultureInfoName=`"en-US`"><AppliesToTypes><Type>Metalogix.SharePoint.SPList</Type></AppliesToTypes></NotContains></FilterExpression></And><FilterExpression><NotContains Property=`"DisplayName`" CaseSensitive=`"True`" BaseFilter=`"False`" Pattern=`"Content type publishing error log`" CultureInfoName=`"en-US`"><AppliesToTypes><Type>Metalogix.SharePoint.SPList</Type></AppliesToTypes></NotContains></FilterExpression></And><FilterExpression><NotContains Property=`"DisplayName`" CaseSensitive=`"True`" BaseFilter=`"False`" Pattern=`"Solution Gallery`" CultureInfoName=`"en-US`"><AppliesToTypes><Type>Metalogix.SharePoint.SPList</Type></AppliesToTypes></NotContains></FilterExpression></And><FilterExpression><NotContains Property=`"DisplayName`" CaseSensitive=`"True`" BaseFilter=`"False`" Pattern=`"TaxonomyHiddenList`" CultureInfoName=`"en-US`"><AppliesToTypes><Type>Metalogix.SharePoint.SPList</Type></AppliesToTypes></NotContains></FilterExpression></And><FilterExpression><NotContains Property=`"DisplayName`" CaseSensitive=`"True`" BaseFilter=`"False`" Pattern=`"Theme Gallery`" CultureInfoName=`"en-US`"><AppliesToTypes><Type>Metalogix.SharePoint.SPList</Type></AppliesToTypes></NotContains></FilterExpression></And><FilterExpression><NotContains Property=`"DisplayName`" CaseSensitive=`"True`" BaseFilter=`"False`" Pattern=`"wfpub`" CultureInfoName=`"en-US`"><AppliesToTypes><Type>Metalogix.SharePoint.SPList</Type></AppliesToTypes></NotContains></FilterExpression></And><FilterExpression><NotContains Property=`"DisplayName`" CaseSensitive=`"True`" BaseFilter=`"False`" Pattern=`"Connected Libraries`" CultureInfoName=`"en-US`"><AppliesToTypes><Type>Metalogix.SharePoint.SPList</Type></AppliesToTypes></NotContains></FilterExpression></And>" ) -UpdateLists "Views","Permissions" -CopyCustomizedFormPages -CopyFolderPermissions -CopyListItems -UseAzureOffice365Upload -EncryptAzureMigrationJobs -IsAzurePrivateContainer "True" -ClearRoleAssignments -CopyItemPermissions -OverwriteItems -CheckModifiedDatesForItemsDocuments -ReattachPageLayouts -CopyVersions -CopySubFolders -PreserveItemIDs -PreserveSharePointDocumentIDs -MigrationMode "Custom" -VerboseLog -LogSkippedItems -ForceRefresh -CorrectingLinks -LinkCorrectionScope "SiteCollection" -AllowDBUserWriting -MapGroupsByName -OverwriteGroups -OverrideCheckouts -Transformers ( New-MetalogixSerializableObject "Metalogix.Transformers.TransformerCollection" "Metalogix.Actions" "<TransformerCollection><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.ContentTypeFieldMapper, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.DocumentSetsFolderApplicator, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.ReferencedFolderDataUpdater, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.FolderColumnMapper, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.ManagedMetadataItemValueMapper, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.DeletionPropagator, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.ReferencedListItemDataUpdater, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.DocumentSetsApplicator, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.ContentTypesApplicator, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.ListItemColumnMapper, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.WorkflowDataUpdater, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.PublishingDataUpdater, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.InfopathItemContentXml, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.Commands.PowerShellTransformer``4[[Metalogix.SharePoint.SPList, Metalogix.SharePoint, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03],[Metalogix.SharePoint.Actions.Migration.PasteListAction, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03],[Metalogix.SharePoint.SPListCollection, Metalogix.SharePoint, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03],[Metalogix.SharePoint.SPListCollection, Metalogix.SharePoint, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03]], Metalogix.System.Commands, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"False`"><BeginScriptLocation Type=`"Metalogix.Commands.ScriptFileLocation`">Configuration</BeginScriptLocation><TransformScriptLocation Type=`"Metalogix.Commands.ScriptFileLocation`">None</TransformScriptLocation><EndScriptLocation Type=`"Metalogix.Commands.ScriptFileLocation`">None</EndScriptLocation><BeginTranformScriptFileName Type=`"System.String`" /><TransformScriptFileName Type=`"System.String`" /><EndTransformScriptFileName Type=`"System.String`" /><FullBeginTransformScript Type=`"System.String`">`$FilteredLists = ( 'Converted Forms', 'Site Assets', 'Engagement Library Status', 'App Links', 'Contacts', 'Site Pages', 'Web Part Gallery', 'MicroFeed', 'Style Library', 'Master Page Gallery', 'Form Templates', 'appdata', 'Composed Looks', 'List Template Gallery', 'Search Config List', 'Content type publishing error log', 'Solution Gallery', 'TaxonomyHiddenList', 'Theme Gallery', 'wfpub', 'ConnectedLibraries') 

for(`$i=0; `$i -lt `$sources.Count; `$i++)
{
    `$xmlString = [xml]`$sources[`$i].Xml

    If(`$FilteredLists -contains `$xmlString.List.Title -or `$FilteredLists -contains `$xmlString.List.Name)
   {         
                `$sources.RemoveAt(`$i)
                `$i--

                `$logItem = `$transformer.CreateLogItem(`"TRANSFORMER:: FILTERED OUT LISTS`")
                `$transformer.FireOperationStarted(`$logItem)
                `$logItem.Source = `$sources.ParentWeb.Url
                `$logItem.Target = `$targets.ParentWeb.Url
                `$logItem.ItemName = `$xmlString.List.Title
                `$logItem.Information = `"Lists filtered by Transformer``r``n`" + `$xmlString.List.Title
                `$logItem.Status = `"Completed`"
                `$transformer.FireOperationFinished(`$logItem)
   }
}
</FullBeginTransformScript><FullTransformScript Type=`"System.String`" /><FullEndTransformScript Type=`"System.String`" /></Transformer><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.ListColumnMapper, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.BDCUpdater, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.ListGuidMapper, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.Commands.PowerShellTransformer``4[[Metalogix.SharePoint.SPField, Metalogix.SharePoint, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03],[Metalogix.SharePoint.Actions.Migration.CopySiteColumnsAction, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03],[Metalogix.SharePoint.SPFieldCollection, Metalogix.SharePoint, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03],[Metalogix.SharePoint.SPFieldCollection, Metalogix.SharePoint, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03]], Metalogix.System.Commands, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"False`"><BeginScriptLocation Type=`"Metalogix.Commands.ScriptFileLocation`">None</BeginScriptLocation><TransformScriptLocation Type=`"Metalogix.Commands.ScriptFileLocation`">Configuration</TransformScriptLocation><EndScriptLocation Type=`"Metalogix.Commands.ScriptFileLocation`">None</EndScriptLocation><BeginTranformScriptFileName Type=`"System.String`" /><TransformScriptFileName Type=`"System.String`" /><EndTransformScriptFileName Type=`"System.String`" /><FullBeginTransformScript Type=`"System.String`" /><FullTransformScript Type=`"System.String`">`$dataObject = `$null</FullTransformScript><FullEndTransformScript Type=`"System.String`" /></Transformer><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.SiteFeatureEnforcer, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.MapUsers, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /><Transformer TransformerType=`"Metalogix.SharePoint.Actions.Transform.WebPartsProcessor, Metalogix.SharePoint.Actions, Version=9.2.0.4, Culture=neutral, PublicKeyToken=3b240fac3e39fc03`" ReadOnly=`"True`" /></TransformerCollection>" -Enumerate) -agentdatabase "Data Source=$qDBServer;Initial Catalog=$qDBName;Integrated Security=False;User ID=$qDBUserName;Password=$qDBPassword" -RunRemotely -jobtitle $jobName 

##-JobID $jobName -TriggerJobOnly -Certificate $AgentCertificate
		                ## ------------------------------------------------------------------------------------------ ###
		                
						
		                if($migration -ne $null){ 
							try{
							$sqlConnection = New-Object System.Data.SqlClient.SqlConnection
							$sqlConnection.ConnectionString = Get-SqlConnectionString $orchestratorSQLID $orchestratorSQLPassword $sqlServerInstance $sqlDatabase
							$sqlCommand = New-Object System.Data.SqlClient.SqlCommand

							$sqlCommand.CommandText = $sprocMigrationJobInsert
							$sqlCommand.Connection = $sqlConnection
							$sqlCommand.CommandType = [System.Data.CommandType]::StoredProcedure

							$SiteID = New-Object System.Data.SqlClient.SqlParameter
							$SiteID.ParameterName = "@SiteId";
							$SiteID.Direction = [System.Data.ParameterDirection]::Input
							$SiteID.DbType = [System.Data.DbType]::Int32
							$SiteID.Value = $_siteID
							
							$BatchID = New-Object System.Data.SqlClient.SqlParameter
							$BatchID.ParameterName = "@BatchId";
							$BatchID.Direction = [System.Data.ParameterDirection]::Input
							$BatchID.DbType = [System.Data.DbType]::Int32
							$BatchID.Value = $_batchID
							$JobID = New-Object System.Data.SqlClient.SqlParameter
							$JobID.ParameterName = "@JobId";
							$JobID.Direction = [System.Data.ParameterDirection]::Input
							$JobID.Value = [string]$migration.Split("'")[1]
							$JobTitle = New-Object System.Data.SqlClient.SqlParameter
							$JobTitle.ParameterName = "@JobTitle";
							$JobTitle.Direction = [System.Data.ParameterDirection]::Input
							$JobTitle.Value = $jobName
							$Result = New-Object System.Data.SqlClient.SqlParameter
							$Result.ParameterName = "@Result";
							$Result.Direction = [System.Data.ParameterDirection]::Output
							$Result.DbType = [System.Data.DbType]::Byte
							$sqlCommand.Parameters.Add($SiteID) | Out-Null
							$sqlCommand.Parameters.Add($BatchID)| Out-Null
							$sqlCommand.Parameters.Add($JobID) 	| Out-Null
							$sqlCommand.Parameters.Add($JobTitle) 	| Out-Null
							$sqlCommand.Parameters.Add($Result) | Out-Null
							$sqlConnection.Open()
							$sqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter  
							$sqlAdapter.SelectCommand = $sqlCommand   
							#Creating Dataset  
							$dataSet = New-Object System.Data.DataSet  
							$sqlAdapter.Fill($dataSet)
							$_Resultbit = $Result.Value
							# Close the Sql Connection
							$sqlConnection.Close()
                            $global:PushedCount++
                            							
                            Write-Host Number of sites pushed for migration: $global:PushedCount
							}
							catch {
							 Write-Host $_.Exception.Message -ForegroundColor Red
                                Write-Host "`n"
                                $ExceptionMessage = $("At Line : "+$_.Exception.ErrorRecord.InvocationInfo.ScriptLineNumber+" Char : "+$_.Exception.ErrorRecord.InvocationInfo.OffsetInLine+" Error : "+$_.Exception.Message).Replace('"','`"')
		                        $ExceptionStacktrace = $_.Exception.ErrorRecord.ScriptStackTrace
                                ExceptionLogs-InputParameters $getMigrationSiteDetails $ExceptionMessage $ExceptionStacktrace "JobId insert proc"
		                        $inputParam = $sprocExcepLogsInputParameters,$sprocExcepLogsDynamicParameters
		                        Execute-StrdProcWithParametersReturnTable $orchestratorSQLID $orchestratorSQLPassword $sqlServerInstance $sqlDatabase $sprocExcepLogging $inputParam $null 
							} 
                            finally{
                            $sqlConnection.Dispose()
                            $sqlCommand.Dispose()
                            }
		
						}
						else{
							if($_siteID -ne -1 -and $_batchID -ne -1){
							   ErrorLog $_siteID $_batchID
							}
						}
		            
		        }#end of Foreach
			}
			else{
				Write-Host "No Site is ready for Migration" -ForegroundColor Red
                Write-Host Number of sites pushed for migration: $global:PushedCount
                Start-Sleep -Seconds 120
				break;
			}
		}
		catch {
                Write-Host "$($_.Exception.Message)" -ForegroundColor Red
                Write-Host "`n"
                $ExceptionMessage = $("At Line : "+$_.Exception.ErrorRecord.InvocationInfo.ScriptLineNumber+" Char : "+$_.Exception.ErrorRecord.InvocationInfo.OffsetInLine+" Error : "+$_.Exception.Message).Replace('"','`"')
		        $ExceptionStacktrace = $_.Exception.ErrorRecord.ScriptStackTrace
                ExceptionLogs-InputParameters $getMigrationSiteDetails $ExceptionMessage $ExceptionStacktrace "Fatal error"
		        $inputParam = $sprocExcepLogsInputParameters,$sprocExcepLogsDynamicParameters
		        Execute-StrdProcWithParametersReturnTable $orchestratorSQLID $orchestratorSQLPassword $sqlServerInstance $sqlDatabase $sprocExcepLogging $inputParam $null 
							
				if($_siteID -ne -1 -and $_batchID -ne -1){
				   ErrorLog $_siteID $_batchID
				}
	          }
    }
    catch {
        Write-Host $_.Exception.Message -ForegroundColor Red
        Write-Host "`n"
        $ExceptionMessage = $("At Line : "+$_.Exception.ErrorRecord.InvocationInfo.ScriptLineNumber+" Char : "+$_.Exception.ErrorRecord.InvocationInfo.OffsetInLine+" Error : "+$_.Exception.Message).Replace('"','`"')
		$ExceptionStacktrace = $_.Exception.ErrorRecord.ScriptStackTrace
        ExceptionLogs-InputParameters $getMigrationSiteDetails $ExceptionMessage $ExceptionStacktrace "InitiateNextSiteMigration"
		$inputParam = $sprocExcepLogsInputParameters,$sprocExcepLogsDynamicParameters
		Execute-StrdProcWithParametersReturnTable $orchestratorSQLID $orchestratorSQLPassword $sqlServerInstance $sqlDatabase $sprocExcepLogging $inputParam $null 
		break;
    } 
	 finally {
		$getMigrationSiteDetails = $null;
        $env:Path = $constEnvPath
        Write-Host Number of sites processed for migration: $global:totalSites
        Write-Host Number of sites got fatal during migration: $global:fatalCount
    }   
}

Function ErrorLog($_siteID,$_batchID){
    $sqlQuery_Scheduled = "EXEC "+$sprocStatusChange+" @fk_Site=" + $_siteID +", @fk_Batch=" + $_batchID +", @JobStep=400, @Status=600, @sys_EndActual=1"
    #Update SQL record - Status to Fatal Error
    Execute-SqlQuery $orchestratorSQLID $orchestratorSQLPassword $sqlServerInstance $sqlDatabase $sqlQuery_Scheduled
    Write-Host "Marking this site("$_siteID") as Fatal -Error in SQL DB" -ForegroundColor Red
    Write-Host "`n"
    $global:fatalCount++
    Continue;	
}

do
{
InitiateNextSiteMigration 
Start-Sleep -Seconds 5
}
while($global:GlobalsiteID -ne -1 -and $global:GlobalbatchID -ne -1)