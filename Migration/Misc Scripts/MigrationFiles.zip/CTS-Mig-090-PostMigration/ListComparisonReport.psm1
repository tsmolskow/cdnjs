﻿
function ListCmpRpt_startValidation($siteObj, $sourceContext, $targetContext, $sqlConnection, $SkipLibraries)
{
    #"""
    #This function will start validation for the Source and Target sites
    #"""
    try {
        $cmpReport_tableName = "Mig_Sites_ComparisonReport"
        $migrationJobFailures_tableName = "Mig_Sites_MigrationJobFailures"

        $query_del_CmpPermTable="delete from [$cmpReport_tableName] where fk_Batch=" + [int]$($siteObj.BatchID) + " and fk_Site=" + [int]$($siteObj.fk_site)
        Execute-SqlQuery $sqlConnection $query_del_CmpPermTable

        $ipAddress = (Get-NetIPAddress -AddressFamily IPv4)[0].IPAddress
        Write-Progress -Id 3 -Activity "Starting Comparison Report for site $($siteObj.OriginalURL)" 
        
        $csvResults = ListCmpRpt_CheckData $siteObj $sourceContext $targetContext $SkipLibraries

        if($csvResults -ne $null)
        {
            $dataTable = New-Object System.Data.DataTable
            $dataTable.Columns.Add("ID", "System.Int32") | Out-Null
            $dataTable.Columns.Add("fk_site", "System.Int32") | Out-Null
            $dataTable.Columns.Add("fk_Batch", "System.Int32") | Out-Null
            $dataTable.Columns.Add("Source_WebURL", "System.String") | Out-Null
            $dataTable.Columns.Add("Source_ListTitle", "System.String") | Out-Null
            $dataTable.Columns.Add("Source_ItemCount", "System.Int32") | Out-Null
            $dataTable.Columns.Add("Source_ViewCount", "System.Int32") | Out-Null
            $dataTable.Columns.Add("Target_WebURL", "System.String") | Out-Null
            $dataTable.Columns.Add("Target_ListTitle", "System.String") | Out-Null
            $dataTable.Columns.Add("Target_ItemCount", "System.Int32") | Out-Null
            $dataTable.Columns.Add("Target_ViewCount", "System.Int32") | Out-Null
            $dataTable.Columns.Add("Count_Match", "System.String") | Out-Null
            $dataTable.Columns.Add("Views_Match", "System.String") | Out-Null
            $dataTable.Columns.Add("timestamp", "System.DateTime") | Out-Null
            $dataTable.Columns.Add("Template", "System.String") | Out-Null
                
            $dt_JobFailures = New-Object System.Data.DataTable
            $dt_JobFailures.Columns.Add("fk_site", "System.Int32") | Out-Null
            $dt_JobFailures.Columns.Add("fk_Batch", "System.Int32") | Out-Null
            $dt_JobFailures.Columns.Add("JobID", "System.String") | Out-Null
            $dt_JobFailures.Columns.Add("Status", "System.String") | Out-Null
            $dt_JobFailures.Columns.Add("Operation", "System.String") | Out-Null #Exception raised in post migration comparison reoprt_ipAddress
            $dt_JobFailures.Columns.Add("ItemName", "System.String") | Out-Null               
            $dt_JobFailures.Columns.Add("Source", "System.String") | Out-Null
            $dt_JobFailures.Columns.Add("Target", "System.String") | Out-Null
            $dt_JobFailures.Columns.Add("Information", "System.String") | Out-Null #Exception.Message
            $dt_JobFailures.Columns.Add("Details", "System.String") | Out-Null #Excpetion.StackTrace
            $dt_JobFailures.Columns.Add("ID", "System.Int32") | Out-Null
            $dt_JobFailures.Columns.Add("fk_jobStep", "System.Int32") | Out-Null
            $dt_JobFailures.Columns.Add("DefectStatus", "System.String") | Out-Null

            $fkSite = [int]$($siteObj.fk_site)
            $fkBatch = [int]$($siteObj.BatchID)

            foreach ($res in $csvResults) {
                $dataTable.Rows.Add(0,$($fkSite),$($fkBatch),$($res.Source_WebURL),$($res.Source_ListTitle),$($res.Source_ItemCount),$($res.Source_ViewCount),$($res.Target_WebURL),$($res.Target_ListTitle),$($res.Target_ItemCount),$($res.Target_ViewCount),$($res.Count_Match),$($res.Views_Match),[DBNull]::Value,$($res.BaseType)) | Out-Null
                    
                #Item Count Mismatch
                if ($res.Count_Match -ne "Yes") {
                    $JobFailure_Information = ""
                    if($res.Target_ListTitle -ne "List Missing"){
                        $JobFailure_Information =$($res.Source_ListTitle)+" - "+$($res.Source_ItemCount)+" and "+$($res.Target_ListTitle)+" - "+$($res.Target_ItemCount)
                    }
                    else{
                        $JobFailure_Information =$($res.Source_ListTitle)+" - "+$($res.Source_ListInternalName)+" - "+$($res.Source_ItemCount)+" and "+$($res.Target_ListTitle)+" - "+$($res.Target_ItemCount)
                    }
                    $dt_JobFailures.Rows.Add($($fkSite),$($fkBatch),[DBNull]::Value,'Failed','Comparison Report_'+$ipAddress,'Item Count Mismatch',$($res.Source_WebURL),`
                    $($res.Target_WebURL),$($JobFailure_Information),$($JobFailure_Information),0,425,'Open' )
                }

                <#View Count Mismatch
                if ($res.Views_Match -ne "Yes") {
                    $JobFailure_Information =$($res.Source_ListTitle)+" - "+$($res.Source_ViewCount)+" & "+$($res.Target_ListTitle)+" - "+$($res.Target_ViewCount)
                    $dt_JobFailures.Rows.Add($($fkSite),$($fkBatch),[DBNull]::Value,'Failed','Comparison Report_'+$ipAddress,'View Count Mismatch',$($res.Source_WebURL),`
                    $($res.Target_WebURL),$($JobFailure_Information),$($JobFailure_Information),0,425,'Open')
                }
                #>
            }
                
            #Logging Comparison Report for Item Count and View Count Mismatch
            Execute-BulkSqlQuery $sqlConnection $cmpReport_tableName $dataTable
                
            #Logging Migration Job Failures for Item Count and View Count Mismatch
            Execute-BulkSqlQuery $sqlConnection $migrationJobFailures_tableName $dt_JobFailures
        }
    } 
    catch {
		throw
	}
}

function ListCmpRpt_CheckData($MigrationInfo, $sourceContext, $targetContext, $SkipLibraries)
{
    #"""
    #This function will call the functions for the comparing source and target sites.
    #"""
    $compareResults = $null  
    try
    { 
        $SourceSiteCollectionUrl = $MigrationInfo.OriginalURL.TrimEnd("/")
        $TargetSiteCollectionUrl = $MigrationInfo.TargetURL.TrimEnd("/")
        $sourceSiteType = $MigrationInfo.SourceType
        #Retrieving Source Objects
        $sourceObjects = ListCmpRpt_getDataForSourceURL $SourceSiteCollectionUrl $sourceContext $SkipLibraries
        
        #Retrieving Target Objects
        $targetObjects = ListCmpRpt_getDataForTargetURL $TargetSiteCollectionUrl $targetContext $SkipLibraries

        $targetURLSplit = $TargetSiteCollectionUrl -split '/'
        $FileName = $targetURLSplit[$targetURLSplit.Length -1]

        Write-Host "Comparing the two sites" -ForegroundColor DarkYellow
        #Comparing the source and target sites data
        $compareResults = ListCmpRpt_compareData $sourceObjects $targetObjects $SourceSiteCollectionUrl $TargetSiteCollectionUrl $sourceSiteType
        return $compareResults
    }
    catch
    {
        throw
    }
}

function ListCmpRpt_getDataForSourceURL($SourceURL, $context, $SkipLibraries)
{
    #"""
    #This function will connect to Source Site and call another function to retreive data.
    #"""
    try{

        $web = $context.web
        $site = $context.site
        $context.Load($web)     
        $context.Load($site)  
        ExecuteQueryWithIncrementalRetry $context 3 5000

        if($web.ServerRelativeUrl -ne "/")
        {
            $serverURL = $SourceURL -replace $web.ServerRelativeUrl, ""
        }
        else
        {
        $serverURL = $SourceURL 
        }
        $srcObjs = ListCmpRpt_getSourceDataForWeb $web $context $serverURL $SkipLibraries
        return $srcObjs
    }
    catch
    {
        throw
    }
}

function ListCmpRpt_getSourceDataForWeb($RootWeb ,$Context, $serverURL, $SkipLibraries)
{
    
    #"""
    #This function will retreive data from the Source site.
    #"""
    try{

        $Webs = $RootWeb.Webs 
        $lists = $RootWeb.lists        
        $Context.Load($lists)
        $Context.Load($Webs) 
        ExecuteQueryWithIncrementalRetry $Context 3 5000
 
        $sourceDataObjects = @()
        Write-Host ("Fetching data for Source Site " + $serverURL + $RootWeb.ServerRelativeUrl)

        foreach($list in $Lists)
        { 
            if(!$list.Hidden -and $SkipLibraries -notcontains $list.Title -and  !$list.Title.ToLower().Contains("workflow"))
            {
                $Views = $list.Views
                $Context.Load($Views) 
                ExecuteQueryWithIncrementalRetry $Context 3 5000
            
                $dataObject = New-Object System.Object
                if ($RootWeb.ServerRelativeUrl -ne "/"){
                    $dataObject | Add-Member -MemberType NoteProperty -Name "WebURL" -Value ($serverURL + $RootWeb.ServerRelativeUrl)
                }
                else
                {
                    $dataObject | Add-Member -MemberType NoteProperty -Name "WebURL" -Value ($serverURL)
                }
                $dataObject | Add-Member -MemberType NoteProperty -Name "ListTitle" -Value $list.title
                $dataObject | Add-Member -MemberType NoteProperty -Name "ListInternalName" -Value $list.entitytypename
                $dataObject | Add-Member -MemberType NoteProperty -Name "BaseType" -Value $list.BaseType
                $dataObject | Add-Member -MemberType NoteProperty -Name "ItemCount" -Value $list.ItemCount
                $dataObject | Add-Member -MemberType NoteProperty -Name "ViewCount" -Value $Views.Count
                $sourceDataObjects += $dataObject
            }
        }   

        return $sourceDataObjects; 
    }
    catch
    {
        throw
    }
    
}

function ListCmpRpt_getDataForTargetURL($TargetURL, $ctx, $SkipLibraries)
{      

    #"""
    #This function will connect to Target Site and call another function to retreive data.
    #"""
    try{

        $web = $ctx.web
        $site = $ctx.site
        $ctx.load($web)
        $ctx.load($site)
        ExecuteQueryWithIncrementalRetry $ctx 3 5000

	    $serverURL = $TargetURL -replace $web.ServerRelativeUrl, ""
        return ListCmpRpt_getTargetDataForWeb $web $ctx $serverURL $SkipLibraries
    }
    catch
    {
        throw
    }

}

function ListCmpRpt_getTargetDataForWeb($RootWeb ,$Context, $serverURL, $SkipLibraries)
{

    #"""
    #This function will retreive data from the Target site.
    #"""
    try {
        $Webs = $RootWeb.Webs 
        $lists = $RootWeb.lists
        $Context.Load($lists)
        $Context.Load($Webs)
        ExecuteQueryWithIncrementalRetry $Context 3 5000
 
        $targetDataObjects = @()
        Write-Host ("Fetching data for Target Site:" + $serverURL + $RootWeb.ServerRelativeUrl)
        foreach($list in $Lists)
        {         
            if(!$list.Hidden -and $SkipLibraries -notcontains $list.Title  -and  !$list.Title.ToLower().Contains("workflow"))
            {
                $WF = $list.WorkflowAssociations
                $Views = $list.Views
                $LastModifiedStamp = $list.LastItemModifiedDate
                $LastUserModifiedStamp = $list.LastItemUserModifiedDate
                $Context.Load($WF)     
                $Context.Load($Views)
                ExecuteQueryWithIncrementalRetry $Context 3 5000

                $dataObject = New-Object System.Object
                $dataObject | Add-Member -MemberType NoteProperty -Name "WebURL" -Value ($serverURL + $RootWeb.ServerRelativeUrl)
                $dataObject | Add-Member -MemberType NoteProperty -Name "ListTitle" -Value $list.title
                $dataObject | Add-Member -MemberType NoteProperty -Name "ListInternalName" -Value $list.entitytypename
                $dataObject | Add-Member -MemberType NoteProperty -Name "BaseType" -Value $list.BaseType
                $dataObject | Add-Member -MemberType NoteProperty -Name "ItemCount" -Value $list.ItemCount
                $dataObject | Add-Member -MemberType NoteProperty -Name "ViewCount" -Value $Views.Count
                $targetDataObjects += $dataObject
            }
        }   
        return $targetDataObjects;
    }
    catch {
        throw
    }
}

function ListCmpRpt_compareData($sourceItems, $targetItems, $sourceURL, $targetURL, $sourceSiteType)
{
    #"""
    #This function will compare the two sites
    #"""
    try {
        $compareObjs = @()
        $sourceURL = $sourceURL.TrimEnd("/")
        $targetURL = $targetURL.TrimEnd("/")
    
        foreach($sobj in $sourceItems)
        {        
            $targetItem = $null
            $sobjListInternalName = $sobj.ListInternalName
            
            # charcaters _x002d_ - "-"| _x0021_ - "!" | _x002e_ - "." | OData__x0040_ - "@" | _x0040_ - "@" | _x0028_ - "(" | _x0029_ - ")" | _x002c_ - ","
            if ($sourceSiteType.ToLower().Trim() -eq "intranet" -or $sourceSiteType.ToLower().Trim() -eq "extranet" ){
                $sobjListInternalName = $sobjListInternalName -replace "_x002d_","" -replace "_x0021_", "" -replace "_x002e_","" -replace "OData__x0040_","" -replace "_x0040_", "" -replace "_x0028_","" -replace "_x0029_","" -replace "_x002c_",""
            }
            if($sobj.ListTitle -eq "Shared Documents")
            {
                $targetItem = $targetItems | Where-object {(($_.WebURL -replace $targetURL,"") -eq ($sobj.WebURL -replace $sourceURL,"")) -and ($_.ListTitle -eq "Documents" -or $_.ListTitle -eq $sobj.ListTitle)}
            }
            else
            {
                $targetItem = $targetItems | Where-object {(($_.WebURL -replace $targetURL,"") -eq ($sobj.WebURL -replace $sourceURL,"")) -and $_.ListInternalName -eq $sobjListInternalName}
            }
            if($targetItem -ne $null)
            {
                $dataObject = New-Object System.Object
                $dataObject | Add-Member -MemberType NoteProperty -Name "Source_WebURL" -Value $sobj.WebURL
                $dataObject | Add-Member -MemberType NoteProperty -Name "Source_ListTitle" -Value $sobj.ListTitle
                $dataObject | Add-Member -MemberType NoteProperty -Name "Source_ListInternalName" -Value $sobj.ListInternalName
                $dataObject | Add-Member -MemberType NoteProperty -Name "Source_ItemCount" -Value $([int][int]$sobj.ItemCount)
                $dataObject | Add-Member -MemberType NoteProperty -Name "Source_ViewCount" -Value $([int][int]$sobj.ViewCount)
                $dataObject | Add-Member -MemberType NoteProperty -Name "Target_WebURL" -Value $targetItem.WebURL
                $dataObject | Add-Member -MemberType NoteProperty -Name "Target_ListTitle" -Value $targetItem.ListTitle
                $dataObject | Add-Member -MemberType NoteProperty -Name "Target_ItemCount" -Value $([int]$targetItem.ItemCount)
                $dataObject | Add-Member -MemberType NoteProperty -Name "Target_ViewCount" -Value $([int]$targetItem.ViewCount)

                if($sobj.ItemCount -le $targetItem.ItemCount)
                {
                    $dataObject | Add-Member -MemberType NoteProperty -Name "Count_Match" -Value "Yes"
                }
                else
                {
                    $dataObject | Add-Member -MemberType NoteProperty -Name "Count_Match" -Value "No"
                }     
            
                if($sobj.ViewCount -le $targetItem.ViewCount+1)
                {
                    $dataObject | Add-Member -MemberType NoteProperty -Name "Views_Match" -Value "Yes"
                }
                else
                {
                    $dataObject | Add-Member -MemberType NoteProperty -Name "Views_Match" -Value "No"
                } 

                if($sobj.BaseType -eq "DocumentLibrary")
                {
                    $dataObject | Add-Member -MemberType NoteProperty -Name "BaseType" -Value $sobj.BaseType
                }
                else
                {
                    $dataObject | Add-Member -MemberType NoteProperty -Name "BaseType" -Value "List"
                } 

                $compareObjs += $dataObject
            }
            else
            {
                $dataObject = New-Object System.Object
                $dataObject | Add-Member -MemberType NoteProperty -Name "Source_WebURL" -Value $sobj.WebURL
                $dataObject | Add-Member -MemberType NoteProperty -Name "Source_ListTitle" -Value $sobj.ListTitle
                $dataObject | Add-Member -MemberType NoteProperty -Name "Source_ListInternalName" -Value $sobj.ListInternalName
                $dataObject | Add-Member -MemberType NoteProperty -Name "Source_ItemCount" -Value $([int]$sobj.ItemCount)
                $dataObject | Add-Member -MemberType NoteProperty -Name "Source_ViewCount" -Value $([int]$sobj.ViewCount)
                $dataObject | Add-Member -MemberType NoteProperty -Name "Target_WebURL" -Value "List Missing"
                $dataObject | Add-Member -MemberType NoteProperty -Name "Target_ListTitle" -Value "List Missing"
                $dataObject | Add-Member -MemberType NoteProperty -Name "Target_ItemCount" -Value $([int]"0")
                $dataObject | Add-Member -MemberType NoteProperty -Name "Target_ViewCount" -Value $([int]"0")
                $dataObject | Add-Member -MemberType NoteProperty -Name "Count_Match" -Value "List Missing"
                $dataObject | Add-Member -MemberType NoteProperty -Name "Views_Match" -Value "List Missing"
                $dataObject | Add-Member -MemberType NoteProperty -Name "BaseType" -Value $sobj.BaseType
                            
                $compareObjs += $dataObject
            }
        }
        return $compareObjs
    }
    catch {
        throw
    }
}
