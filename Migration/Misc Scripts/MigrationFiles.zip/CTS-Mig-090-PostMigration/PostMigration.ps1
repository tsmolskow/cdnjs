﻿Get-Module | Remove-Module -Force
Clear-Host
#Load XML Config File
$scriptRoot = Split-Path $MyInvocation.MyCommand.Path -Parent
$parentRoot = (Get-Item $scriptRoot).Parent.FullName
$configfolder = Join-Path $parentRoot.ToLower().Replace('\cts\','\ey\') "CTS-Mig-0Settings"
$xmlConfigPath =  Join-Path $configfolder "ConfigurationSettings.xml"
$configXmlfile = [xml]$(Get-Content $xmlConfigPath)

#Fetching SQL Server Details
$sqlServerInstance = $configXmlfile.ConfigSettings.SqlSettings.SqlDbServer
$sqlDatabase = $configXmlfile.ConfigSettings.SqlSettings.SqlDatabase

#StoredProcedure - Fetch Pre-Migration sites
$sprocSitesForPostMigration = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.GetPostMigrationSites.Name
$sprocInputParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.GetPostMigrationSites.InputParameters
$sprocOutputParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.GetPostMigrationSites.OutputParameters

#StoredProcedure - Change Pre-Migration status
$sprocChangePreMigrationStatus = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ChangePreMigrationStatus.Name

#StoredProcedure - Change Status
$sprocStatusChange = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ChangeStatus.Name
$sprocStatusChangeInputParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ChangeStatus.InputParameters
$sprocStatusChangeDynamicParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ChangeStatus.DynamicInputParameters

#StoredProcedure - Exception logging
$sprocExcepLogging = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ExceptionLogging.Name
$sprocExcepLogsInputParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ExceptionLogging.InputParameters
$sprocExcepLogsDynamicParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ExceptionLogging.DynamicInputParameters

#Load Module files - Reusable methods
$modulesFolder = Join-Path $parentRoot $configXmlfile.ConfigSettings.CommonSettings.Modules.Name
$modulesPath = Join-Path $modulesFolder $configXmlfile.ConfigSettings.CommonSettings.Modules.Value
Import-Module -Name $modulesPath

Import-Module -Name $(Join-Path $scriptRoot "ListComparisonReport.psm1")

#Load SharePoint CSOM Assemblies
$spoModulesRefPath = $configXmlfile.ConfigSettings.CommonSettings.SPOnlineReferencesPath.Value
Import-Module -Name $spoModulesRefPath -DisableNameChecking
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client")
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client.Runtime")

#Load SharePoint PnP PowerShell Online Assemblies
$spPnPPSModulesRefPath = $configXmlfile.ConfigSettings.CommonSettings.SharePointPnPPowerShellOnline.Value
Import-Module -Name $spPnPPSModulesRefPath -DisableNameChecking

#Fetch SQL and SharePoint Credentials from Azure KeyVault
$azureAccountsPsd = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.AzureAccountsPsd
$azureKeyvaultsPsd = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.AzureKeyvaultsPsd
Import-Module -Name $azureAccountsPsd
Import-Module -Name $azureKeyvaultsPsd

$azAppId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.ApplicationId
$azTenantId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.TenantId
$azCertificates = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.CertificateThumbprint
$azVault = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.VaultName
$azOrchDbUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.OrchestrationUserId
$azOrchDbPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.OrchestrationPassword
$azSourceIntranetUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceIntranetUserId
$azSourceIntranetPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceIntranetPassword
$azSourceSpoUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceSPOUserId
$azSourceSpoPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceSPOPassword
$azSourceExtranetUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceExtranetUserId
$azSourceExtranetPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceExtranetPassword
$azTargetUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.TargetUserId
$azTargetPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.TargetPassword

function SetLibraryCheckOutRequirement ($pnpConn, $Enable, $cmdbSqlConn, $siteObj) {
    try {
	    #get list of libraries to exclude
	    $sql="select LibraryToExclude from vw_PreMig_GetLibrariesToExclude"
        $libraries = Get-ContentFromSqlQuery $cmdbSqlConn $sql

        #Get the Document Libraries
        $sqlQuery = "exec sp_postmig_get_checkout_status_of_documentlibraries @SiteId="+$siteObj.fk_Site+", @BatchId="+$siteObj.BatchID
        $dbCheckoutEnabledlibraries = Get-ContentFromSqlQuery $cmdbSqlConn $sqlQuery
	    $DocumentLibraries = Get-PnPList -Connection $pnpConn | Where-Object {$_.BaseTemplate -eq 101 -and $_.Hidden -eq $false} #Or $_.BaseType -eq "DocumentLibrary"
	 
	    #Get Document Libraries Name, Default URL and Number of Items
	    #$DocumentLibraries | Select Title, DefaultViewURL, ItemCount
	    foreach ($spLibrary in $DocumentLibraries) {
    		    $ret=$libraries | Where-Object {$_.LibraryToExclude -eq $spLibrary.Title }
                $ret1=$dbCheckoutEnabledlibraries | Where-Object {$_.DocLibDisplayName -eq $spLibrary.Title }
		    if (!$ret -and $ret1 -and !$spLibrary.ForceCheckout) {
				    #Write-Feedback "...recording library setting and changing status"
				    Set-PnPList -Identity $spLibrary.Title -ForceCheckout $Enable
				    Invoke-PnPQuery -RetryWait 10 -RetryCount 5
                    $postMigrationUpdateLibraryCheckOutStatus="sp_postmig_updatecheckout_status_of_documentlibrary"
                    $docLibQuery = "EXEC $postMigrationUpdateLibraryCheckOutStatus @id=$($ret1.id), @SiteId=$($siteObj.fk_site), @BatchId=$($siteObj.BatchID),@Result=0"                 
                    Execute-SqlQuery $cmdbSqlConn $docLibQuery
			    }
		    }
    }
    catch {
        throw
    }
}

try {    
    #Fetch SQL DB Credentials from Azure Keyvault
    $dbCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azOrchDbUserId $azOrchDbPassword    
    $secureDbPassword = $dbCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force
  
    #Fetch Source Sites Credentials from Azure keyvault
    $sourceCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azSourceIntranetUserId $azSourceIntranetPassword
    $sourceSecurePassword = $sourceCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force

    #Fetch Source Extranet Sites Credentials from Azure keyvault
    $sourceExtranetCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azSourceExtranetUserId $azSourceExtranetPassword     
    $sourceExtranetSecurePassword = $sourceExtranetCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force

    #Fetch Source SPO Sites Credentials from Azure keyvault
    if(!([String]::IsNullOrEmpty($azSourceSpoUserId)) -and !([String]::IsNullOrEmpty($azSourceSpoPassword))) {
        $sourceSpoCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azSourceSpoUserId $azSourceSpoPassword     
        $sourceSpoSecurePassword = $sourceSpoCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force
    }

    #Fetch Target Sites Credentials from Azure keyvault
    $targetCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azTargetUserId $azTargetPassword     
    $targetSecurePassword = $targetCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force
    

    Write-Host "------------------------------Post-Migration process Starts------------------------------`n"
        
    #Build SQL Connection
    $sqlConnection = New-Object System.Data.SqlClient.SqlConnection
	$sqlConnection.ConnectionString = Get-SqlConnectionString $dbCredentials.LoginId $secureDbPassword $sqlServerInstance $sqlDatabase
    $sqlConnection.Open()

    $flag = $true        
    while($flag) {
         try {
            if($sqlConnection.State -ne "Open") {
                $sqlConnection.Open()
            }

            $getPostMigrationSiteDetails = $null
            $flagNoData = $true
            while($flagNoData) {

                #Fetch Sites Ready for Post Migration            
                $getPostMigrationSiteDetails = Execute-StrdProcWithParameters $sqlConnection $sprocSitesForPostMigration $sprocInputParameters $sprocOutputParameters
                if($getPostMigrationSiteDetails -eq $null){
                    Write-Host "Null Object Returned. Waiting for 5 seconds" -ForegroundColor Red
                    Start-Sleep -Seconds 5
                }
                else { 
                $flagNoData = $false
                }
            }
            
            #if(!([String]::IsNullOrEmpty($getPostMigrationSiteDetails.OriginalURL)) -and !([String]::IsNullOrEmpty($getPostMigrationSiteDetails.TargetURL))) {
            if(!($getPostMigrationSiteDetails.SiteID -eq "-1" -and $getPostMigrationSiteDetails.BatchID -eq -1)) {

                Write-Host "Performing PostMigration on Site:" $getPostMigrationSiteDetails.TargetURL "`n" -ForegroundColor Green
                
                $migrationJobFailures_tableName = "Mig_Sites_MigrationJobFailures"
                $query_update_Job_Failure_Information="update [$migrationJobFailures_tableName] set DefectStatus='Closed' where fk_jobStep=425 and fk_Batch=" + [int]$($getPostMigrationSiteDetails.BatchID) + " and fk_Site=" + [int]$($getPostMigrationSiteDetails.fk_site)
                Execute-SqlQuery $sqlConnection $query_update_Job_Failure_Information


                #Get Context for Source and Target sites
                $sourceUserId = $null
                if($getPostMigrationSiteDetails.SourceType.ToLower().Trim() -eq "intranet") {
                    $sourceUserId = $sourceCredentials.LoginId
                    $sourceContext = Get-SPContext $getPostMigrationSiteDetails.OriginalURL $sourceUserId $sourceSecurePassword
                }
                elseif($getPostMigrationSiteDetails.SourceType.ToLower().Trim() -eq "extranet") {
                    $sourceUserId = $sourceExtranetCredentials.LoginId
                    $sourceContext = Get-SPContext $getPostMigrationSiteDetails.OriginalURL $sourceUserId $sourceExtranetSecurePassword
                }                
                else {
                    $sourceUserId = $sourceSpoCredentials.LoginId
                    $sourceContext = Get-SPContext $getPostMigrationSiteDetails.OriginalURL $sourceUserId $sourceSpoSecurePassword
                }

                $targetContext = Get-SPContext $getPostMigrationSiteDetails.TargetURL $targetCredentials.LoginId $targetSecurePassword
                
                #Get PnP Connection
                $targetPnPCredentials = New-Object System.Management.Automation.PSCredential($targetCredentials.LoginId ,$targetSecurePassword)  
                $targetPnPConnection = Connect-PnPOnline -Url $getPostMigrationSiteDetails.TargetURL -Credentials $targetPnPCredentials -ReturnConnection -RetryCount 5 -RetryWait 10

                #Step 1 - Remove Hide from delve / Search
                try {
				    Set-PnPWeb -NoCrawl:$false -Connection $targetPnPConnection
                } 
                catch {
                    $exception = $($_.Exception.Message).Replace('"', '`"')
                    if($exception.ToLower().contains("nocrawl")){
                        Write-Host $_.Exception.Message -ForegroundColor Red
                    }
                    else {
                        throw
                    }
                }
                

                #Step 2 - remove 'require checkout option' from all doc libraries (record in db if any changes were made to the libraries)
                if(!$getPostMigrationSiteDetails.OriginalURL.ToLower().contains("sharepoint.com")) 
                {
				    SetLibraryCheckOutRequirement $targetPnPConnection $true $sqlConnection $getPostMigrationSiteDetails
                }

                #Step 3 - run comparison report
                $qryLibraryToExclude = "SELECT [LibraryToExclude] FROM [dbo].[MigDef_LibrariesToExclude] order by [LibraryToExclude]"
                $SkipLibrariesResult = Get-ContentFromSqlQuery $sqlConnection $qryLibraryToExclude
                $SkipLibraries = @()
                Foreach($item in $SkipLibrariesResult)
                {
                    $SkipLibraries= $SkipLibraries + $($item.LibraryToExclude)
                }

                ListCmpRpt_startValidation $getPostMigrationSiteDetails $sourceContext $targetContext $sqlConnection $SkipLibraries

                #Update SQL record - Status to Post-Migration complete
                ChangeStatus-InputParameters $getPostMigrationSiteDetails.fk_Site $getPostMigrationSiteDetails.BatchID $sprocStatusChangeDynamicParameters "425" "400" "Post Migration completed"
                $changeStatusParameters = $sprocStatusChangeInputParameters,$sprocStatusChangeDynamicParameters
                $ret = Execute-StrdProcWithParameters $sqlConnection $sprocStatusChange $changeStatusParameters $null                                    
                
                #Update SQL record - Status to Migration Scheduled 
                ChangeStatus-InputParameters $getPostMigrationSiteDetails.fk_Site $getPostMigrationSiteDetails.BatchID $sprocStatusChangeDynamicParameters "450" "1000" "Ready for Remediation"
                $changeStatusParameters = $sprocStatusChangeInputParameters,$sprocStatusChangeDynamicParameters
                $ret = Execute-StrdProcWithParameters $sqlConnection $sprocStatusChange $changeStatusParameters $null                                    
            }
            else {
                Write-Host "No sites found for Post-Migration! `n" -ForegroundColor Yellow
                $flag = $false
            }
        }
        catch {            
            Write-Host $_.Exception.Message -ForegroundColor Red
            $exception = $($_.Exception.Message).Replace('"', '`"')
            #Fatal error logs            
            ChangeStatus-InputParameters $getPostMigrationSiteDetails.fk_Site $getPostMigrationSiteDetails.BatchID $sprocStatusChangeDynamicParameters "425" "600" $exception
            $parameters = $sprocStatusChangeInputParameters,$sprocStatusChangeDynamicParameters
            $ret = Execute-StrdProcWithParameters $sqlConnection $sprocStatusChange $parameters $null
                            
            #Exception logs
            ExceptionLogs-InputParameters $getPostMigrationSiteDetails $sprocExcepLogsDynamicParameters "425" "Automated PostMigration: " $exception $($_.ScriptStackTrace)
            $inputParameters = $sprocExcepLogsInputParameters,$sprocExcepLogsDynamicParameters
            $ret = Execute-StrdProcWithParameters $sqlConnection $sprocExcepLogging $inputParameters $null

            if($exception.ToLower().contains("partner returned a bad sign-in name or password error")) {
                $flag = $false
            }
        }
        finally {           
            $sourceContext = $null
            $targetContext = $null
        }
    }
        
    #Dispose SqlConnection
    $sqlConnection.Dispose()
}
catch {
    Write-Host "Exception in fetching Azure Keyvault details `n" $_.Exception.Message -ForegroundColor Red
}

Write-Host "------------------------------Post-Migration process Ends------------------------------"