﻿Get-Module | Remove-Module -Force
Clear-Host
#Load XML Config File
$scriptRoot = Split-Path $MyInvocation.MyCommand.Path -Parent
$parentRoot = (Get-Item $scriptRoot).Parent.FullName
$configfolder = Join-Path $parentRoot.ToLower().Replace('\cts\','\ey\') "CTS-Mig-0Settings"
$xmlConfigPath =  Join-Path $configfolder "ConfigurationSettings.xml"
$configXmlfile = [xml]$(Get-Content $xmlConfigPath)

#Fetching SQL Server Details
$sqlServerInstance = $configXmlfile.ConfigSettings.SqlSettings.SqlDbServer
$sqlDatabase = $configXmlfile.ConfigSettings.SqlSettings.SqlDatabase

#StoredProcedure - Fetch Remediation sites
$sprocSitesForRemediation = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.GetRemediationSites.Name
$sprocInputParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.GetRemediationSites.InputParameters
$sprocOutputParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.GetRemediationSites.OutputParameters

#StoredProcedure - Change Status
$sprocStatusChange = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ChangeStatus.Name
$sprocStatusChangeInputParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ChangeStatus.InputParameters
$sprocStatusChangeDynamicParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ChangeStatus.DynamicInputParameters

#StoredProcedure - PostMigration for applying Permissions
$sprocSitesForPostMigration = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.GetPostMigration_PermissionDetails.Name

#StoredProcedure - Exception logging
$sprocExcepLogging = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ExceptionLogging.Name
$sprocExcepLogsInputParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ExceptionLogging.InputParameters
$sprocExcepLogsDynamicParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ExceptionLogging.DynamicInputParameters

#Load ConsoleApp exe file for migrating WorkflowHistory List, QuickLaunch and Connected Lists/Library Items
$consoleAppExeFileContainer = Join-Path  $scriptRoot $configXmlfile.ConfigSettings.ConsoleAppUtilities.RemediationUtility.Folder
$consoleAppExeFile = $configXmlfile.ConfigSettings.ConsoleAppUtilities.RemediationUtility.Value
$consoleAppExeFilePath = Join-Path  $consoleAppExeFileContainer $consoleAppExeFile

#Load Module files - Reusable methods, Apply Permissions
$modulesFolder = Join-Path $parentRoot $configXmlfile.ConfigSettings.CommonSettings.Modules.Name
$modulesPath = Join-Path $modulesFolder $configXmlfile.ConfigSettings.CommonSettings.Modules.Value
$applyPermissionsModules = Join-Path $scriptRoot $configXmlfile.ConfigSettings.CommonSettings.ApplyPermissions.Value
Import-Module -Name $modulesPath
Import-Module -Name $applyPermissionsModules

#Load SharePoint CSOM Assemblies
$spoModulesRefPath = $configXmlfile.ConfigSettings.CommonSettings.SPOnlineReferencesPath.Value
Import-Module -Name $spoModulesRefPath -DisableNameChecking
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client")
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client.Runtime")

#Load SharePoint PnP PowerShell Online Assemblies
$spPnPPSModulesRefPath = $configXmlfile.ConfigSettings.CommonSettings.SharePointPnPPowerShellOnline.Value
Import-Module -Name $spPnPPSModulesRefPath -DisableNameChecking

#Fetch SQL and SharePoint Credentials from Azure KeyVault
$azureAccountsPsd = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.AzureAccountsPsd
$azureKeyvaultsPsd = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.AzureKeyvaultsPsd
Import-Module -Name $azureAccountsPsd
Import-Module -Name $azureKeyvaultsPsd

$azAppId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.ApplicationId
$azTenantId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.TenantId
$azCertificates = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.CertificateThumbprint
$azVault = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.VaultName
$azOrchDbUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.OrchestrationUserId
$azOrchDbPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.OrchestrationPassword
$azSourceIntranetUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceIntranetUserId
$azSourceIntranetPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceIntranetPassword
$azSourceSpoUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceSPOUserId
$azSourceSpoPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceSPOPassword
$azSourceExtranetUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceExtranetUserId
$azSourceExtranetPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceExtranetPassword
$azTargetUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.TargetUserId
$azTargetPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.TargetPassword       

try {    
    #Fetch SQL DB Credentials from Azure Keyvault
    $dbCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azOrchDbUserId $azOrchDbPassword    
    $secureDbPassword = $dbCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force
  
    #Fetch Source Sites Credentials from Azure keyvault
    $sourceCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azSourceIntranetUserId $azSourceIntranetPassword
    $sourceSecurePassword = $sourceCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force

    #Fetch Source Extranet Sites Credentials from Azure keyvault
    $sourceExtranetCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azSourceExtranetUserId $azSourceExtranetPassword     
    $sourceExtranetSecurePassword = $sourceExtranetCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force

    #Fetch Source SPO Sites Credentials from Azure keyvault
    if(!([String]::IsNullOrEmpty($azSourceSpoUserId)) -and !([String]::IsNullOrEmpty($azSourceSpoPassword))) {
        $sourceSpoCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azSourceSpoUserId $azSourceSpoPassword     
        $sourceSpoSecurePassword = $sourceSpoCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force
    }

    #Fetch Target Sites Credentials from Azure keyvault
    #$targetCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azTargetUserId $azTargetPassword     
    $targetCredentials = @{
                                "LoginId" = "P.AUSPODPMIGP.5@ey.net"
                                "LoginPassword" = "MVausASK@+AIVHvV"
                              }     
    $targetSecurePassword = $targetCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force
        
    Write-Host "------------------------------Remediation process Starts------------------------------`n"
        
    #Build SQL Connection
    $sqlConnection = New-Object System.Data.SqlClient.SqlConnection
	$sqlConnection.ConnectionString = Get-SqlConnectionString $dbCredentials.LoginId $secureDbPassword $sqlServerInstance $sqlDatabase
    $sqlConnection.Open()

    $csvPath = Join-Path $scriptRoot "SiteDetails.csv"

    $flag = $true        
    while($flag) {
        try {
            if($sqlConnection.State -ne "Open") {
                $sqlConnection.Open()
            }
            
            $siteDetails = Import-csv $csvPath

            foreach($getRemediationSiteDetails in $siteDetails)
            {
                #if(!([String]::IsNullOrEmpty($getRemediationSiteDetails.OriginalURL)) -and !([String]::IsNullOrEmpty($getRemediationSiteDetails.TargetURL))) {
                if(!($getRemediationSiteDetails.SiteID -eq -1 -and $getRemediationSiteDetails.BatchID -eq -1)) {
                    Write-Host "Performing Remediation on Site:" $getRemediationSiteDetails.TargetURL "`n" -ForegroundColor Green

                    $jobFailuresTable = "Mig_Sites_MigrationJobFailures"
                    $query_UpdateJobFailuresTable = "update [$jobFailuresTable] set DefectStatus='Closed' where fk_jobStep=450 and fk_Batch=" + $([int]$getRemediationSiteDetails.BatchID) + " and fk_Site=" + $([int]$getRemediationSiteDetails.SiteID)
                    Execute-SqlQuery $sqlConnection $query_UpdateJobFailuresTable
                
                    #Get Context for Source and Target sites
                    $sourceUserId = $null
                    $sourcePassword = $null
                    if($getRemediationSiteDetails.SourceType.ToLower().Trim().Contains("intranet")) {
                        $sourceUserId = $sourceCredentials.LoginId
                        $sourcePassword = $sourceCredentials.LoginPassword
                        #$sourceContext = Get-SPContext $getRemediationSiteDetails.OriginalURL $sourceUserId $sourceSecurePassword
                    }
                    elseif($getRemediationSiteDetails.SourceType.ToLower().Trim().Contains("extranet")) {
                        $sourceUserId = $sourceExtranetCredentials.LoginId
                        $sourcePassword = $sourceExtranetCredentials.LoginPassword
                        #$sourceContext = Get-SPContext $getRemediationSiteDetails.OriginalURL $sourceUserId $sourceExtranetSecurePassword
                    }                
                    else {
                        $sourceUserId = $sourceSpoCredentials.LoginId
                        $sourcePassword = $sourceSpoCredentials.LoginPassword
                        #$sourceContext = Get-SPContext $getRemediationSiteDetails.OriginalURL $sourceUserId $sourceSpoSecurePassword
                    }                                   
                            
                    #target Context
                    $targetContext = Get-SPContext $getRemediationSiteDetails.TargetURL $targetCredentials.LoginId $targetSecurePassword
                
                    ApplyPermissionsOnTarget $targetContext $getRemediationSiteDetails $sprocSitesForPostMigration $sqlConnection
                }
                else {
                    Write-Host "No sites found for Remediation! `n" -ForegroundColor Yellow
                    $flag = $false                
                }
            }
        }
        catch {
            Write-Host $_.Exception.Message -ForegroundColor Red            
        }
        finally {           
            #$sourceContext.Dispose()
            $targetContext.Dispose()
        }
    }

    #Dispose SqlConnection
    $sqlConnection.Dispose()
}
catch {
    Write-Host "Exception in fetching Azure Keyvault details `n" $_.Exception.Message -ForegroundColor Red
}

Write-Host "------------------------------Remediation process Ends------------------------------"
