﻿Get-Module | Remove-Module -Force
Clear-Host
#Load XML Config File
$scriptRoot = Split-Path $MyInvocation.MyCommand.Path -Parent
$parentRoot = (Get-Item $scriptRoot).Parent.FullName
$configfolder = Join-Path $parentRoot.ToLower().Replace('\cts\','\ey\') "CTS-Mig-0Settings"
$xmlConfigPath =  Join-Path $configfolder "ConfigurationSettings.xml"
$configXmlfile = [xml]$(Get-Content $xmlConfigPath)

#Fetching SQL Server Details
$sqlServerInstance = $configXmlfile.ConfigSettings.SqlSettings.SqlDbServer
$sqlDatabase = $configXmlfile.ConfigSettings.SqlSettings.SqlDatabase

#StoredProcedure - Fetch Remediation sites
$sprocSitesForRemediation = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.GetRemediationSites.Name
$sprocInputParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.GetRemediationSites.InputParameters
$sprocOutputParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.GetRemediationSites.OutputParameters

#StoredProcedure - Change Status
$sprocStatusChange = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ChangeStatus.Name
$sprocStatusChangeInputParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ChangeStatus.InputParameters
$sprocStatusChangeDynamicParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ChangeStatus.DynamicInputParameters

#StoredProcedure - PostMigration for applying Permissions
$sprocSitesForPostMigration = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.GetPostMigration_PermissionDetails.Name

#StoredProcedure - Exception logging
$sprocExcepLogging = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ExceptionLogging.Name
$sprocExcepLogsInputParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ExceptionLogging.InputParameters
$sprocExcepLogsDynamicParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ExceptionLogging.DynamicInputParameters

#Load ConsoleApp exe file for migrating WorkflowHistory List, QuickLaunch and Connected Lists/Library Items
$consoleAppExeFileContainer = Join-Path  $scriptRoot $configXmlfile.ConfigSettings.ConsoleAppUtilities.RemediationUtility.Folder
$consoleAppExeFile = $configXmlfile.ConfigSettings.ConsoleAppUtilities.RemediationUtility.Value
$consoleAppExeFilePath = Join-Path  $consoleAppExeFileContainer $consoleAppExeFile

#Load Module files - Reusable methods, Apply Permissions
$modulesFolder = Join-Path $parentRoot $configXmlfile.ConfigSettings.CommonSettings.Modules.Name
$modulesPath = Join-Path $modulesFolder $configXmlfile.ConfigSettings.CommonSettings.Modules.Value
$applyPermissionsModules = Join-Path $scriptRoot $configXmlfile.ConfigSettings.CommonSettings.ApplyPermissions.Value
Import-Module -Name $modulesPath
Import-Module -Name $applyPermissionsModules

#Load SharePoint CSOM Assemblies
$spoModulesRefPath = $configXmlfile.ConfigSettings.CommonSettings.SPOnlineReferencesPath.Value
Import-Module -Name $spoModulesRefPath -DisableNameChecking
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client")
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client.Runtime")

#Load SharePoint PnP PowerShell Online Assemblies
$spPnPPSModulesRefPath = $configXmlfile.ConfigSettings.CommonSettings.SharePointPnPPowerShellOnline.Value
Import-Module -Name $spPnPPSModulesRefPath -DisableNameChecking

#Fetch SQL and SharePoint Credentials from Azure KeyVault
$azureAccountsPsd = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.AzureAccountsPsd
$azureKeyvaultsPsd = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.AzureKeyvaultsPsd
Import-Module -Name $azureAccountsPsd
Import-Module -Name $azureKeyvaultsPsd

$azAppId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.ApplicationId
$azTenantId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.TenantId
$azCertificates = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.CertificateThumbprint
$azVault = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.VaultName
$azOrchDbUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.OrchestrationUserId
$azOrchDbPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.OrchestrationPassword
$azSourceIntranetUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceIntranetUserId
$azSourceIntranetPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceIntranetPassword
$azSourceSpoUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceSPOUserId
$azSourceSpoPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceSPOPassword
$azSourceExtranetUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceExtranetUserId
$azSourceExtranetPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceExtranetPassword
$azTargetUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.TargetUserId
$azTargetPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.TargetPassword
       
#Replace broken links
function Replace-BrokenLinks {
    Param(
        [Parameter(Mandatory = $true)] $itemsCol,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $userId,
        [Parameter(Mandatory = $true)] $password
    )
    try {
        $credentials = New-Object System.Management.Automation.PSCredential($userId,$password)        
        Connect-PnPOnline -Url $itemsCol.TargetURL -Credentials $credentials
        $pagesCol = Get-PnPListItem -List 'Site Pages'

        $conteneEditorType= '<TypeName>Microsoft.SharePoint.WebPartPages.ContentEditorWebPart</TypeName>'
        $summaryLinksType = 'name="Microsoft.SharePoint.Publishing.WebControls.SummaryLinkWebPart'
        $scriptEditorType='<type name="Microsoft.SharePoint.WebPartPages.ScriptEditorWebPart'
        
        $pagesCounter = 0
        foreach($page in $pagesCol) {            
            $pagesCounter++
            #Write-Host "Processing page no:" $pagesCounter " — Out of total pages" $pagesCol.Count " — Page title:" $page["FileLeafRef"] -ForegroundColor Cyan                        
                                
            $pageRelativeURL = $page["FileRef"]
            $clientContext = Get-PnPContext
            $currentPage = Get-PnPFile -Url $pageRelativeURL -AsListItem
            $pageFile = $currentPage.File
            $clientContext.Load($pageFile)
            #$clientContext.ExecuteQuery()
            ExecuteQueryWithIncrementalRetry $clientContext 3 5000

            if($pageFile.CheckOutType -eq [Microsoft.SharePoint.Client.CheckOutType]::Online) {
                Set-PnPFileCheckedIn -Url $pageRelativeURL
            }

            $webpartsCol = Get-PnPWebPart -ServerRelativePageUrl $pageRelativeURL
            $webpartsCount = 0
            $flag = $false
            foreach ($webpart in $webpartsCol) {
                $webpartTitle = $webpart.WebPart.Properties.FieldValues.Title
                [int]$zoneIndex = $webpart.WebPart.ZoneIndex
                $zoneId = $webpart.ZoneId

                $webpartXML = Get-PnPWebPartXml -ServerRelativePageUrl $pageRelativeURL -Identity $webpartTitle
                if(($webpartXML.IndexOf($summaryLinksType) -gt -1) -or ($webpartXML.IndexOf($conteneEditorType) -gt -1) -or ($webpartXML.IndexOf($scriptEditorType) -gt -1) ) {
                    $flag = $true
                    $webpartsCount++
                    $webpartXML = $webpartXML.Replace($itemsCol.OriginalURL,$itemsCol.TargetURL)#.Replace($sourceUrl1,$NewValue1).Replace($sourceUrl2,$NewValue2);

                    Set-PnPFileCheckedOut -Url $pageRelativeURL
                    Remove-PnPWebPart -ServerRelativePageUrl $pageRelativeURL -Identity $webpart.Id
                    Add-PnPWebPartToWebPartPage -ServerRelativePageUrl $pageRelativeURL -XML $webpartXML -ZoneId $zoneId -ZoneIndex $zoneIndex
                    Set-PnPFileCheckedIn -Url $pageRelativeURL

                    #Write-Host "Completed fixing broken links in the webpart :" $webpartTitle -ForegroundColor Green                    
                }        
            }            
        }
        Write-Host "Completed the broken links replacement process `n" -ForegroundColor Green        
    }
    catch {
        Write-Host "Failed in Replace-BrokenLinks method execution: $($_.Exception.Message) `n" -ForegroundColor Red        
        throw
    }
}

#Execute Console application for Workflow History list and Connected list/library Items
function Execute-ConsoleAppUtilities {
    Param(
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $sourceUrl,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $targetUrl,
        [Parameter(Mandatory = $true)] $siteId,
        [Parameter(Mandatory = $true)] $batchId,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $dboUserID,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $dboPassword,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $spOnPremUserId,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $spOnPremPassword,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $spoUserId,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $spoPassword
    )
    try {
        & $consoleAppExeFilePath $sourceUrl $targetUrl $siteId $batchId $dboUserID $dboPassword $spOnPremUserId $spOnPremPassword $spoUserId $spoPassword                     
    }
    catch {
        Write-Host $_.Exception.Message -ForegroundColor Red
        throw
    }
}

#Change Regional settings
function Change-RegionalSettings {
    Param(
        [Parameter(Mandatory = $true)] $sourceContext,
        [Parameter(Mandatory = $true)] $targetContext
    )
    try {        
        #Fetch Source site regional settings
        $sourceRegionalSettings = $sourceContext.Web.RegionalSettings
        $sourceContext.Load($sourceRegionalSettings)
        $sourceContext.ExecuteQuery()
        $localId = $sourceRegionalSettings.LocaleId        
        $timeZone = $sourceRegionalSettings.TimeZone        
        $sourceContext.Load($timeZone)
        #$sourceContext.ExecuteQuery()  
        ExecuteQueryWithIncrementalRetry $sourceContext 3 5000      
        
        #Update Target site regional settings
        $targetTimeZones = $targetContext.Web.RegionalSettings.TimeZones
        $targetContext.Load($targetTimeZones)
        #$targetContext.ExecuteQuery()
        ExecuteQueryWithIncrementalRetry $targetContext 3 5000
        $setTimeZone = $targetTimeZones | Where { $_.Description -eq $timeZone.Description }
        $regionalSettings = $targetContext.Web.RegionalSettings
        $regionalSettings.TimeZone = $setTimeZone
        $regionalSettings.LocaleId = $localeId
        $targetContext.Web.Update()
        #$targetContext.ExecuteQuery()
        ExecuteQueryWithIncrementalRetry $targetContext 3 5000
        Write-Host "Regional settings updated successfully" -ForegroundColor Green
    }
    catch {
        Write-Host "Failed in Change-RegionalSettings method execution: $($_.Exception.Message) `n" -ForegroundColor Red        
        throw
    }
}

try {    
    #Fetch SQL DB Credentials from Azure Keyvault
    $dbCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azOrchDbUserId $azOrchDbPassword    
    $secureDbPassword = $dbCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force
  
    #Fetch Source Sites Credentials from Azure keyvault
    $sourceCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azSourceIntranetUserId $azSourceIntranetPassword
    $sourceSecurePassword = $sourceCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force

    #Fetch Source Extranet Sites Credentials from Azure keyvault
    $sourceExtranetCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azSourceExtranetUserId $azSourceExtranetPassword     
    $sourceExtranetSecurePassword = $sourceExtranetCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force

    #Fetch Source SPO Sites Credentials from Azure keyvault
    if(!([String]::IsNullOrEmpty($azSourceSpoUserId)) -and !([String]::IsNullOrEmpty($azSourceSpoPassword))) {
        $sourceSpoCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azSourceSpoUserId $azSourceSpoPassword     
        $sourceSpoSecurePassword = $sourceSpoCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force
    }

    #Fetch Target Sites Credentials from Azure keyvault
    $targetCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azTargetUserId $azTargetPassword     
    $targetSecurePassword = $targetCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force
        
    Write-Host "------------------------------Remediation process Starts------------------------------`n"
        
    #Build SQL Connection
    $sqlConnection = New-Object System.Data.SqlClient.SqlConnection
	$sqlConnection.ConnectionString = Get-SqlConnectionString $dbCredentials.LoginId $secureDbPassword $sqlServerInstance $sqlDatabase
    $sqlConnection.Open()

    $flag = $true        
    while($flag) {
        try {
            if($sqlConnection.State -ne "Open") {
                $sqlConnection.Open()
            }
            
            $getRemediationSiteDetails = $null
            $flagNoData = $true
            while($flagNoData) {
                #Fetch Sites Ready for Remediation            
                $getRemediationSiteDetails = Execute-StrdProcWithParameters $sqlConnection $sprocSitesForRemediation $sprocInputParameters $sprocOutputParameters
                if($getRemediationSiteDetails -eq $null){
                    Write-Host "Null Object Returned. Waiting for 5 seconds" -ForegroundColor Red
                    Start-Sleep -Seconds 5
                }
                else { 
                    $flagNoData = $false
                }
            }

            #if(!([String]::IsNullOrEmpty($getRemediationSiteDetails.OriginalURL)) -and !([String]::IsNullOrEmpty($getRemediationSiteDetails.TargetURL))) {
            if(!($getRemediationSiteDetails.SiteID -eq -1 -and $getRemediationSiteDetails.BatchID -eq -1)) {
                Write-Host "Performing Remediation on Site:" $getRemediationSiteDetails.TargetURL "`n" -ForegroundColor Green

                $jobFailuresTable = "Mig_Sites_MigrationJobFailures"
                $query_UpdateJobFailuresTable = "update [$jobFailuresTable] set DefectStatus='Closed' where fk_jobStep=450 and fk_Batch=" + $([int]$getRemediationSiteDetails.BatchID) + " and fk_Site=" + $([int]$getRemediationSiteDetails.SiteID)
                Execute-SqlQuery $sqlConnection $query_UpdateJobFailuresTable
                
                #Get Context for Source and Target sites
                $sourceUserId = $null
                $sourcePassword = $null
                if($getRemediationSiteDetails.SourceType.ToLower().Trim() -eq "intranet") {
                    $sourceUserId = $sourceCredentials.LoginId
                    $sourcePassword = $sourceCredentials.LoginPassword
                    #$sourceContext = Get-SPContext $getRemediationSiteDetails.OriginalURL $sourceUserId $sourceSecurePassword
                }
                elseif($getRemediationSiteDetails.SourceType.ToLower().Trim() -eq "extranet") {
                    $sourceUserId = $sourceExtranetCredentials.LoginId
                    $sourcePassword = $sourceExtranetCredentials.LoginPassword
                    #$sourceContext = Get-SPContext $getRemediationSiteDetails.OriginalURL $sourceUserId $sourceExtranetSecurePassword
                }                
                else {
                    $sourceUserId = $sourceSpoCredentials.LoginId
                    $sourcePassword = $sourceSpoCredentials.LoginPassword
                    #$sourceContext = Get-SPContext $getRemediationSiteDetails.OriginalURL $sourceUserId $sourceSpoSecurePassword
                }
                
                Start-Sleep -Seconds 5
                #Migrate WorkflowHistory List, QuickLaunch and Connected Lists/Library Items
                Execute-ConsoleAppUtilities $getRemediationSiteDetails.OriginalURL $getRemediationSiteDetails.TargetURL $([String]$getRemediationSiteDetails.SiteID) $([String]$getRemediationSiteDetails.BatchID) $dbCredentials.LoginId $dbCredentials.LoginPassword $sourceUserId $sourcePassword $targetCredentials.LoginId $targetCredentials.LoginPassword
                
                $checkFatalErrorQuery = "select fk_Status from [dbo].[Mig_Sites_Step_Status] where fk_Site=$($getRemediationSiteDetails.SiteID) and fk_Batch=$($getRemediationSiteDetails.BatchID) and fk_JobStep=4"
                $getFatalStatus = Get-ContentFromSqlQuery $sqlConnection $checkFatalErrorQuery
                if($getFatalStatus.fk_Status -ne 6) {
                    #target Context
                    $targetContext = Get-SPContext $getRemediationSiteDetails.TargetURL $targetCredentials.LoginId $targetSecurePassword
                
                    #Start-Sleep -Seconds 5                
                    #Change Regional Settings - Target Site
                    #Change-RegionalSettings $sourceContext $targetContext
                
                    #Start-Sleep -Seconds 5                    
                    #Replace broken links
                    #Replace-BrokenLinks $getRemediationSiteDetails $targetCredentials.LoginId $targetSecurePassword

                    #Check if Permissions available in DB
                    $chkPermissionsQuery = "SELECT COUNT(*) as ItemsCount FROM Mig_Sites_Permissions WHERE fk_site = $($getRemediationSiteDetails.SiteID)"
                    $permsCount = Get-ContentFromSqlQuery $sqlConnection $chkPermissionsQuery

                    if($permsCount.ItemsCount -gt 0) {
                        #Applying permissions to the target site                    
                        #ApplyPermissionsOnTarget $targetContext $getRemediationSiteDetails.SiteID $getRemediationSiteDetails.BatchID $getRemediationSiteDetails.OriginalURL $getRemediationSiteDetails.TargetURL $sprocSitesForPostMigration $sqlConnection
                        ApplyPermissionsOnTarget $targetContext $getRemediationSiteDetails $sprocSitesForPostMigration $sqlConnection
                    
                        #Update SQL record - Status to Remediation Completed
                        ChangeStatus-InputParameters $getRemediationSiteDetails.SiteID $getRemediationSiteDetails.BatchID $sprocStatusChangeDynamicParameters "450" "400" "Remediation - Completed"
                        $changeStatusParameters = $sprocStatusChangeInputParameters,$sprocStatusChangeDynamicParameters
                        $retObj = Execute-StrdProcWithParameters $sqlConnection $sprocStatusChange $changeStatusParameters $null

                        #Update SQL record - Status to Testing Ready
                        ChangeStatus-InputParameters $getRemediationSiteDetails.SiteID $getRemediationSiteDetails.BatchID $sprocStatusChangeDynamicParameters "500" "1000" "Testing - Ready to Proceed"
                        $changeStatusParameters = $sprocStatusChangeInputParameters,$sprocStatusChangeDynamicParameters
                        $retObj = Execute-StrdProcWithParameters $sqlConnection $sprocStatusChange $changeStatusParameters $null
                    }
                    else {
                        $exception = "No Permissions available in DB"
                        #Fatal error logs            
                        ChangeStatus-InputParameters $getRemediationSiteDetails.SiteID $getRemediationSiteDetails.BatchID $sprocStatusChangeDynamicParameters "450" "600" $exception
                        $parameters = $sprocStatusChangeInputParameters,$sprocStatusChangeDynamicParameters
                        Execute-StrdProcWithParameters $sqlConnection $sprocStatusChange $parameters $null
                            
                        #Exception logs
                        ExceptionLogs-InputParameters $getRemediationSiteDetails $sprocExcepLogsDynamicParameters "450" "Automated Remediation: " $exception $exception           
                        $inputParameters = $sprocExcepLogsInputParameters,$sprocExcepLogsDynamicParameters
                        Execute-StrdProcWithParameters $sqlConnection $sprocExcepLogging $inputParameters $null
                    }
                }
            }
            else {
                Write-Host "No sites found for Remediation! `n" -ForegroundColor Yellow
                $flag = $false                
            }
        }
        catch {
            Write-Host $_.Exception.Message -ForegroundColor Red
            $exception = $($_.Exception.Message).Replace('"', '`"')
            #Fatal error logs            
            ChangeStatus-InputParameters $getRemediationSiteDetails.SiteID $getRemediationSiteDetails.BatchID $sprocStatusChangeDynamicParameters "450" "600" $exception
            $parameters = $sprocStatusChangeInputParameters,$sprocStatusChangeDynamicParameters
            Execute-StrdProcWithParameters $sqlConnection $sprocStatusChange $parameters $null
                            
            #Exception logs
            ExceptionLogs-InputParameters $getRemediationSiteDetails $sprocExcepLogsDynamicParameters "450" "Automated Remediation: " $exception $($_.ScriptStackTrace)            
            $inputParameters = $sprocExcepLogsInputParameters,$sprocExcepLogsDynamicParameters
            Execute-StrdProcWithParameters $sqlConnection $sprocExcepLogging $inputParameters $null

            if($exception.ToLower().contains("partner returned a bad sign-in name or password error")) {
                $flag = $false
            }
        }
        finally {           
            #$sourceContext.Dispose()
            $targetContext.Dispose()
        }
    }

    #Dispose SqlConnection
    $sqlConnection.Dispose()
}
catch {
    Write-Host "Exception in fetching Azure Keyvault details `n" $_.Exception.Message -ForegroundColor Red
}

Write-Host "------------------------------Remediation process Ends------------------------------"
