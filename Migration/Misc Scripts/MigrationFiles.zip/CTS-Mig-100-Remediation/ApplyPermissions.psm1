﻿$dt = Get-Date 
$executingScriptDirectory = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent

$mth = $dt.Month
if($mth -eq 1 -or $mth -eq 2 -or $mth -eq 3 -or $mth -eq 4 -or $mth -eq  5 -or $mth -eq 6 -or $mth -eq 7 -or $mth -eq 8 -or $mth -eq 9)
{
$mth = "0"+$mth;
}
$dte = $dt.Day.ToString()+ '_' + $mth.ToString() + '_' + $dt.Year.ToString() +'_'+ $dt.Hour.ToString() + '_' + $dt.Minute.ToString() + '_' + $dt.Second.ToString();

#$logPath = $executingScriptDirectory +"\Logs\" + "PE_Logs"+ $dte + ".csv"


function Dispose-All 
{
    <#  .DESCRIPTION         Disposes of all memory used.,        .EXAMPLE        Dispose-All    #>
	
Get-Variable -exclude Runspace | Where-Object {$_.Value -is [System.IDisposable] -and $_.Value.GetType().Name -ne "SqlBulkCopy"} | 
		Foreach-Object { $_.Value.Dispose() }
}

#--------------------------------------------------------------------------------------------------
# Main Script
#--------------------------------------------------------------------------------------------------

$OutputFilename = $executingScriptDirectory +"\Logs\" +"$((Get-Date).ToString("yyyyMMdd_HHmmss"))_GetPermissionEditTransScript.csv"
$OutputLogFilename =$executingScriptDirectory +"\Logs\" + "$((Get-Date).ToString("yyyyMMdd_HHmmss"))_GetPermissionEditLog.csv" 

#Input file of the Site URLs - Source URL and Target URL


 #Create an array to capture Logs while executing the script
$oLogDetailsCollection = New-Object System.Collections.ArrayList
#To call a non-generic method Load
 
 Function Invoke-LoadMethod() {
    param(
            [Microsoft.SharePoint.Client.ClientObject]$Object = $(throw "Please provide a Client Object"),
            [string]$PropertyName
        )
   $ctx = $Object.Context
   $load = [Microsoft.SharePoint.Client.ClientContext].GetMethod("Load")
   $type = $Object.GetType()
   $clientLoad = $load.MakeGenericMethod($type)
  
   $Parameter = [System.Linq.Expressions.Expression]::Parameter(($type), $type.Name)
   $Expression = [System.Linq.Expressions.Expression]::Lambda([System.Linq.Expressions.Expression]::Convert([System.Linq.Expressions.Expression]::PropertyOrField($Parameter,$PropertyName),[System.Object] ), $($Parameter))
   $ExpressionArray = [System.Array]::CreateInstance($Expression.GetType(), 1)
   $ExpressionArray.SetValue($Expression, 0)
   $clientLoad.Invoke($ctx,@($Object,$ExpressionArray))
}

#Function to Get Webs's Permissions from given URL
Function Get-SPOWebPermission([Microsoft.SharePoint.Client.ClientContext]$Ctx)
{
    $web = $Ctx.Web;
    $Ctx.Load($web) 
    #$Ctx.executeQuery()
    ExecuteQueryWithIncrementalRetry $Ctx 3 5000 
   
    #Call the function to Get Lists of the web
    #Write-host -f Yellow "Getting the Permissions of Web "$web.URL"..."
    #    "Iterating through Permissions of web in the List:"+ $web.URL| Out-File $OutputFilename -Append
    #
    ##Check if the Web has unique permissions
    Invoke-LoadMethod -Object $web -PropertyName "HasUniqueRoleAssignments"
    #$Ctx.ExecuteQuery()
    ExecuteQueryWithIncrementalRetry $Ctx 3 5000 
  
    #Get the Web's Permissions
    If($web.HasUniqueRoleAssignments -eq $true)
    {
        Get-Permissions $Ctx -Object $web -SiteURL $SiteURL -OutputFilename $OutputFilename -oLogDetailsCollection $oLogDetailsCollection
    }
  
    #Scan Lists with Unique Permissions
    #Write-host -f Yellow "`t Getting the Permissions of Lists and Libraries in "$Web.URL"..."
    #"Iterating through the Permissions of Lists and Libraries in:"+ $web.URL| Out-File $OutputFilename -Append
    Get-SPOListPermission $Ctx $web
   
   
}

        #Function to Get Permissions of all lists from the web
Function Get-SPOListPermission([Microsoft.SharePoint.Client.ClientContext]$Ctx, [Microsoft.SharePoint.Client.Web]$Web)
{
    #Get All Lists from the web
    $Lists = $Web.Lists
    $Ctx.Load($Lists)
    #$Ctx.ExecuteQuery()
    ExecuteQueryWithIncrementalRetry $Ctx 3 5000
  
    #Get all lists from the web  
    ForEach($List in $Lists)
    {
        #Exclude System Lists
        If($List.Hidden -eq $False)
        {
            #Get List Items Permissions
            # Get-SPOListItemsPermission $List 

  
            #Get the Lists with Unique permission
            Invoke-LoadMethod -Object $List -PropertyName "HasUniqueRoleAssignments"
            #$Ctx.ExecuteQuery()
            ExecuteQueryWithIncrementalRetry $Ctx 3 5000
  
            If( $List.HasUniqueRoleAssignments -eq $True)
            {
                #Call the function to check permissions
                Get-Permissions $Ctx -Object $List -SiteURL $SiteURL -OutputFilename $OutputFilename -oLogDetailsCollection $oLogDetailsCollection
            }
        }
    }
}
  
  
#Function to Get Permissions Applied on a particular Object, such as: Web, List or Item
Function Get-Permissions([Microsoft.SharePoint.Client.ClientContext]$Ctx,
[Microsoft.SharePoint.Client.SecurableObject]$Object, $SiteURL,$OutputFilename,$oLogDetailsCollection)
{
    Try{
       #Determine the type of the object
        Switch($Object.TypedObject.ToString())
        {
            "Microsoft.SharePoint.Client.Web"  { $ObjectType = "Site" ; $ObjectURL = $Object.URL }
       
           Default
            {
                $ObjectType = "List/Library"
                #Get the URL of the List or Library
                $Ctx.Load($Object.RootFolder)
                #$Ctx.ExecuteQuery() 
                ExecuteQueryWithIncrementalRetry $Ctx 3 5000 
       
                $ObjectURL = $("{0}{1}" -f $Ctx.Web.Url.Replace($Ctx.Web.ServerRelativeUrl,''), $Object.RootFolder.ServerRelativeUrl)
            }
        }
  
        #Get permissions assigned to the object
        $Ctx.Load($Object.RoleAssignments)
        #$Ctx.ExecuteQuery()
        ExecuteQueryWithIncrementalRetry $Ctx 3 5000
  
        Foreach($RoleAssignment in $Object.RoleAssignments)
        {
            $Ctx.Load($RoleAssignment.Member)
            #$Ctx.executeQuery()
            ExecuteQueryWithIncrementalRetry $Ctx 3 5000
                 
            #Get the Permissions on the given object
            $Permissions=@()
            $Ctx.Load($RoleAssignment.RoleDefinitionBindings)
            #$Ctx.ExecuteQuery()
            ExecuteQueryWithIncrementalRetry $Ctx 3 5000
            $accName= $RoleAssignment.Member.LoginName
            try {
                Edit-SPOSitePermission -Context $Ctx -SiteURL $SiteURL  -ObjectType $ObjectType -RoleAssignment $RoleAssignment -ObjectTitle $Object.Title -OutputFilename $OutputFilename -oLogDetailsCollection $oLogDetailsCollection -ObjectURL  $ObjectURL -accName $accName 
            }
            catch {
                if($_.Exception.Message.ToLower().Contains("too many")) {
                    Write-Host $_.Exception.Message -ForegroundColor Red
                    #$exception = $($_.Exception.Message).Replace('"', '`"')
                    
                    #Exception logs
                    #ExceptionLogs-InputParameters $getRemediationSiteDetails $sprocExcepLogsDynamicParameters "450" "Automated Remediation: " $exception $($_.ScriptStackTrace)            
                    #$inputParameters = $sprocExcepLogsInputParameters,$sprocExcepLogsDynamicParameters
                    #Execute-StrdProcWithParameters $sqlConnection $sprocExcepLogging $inputParameters $null
                }
                else {
                    throw
                }
            }
        }
    }
    Catch{        
        throw   
    }
}


#Function to Edit Permissions 
Function Edit-SPOSitePermission([Microsoft.SharePoint.Client.ClientContext]$Context, $SiteURL,$ObjectType,$RoleAssignment,$ObjectTitle,$OutputFilename ,$oLogDetailsCollection, $ObjectURL,$accName)
{
Try{#$accName= $RoleAssignment.Member.LoginName 
    if(($RoleAssignment.Member.PrincipalType -eq "SharePointGroup") -or ($RoleAssignment.Member.PrincipalType -eq "SecurityGroup") -or ($RoleAssignment.Member.PrincipalType -eq "User"))
    #if(($RoleAssignment.Member.PrincipalType -eq "User"))    
         {      $ReadRole = “Read”
                $RnPRole = “Read and Personalize"
                $FullControlRole = "Full Control"
                $vRole = “View Only"
                $cRole  = "Contribute"             
                $Inheritance = "Custom"            
                #$selColumns = "Type","Name","URL","Inheritance","User/group","Principaltype","Accountname","Permissions","TargetURL","DesURL"	
                $selColumns = "TypeOfContent","SiteName","SourceURL","Inheritance","UserGroup","Principaltype","Accountname","ContentPermissions" #,"TargetURL","DesURL"	
                $selColumns = "TypeOfContent","SiteName","SourceURL","Inheritance","UserGroup","Principaltype","Accountname","ContentPermissions","TargetURL","DesURL"
                $perSource = $getPostMigrationSiteDetails | Select-Object -Property $selColumns
                

                $cdtn = ( ($_.ContentPermissions -notmatch $ReadRole) -or ($_.ContentPermissions -notmatch $RnPRole) -or ($_.ContentPermissions -notmatch $vRole) -or ($_.ContentPermissions -notmatch $FullControlRole))
                             
                $selSPOPer +=  $perSource| Where-Object {( $_.TargetURL -match  $SiteURL) -and ( $_.DesURL -eq ($ObjectURL)) -and ($_.Inheritance -match  $Inheritance) -and ($_.TypeOfContent -match $ObjectType) -and (($_.AccountName -like $RoleAssignment.Member.LoginName) -or($_.AccountName -match $RoleAssignment.Member.Title)) -and $cdtn}| Select-Object  {$_.ContentPermissions} 
                
                
         if($selSPOPer.'$_.ContentPermissions' -ne $null)
            {    $selSPOPerArr =$selSPOPer.'$_.ContentPermissions'.Split(";")

                 #Get the Permissions on the given object
                 $Permissions=@()
                 Foreach ($RoleDefinition in $RoleAssignment.RoleDefinitionBindings)                    
                    { $Permissions += $RoleDefinition.Name }
                 
                  
              
                                                                                  
           $counter = $selSPOPerArr.Count - 1
          for($i=0;$i -lt $counter ;$i++)  
            { #Get Permission Levels to add and remove
                    $AddPermission = $selSPOPerArr[$i]
                    $DispPermission ="No"
                    $RoleDefToRmvRead = $Ctx.web.RoleDefinitions.GetByName($ReadRole)  
                    $RoleDefToRmvRnP = $Ctx.web.RoleDefinitions.GetByName($RnPRole)  
                    $RoleDefToRmvVO = $Ctx.web.RoleDefinitions.GetByName($vRole) 
                    $RoleDefToRmvCon = $Ctx.web.RoleDefinitions.GetByName($cRole)  
                    $RoleDefToRmvFullControl = $Ctx.web.RoleDefinitions.GetByName($FullControlRole)
                                    
                    if($AddPermission -ne "Site Collection Administrator")
                    {  
                     if($AddPermission.Length -ne 0){ $RoleDefToAdd = $Ctx.web.RoleDefinitions.GetByName($AddPermission)
                     #Add Permission level to the group
                      if (($RoleAssignment.RoleDefinitionBindings.Name -notcontains $AddPermission ))
                       {
                          $RoleAssignment.RoleDefinitionBindings.Add($RoleDefToAdd)                                                                                        
                          $RoleAssignment.Update()
                           
                       } 
                       }
                       
                       if (($selSPOPerArr -notcontains $ReadRole) -and ($RoleAssignment.RoleDefinitionBindings.Name -contains $ReadRole ))
                       {
                          $RoleAssignment.RoleDefinitionBindings.Remove($RoleDefToRmvRead)                                                                                        
                          $RoleAssignment.Update()
                          $DispPermission = $ReadRole    
                       }
                       elseif(($selSPOPerArr -notcontains $RnPRole) -and ($RoleAssignment.RoleDefinitionBindings.Name -contains $RnPRole ))
                       {  
                          $RoleAssignment.RoleDefinitionBindings.Remove($RoleDefToRmvRnP)                                                                                        
                          $RoleAssignment.Update()
                          $DispPermission = $RnPRole 
                       }
                       elseif( ($selSPOPerArr -notcontains $vRole) -and ($RoleAssignment.RoleDefinitionBindings.Name -contains $vRole ))
                       {  
                          $RoleAssignment.RoleDefinitionBindings.Remove($RoleDefToRmvVO)                                                                                        
                          $RoleAssignment.Update()
                          $DispPermission = $RnPRole 
                        }
                        elseif( ($selSPOPerArr -notcontains $cRole) -and ($RoleAssignment.RoleDefinitionBindings.Name -contains $cRole ))
                       {  
                          $RoleAssignment.RoleDefinitionBindings.Remove($RoleDefToRmvCon)                                                                                        
                          $RoleAssignment.Update()
                          $DispPermission = $RnPRole 
                        }
                        elseif( ($selSPOPerArr -notcontains $FullControlRole) -and ($RoleAssignment.RoleDefinitionBindings.Name -contains $FullControlRole ))
                       {  
                          $RoleAssignment.RoleDefinitionBindings.Remove($RoleDefToRmvFullControl)                                                                                        
                          $RoleAssignment.Update()
                          $DispPermission = $RnPRole 
                        }
                        
                       #$Ctx.ExecuteQuery()
                       ExecuteQueryWithIncrementalRetry $Ctx 3 5000
                       #$AddPermission + "Permission Added to the Group!" + $accName | Out-File $OutputFilename   -Append
                       #$DispPermission + "Permission Removed from the Group!" + $accName | Out-File $OutputFilename   -Append  
                    } 
                }  
               }
            
             
              }
             }
     Catch{
        $exception = $($_.Exception.Message).Replace('"', '`"')
        if($exception.ToLower().contains("permission level specified is already added to the collection")) {
            Write-Host $_.Exception.Message -ForegroundColor Red
        }
        else {
            throw
        }  
            
     }
}

#Set parameter values
#$ReportFile=".\SitePermissionRpt.csv"
$BatchSize = 500
$accName = $null

function ApplyPermissionsOnTarget($Ctx,$getRemediationSiteDetails, $sprocSitesForPostMigration, $sqlConnection) {
    try {
	    #StoredProcedure - Fetch Post-Migration sites
        $elapsed = [System.Diagnostics.Stopwatch]::StartNew()
        $siteId = $getRemediationSiteDetails.SiteID
        $batchId = $getRemediationSiteDetails.BatchID
        $sourceUrl = $getRemediationSiteDetails.OriginalURL
        $targetUrl = $getRemediationSiteDetails.TargetURL
                
        $fetchPermissonsQuery = "DECLARE @Returncode int EXEC $($sprocSitesForPostMigration) @Siteid = $($siteId), @Returncode = @Returncode OUTPUT"
        $getPostMigrationSiteDetails = Get-ContentFromSqlQuery $sqlConnection $fetchPermissonsQuery
        $getPostMigrationSiteDetails  = $getPostMigrationSiteDetails | select -Skip 1
        
        $SiteURL = $targetUrl.Trim().TrimEnd('/')        
        Write-Host "Applying permissions for Site : " $SiteURL -ForegroundColor DarkGreen
                
        #Call the function
        Get-SPOWebPermission $Ctx
        Write-Host "Total Elapsed Time: $($elapsed.Elapsed.TotalMinutes)"
    }
    catch {
        throw
    }
}