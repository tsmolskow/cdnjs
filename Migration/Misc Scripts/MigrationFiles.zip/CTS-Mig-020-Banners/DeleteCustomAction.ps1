﻿Add-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue
 
#Set Site variable
$SiteURL="https://us.tdm.ey.net/sites/2d28602302b642bdacf1bbb683998ffb"
$CustomActionTitle ="Support Center"
 
Try {
    #Get the Web
    $Web = Get-SPWeb $SiteURL
  
    #Get the Custom Actions Filter by Title
    $CustomActions = $web.UserCustomActions | Where { $_.Title -eq $CustomActionTitle } | Select ID, Title
 
    If($CustomActions -ne $Null)
    {
        #Delete custom action(s)
        $CustomActions | ForEach-Object {
            #Remove the custom action
            $web.UserCustomActions.Item($_.Id).Delete()
            Write-Host -f Green "Custom Action '$($_.Title)' Deleted Successfully!"
        }
    }
    Else
    {
        write-host -f Yellow "Custom Action '$CustomActionTitle' Doesn't Exist!"
    } 
} Catch {
    Write-Host -ForegroundColor Red "Error:" $_.Exception.Message
}