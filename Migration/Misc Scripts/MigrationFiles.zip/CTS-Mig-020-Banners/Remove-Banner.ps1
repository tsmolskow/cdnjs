﻿#region Variable Declaration
Get-Module | Remove-Module -Force
Clear-Host
#Load XML Config File
$scriptRoot = Split-Path $MyInvocation.MyCommand.Path -Parent
$parentRoot = (Get-Item $scriptRoot).Parent.FullName
$configfolder = Join-Path $parentRoot.ToLower().Replace('\cts\','\ey\') "CTS-Mig-0Settings"
$xmlConfigPath =  Join-Path $configfolder "ConfigurationSettings.xml"
$configXmlfile = [xml]$(Get-Content $xmlConfigPath)

#Load Module files - Reusable methods, Apply Permissions
$modulesFolder = Join-Path $parentRoot $configXmlfile.ConfigSettings.CommonSettings.Modules.Name
$modulesPath = Join-Path $modulesFolder $configXmlfile.ConfigSettings.CommonSettings.Modules.Value
$rolebackPermissionsModule = Join-Path $scriptRoot $configXmlfile.ConfigSettings.CommonSettings.RolebackPermissions.Value
Import-Module -Name $modulesPath -WarningAction SilentlyContinue
Import-Module -Name $rolebackPermissionsModule -WarningAction SilentlyContinue

#Load SharePoint CSOM Assemblies
$spoModulesRefPath = $configXmlfile.ConfigSettings.CommonSettings.SPOnlineReferencesPath.Value
Import-Module -Name $spoModulesRefPath -DisableNameChecking
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client")
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client.Runtime")

#Load SharePoint PnP PowerShell Online Assemblies
$spPnPPSModulesRefPath = $configXmlfile.ConfigSettings.CommonSettings.SharePointPnPPowerShellOnline.Value
Import-Module -Name $spPnPPSModulesRefPath -DisableNameChecking

#Load Azure Moodules
$azureAccountsPsd = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.AzureAccountsPsd
$azureKeyvaultsPsd = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.AzureKeyvaultsPsd
Import-Module -Name $azureAccountsPsd
Import-Module -Name $azureKeyvaultsPsd

# Permission Level to be changed
$permissionLevel = $null;

#Add-Content -Path $logPath -Value "Adding datatable header"
$dataTable = New-Object System.Data.DataTable
$dataTable.Columns.Add("ID", "System.Int32") | Out-Null
$dataTable.Columns.Add("fk_site", "System.Int32") | Out-Null
$dataTable.Columns.Add("fk_batch", "System.Int32") | Out-Null
$dataTable.Columns.Add("TypeOfContent", "System.String") | Out-Null
$dataTable.Columns.Add("SiteName", "System.String") | Out-Null
$dataTable.Columns.Add("SourceURL", "System.String") | Out-Null
$dataTable.Columns.Add("Inheritance", "System.String") | Out-Null
$dataTable.Columns.Add("UserGroup", "System.String") | Out-Null
$dataTable.Columns.Add("Principaltype", "System.String") | Out-Null
$dataTable.Columns.Add("Accountname", "System.String") | Out-Null
$dataTable.Columns.Add("ContentPermissions", "System.String") | Out-Null
		
[int]$Global:fk_Site = 0;
[int]$Global:fk_Batch = 0;

$Global:ExistingBannerColor = "";
$Global:BannerType = "";
$Global:isSetPermissionSuccess = $true;

$_fullControl = "Full Control";
$_contribute = "Contribute";
$_read = "Read";
$_viewOnly = "View Only";
$_limitedAccess = "Limited Access";
$_editEdit = "Edit";

$Global:batchNo = 0;

#endregion

Function IsAuthorizedSite(){
	try{
        
        $filepath = $scriptRoot + "\ReverseMigration.csv"
	    $Global:sites = Import-csv $filepath;

        #while($bannerReadySites){
        foreach($Global:site in $Global:sites){
            $_siteURL = $site.OriginalURL
            $_source = $site.SourceType
        

            #$SiteURL = "https://eyonespace.ey.com/Sites/f33c90653d7345359be362b86d58bf58/42ddf96c9164464f9e245dd5e13e8cd4"
		    #$LogMessage = "Get SPCredential for the Site: " + $SiteURL         
            #Write-Host -f Yellow $LogMessage
            #$_sourceType = "extranet";

            #Get-SPContext -source $SiteURL -userId $srcUserName -securePassword $srcPassword
            if($_source.ToLower().Trim().IndexOf("intranet") -ne -1) {
            $Global:Ctx = Get-SPContext $_siteURL $sourceCredentials.LoginId $sourceSecurePassword
            }
            elseif($_source.ToLower().Trim().IndexOf("extranet") -ne -1) {
                $Global:Ctx = Get-SPContext $_siteURL $sourceExtranetCredentials.LoginId $sourceExtranetSecurePassword
            }
            else {
                $Global:Ctx = Get-SPContext $_siteURL $sourceSpoCredentials.LoginId $sourceSpoSecurePassword
            }

            #Get the Web
            $Web = $Ctx.Web;
            $Ctx.Load($Web);
            $UserCustomActions = $Ctx.Web.UserCustomActions
            $PropertyValues = $Ctx.Web.AllProperties
            $Ctx.Load($UserCustomActions)
            $Ctx.Load($PropertyValues)
            #-----------------------------------  Execute Site Context -------------------------------------
            $LogMessage = "Execute Site Context";         
            #Write-Host -f Yellow $LogMessage
            Invoke-LoadMethod -Object $Web -PropertyName "HasUniqueRoleAssignments"
            ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
		    $LogMessage = "Connection Established successfully for the Site Url: "+ $SiteURL; 

            #Check if the Custom Action Exists already

            $CustomAction = $UserCustomActions | Where { $_.Sequence -eq $customActionSequenceNo } | Select ID, Title
            #Remove the custom action
		    $Ctx.Web.UserCustomActions.GetById($CustomAction.Id).DeleteObject()
        
            $PropertyValues["DestinationUrl"] = ""
            $PropertyValues["MigrationDate"] = ""
            $PropertyValues["BannerColor"] = ""
            $Web.Update()

		    ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
            #Write-Host -f Yellow $LogMessage; 
            #Write-Host -f Yellow 'LogMessage; 
        }    
        
	}
	catch{
		$logMsg = $_.Exception.Message
        #Set-ChangeStatus $logMsg $($_.ScriptStackTrace);
	}
	finally{
		$Ctx.Dispose();
	}
}

IsAuthorizedSite