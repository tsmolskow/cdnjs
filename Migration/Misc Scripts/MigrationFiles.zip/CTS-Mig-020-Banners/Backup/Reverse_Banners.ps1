﻿#region Variable Declaration
Get-Module | Remove-Module -Force
Clear-Host
#Load XML Config File
$scriptRoot = Split-Path $MyInvocation.MyCommand.Path -Parent
$parentRoot = (Get-Item $scriptRoot).Parent.FullName
$configfolder = Join-Path $parentRoot.ToLower().Replace('\cts\','\ey\') "CTS-Mig-0Settings"
$xmlConfigPath =  Join-Path $configfolder "ConfigurationSettings.xml"
$Global:configXmlfile = [xml]$(Get-Content $xmlConfigPath)

#Load Module files - Reusable methods, Apply Permissions
$modulesFolder = Join-Path $parentRoot $configXmlfile.ConfigSettings.CommonSettings.Modules.Name
$modulesPath = Join-Path $modulesFolder $configXmlfile.ConfigSettings.CommonSettings.Modules.Value
#Import-Module -Name $modulesPath -WarningAction SilentlyContinue
$rolebackPermissionsModule = Join-Path $scriptRoot $configXmlfile.ConfigSettings.CommonSettings.RolebackPermissions.Value
Import-Module -Name $modulesPath -WarningAction SilentlyContinue
Import-Module -Name $rolebackPermissionsModule -WarningAction SilentlyContinue

#Load SharePoint CSOM Assemblies
$spoModulesRefPath = $configXmlfile.ConfigSettings.CommonSettings.SPOnlineReferencesPath.Value
Import-Module -Name $spoModulesRefPath -DisableNameChecking
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client")
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client.Runtime")

#Load SharePoint PnP PowerShell Online Assemblies
$spPnPPSModulesRefPath = $configXmlfile.ConfigSettings.CommonSettings.SharePointPnPPowerShellOnline.Value
Import-Module -Name $spPnPPSModulesRefPath -DisableNameChecking

#Load Azure Moodules
$azureAccountsPsd = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.AzureAccountsPsd
$azureKeyvaultsPsd = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.AzureKeyvaultsPsd
Import-Module -Name $azureAccountsPsd
Import-Module -Name $azureKeyvaultsPsd
[int]$Global:fk_Site = 0;
[int]$Global:fk_Batch = 0;
$Global:batchNo = 0;

#endregion

# Permission Level to be changed
$permissionLevel = $null;

#Add-Content -Path $logPath -Value "Adding datatable header"
$dataTable = New-Object System.Data.DataTable
$dataTable.Columns.Add("ID", "System.Int32") | Out-Null
$dataTable.Columns.Add("fk_site", "System.Int32") | Out-Null
$dataTable.Columns.Add("fk_batch", "System.Int32") | Out-Null
$dataTable.Columns.Add("TypeOfContent", "System.String") | Out-Null
$dataTable.Columns.Add("SiteName", "System.String") | Out-Null
$dataTable.Columns.Add("SourceURL", "System.String") | Out-Null
$dataTable.Columns.Add("Inheritance", "System.String") | Out-Null
$dataTable.Columns.Add("UserGroup", "System.String") | Out-Null
$dataTable.Columns.Add("Principaltype", "System.String") | Out-Null
$dataTable.Columns.Add("Accountname", "System.String") | Out-Null
$dataTable.Columns.Add("ContentPermissions", "System.String") | Out-Null


Function Create-LogFile($fileName){
    $date= Get-Date -format MMddyyyyHHmmss  
    $enddate = (Get-Date).tostring("yyyyMMddhhmmss")
    $logFileName = $fileName +"_"+ $enddate+"_Log.txt"   
    $Global:directoryPathForLog = $scriptRoot+"\"+"LogFiles"
    if(!(Test-Path -path $directoryPathForLog))  
    {  
        New-Item -ItemType directory -Path $directoryPathForLog          
    }
    $Global:logPath = $directoryPathForLog + "\" + $logFileName
    $Global:isLogFileCreated = $true
}

Function Write-Log([string]$logMsg)  
{   
    if(!$isLogFileCreated){   
        #Write-Host "Creating Log File..."   
        if(!(Test-Path -path $directoryPathForLog))  
        {  
            #Write-Host "Please Provide Proper Log Path" -ForegroundColor Red   
        }   
        else   
        {   
            $Global:isLogFileCreated = $true   
            [string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
            Add-Content -Path $Global:logPath -Value $logMessage   
        }   
    }   
    else   
    {   
        [string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage   
    }   
}


Function Invoke-LoadMethod() {
    param(
            [Microsoft.SharePoint.Client.ClientObject]$Object = $(throw "Please provide a Client Object"),
            [string]$PropertyName
        )
   $ctx = $Object.Context
   $load = [Microsoft.SharePoint.Client.ClientContext].GetMethod("Load")
   $type = $Object.GetType()
   $clientLoad = $load.MakeGenericMethod($type)
   
   $Parameter = [System.Linq.Expressions.Expression]::Parameter(($type), $type.Name)
   $Expression = [System.Linq.Expressions.Expression]::Lambda([System.Linq.Expressions.Expression]::Convert([System.Linq.Expressions.Expression]::PropertyOrField($Parameter,$PropertyName),[System.Object] ), $($Parameter))
   $ExpressionArray = [System.Array]::CreateInstance($Expression.GetType(), 1)
   $ExpressionArray.SetValue($Expression, 0)
   $clientLoad.Invoke($ctx,@($Object,$ExpressionArray))
}

#Step4 Add-Banner Execution Start--  
#region --- Add Banner Execution Start ---

Function Add-Banner($targetUrl, $migrationDate, $bannerColor)
{
    Try 
    {
				
                
    $js = "$"+"("+"document"+")"+".ready(function(){
				
		var cdnJSFilePath = window.location.protocol + ""//"" + window.location.host + ""/"+$userCustomActionCDNPath+""";
		var cdnCSSFilePath = window.location.protocol + ""//"" + window.location.host + ""/"+$userCustomActionCssCDNPath+""";
					
		var head = document.getElementsByTagName('head')[0];
        var script = document.createElement('script');
        script.type = 'text/javascript';
        script.src = cdnJSFilePath;
        head.appendChild(script);
					
		var head  = document.getElementsByTagName('head')[0];
		var link  = document.createElement('link');
		link.id   = 'cssId';
		link.rel  = 'stylesheet';
		link.type = 'text/css';
		link.href = cdnCSSFilePath;
		link.media = 'all';
		head.appendChild(link);
					
    });";
								
    #Check if the Custom Action Exists already
    $CustomAction = $UserWebCustomActions | Where { $_.Sequence -eq $customActionSequenceNo } | Select ID, Title
		
        # Delete Custom Action, If already exist for brand new site.
		try
		{
			If($_bannerType -eq "T-1"){
				#Remove the custom action
		        $Ctx.Web.UserCustomActions.GetById($CustomAction.Id).DeleteObject()
		        ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
		        $UserCustomActions = $Ctx.Web.UserCustomActions;
				$Ctx.Load($UserCustomActions);
				ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
				$CustomAction = $UserCustomActions | Where { $_.Sequence -eq $customActionSequenceNo } | Select ID, Title
			}
		}
		catch{
			#Write-Host $_.Exception.Message
		}		
				    
        If($CustomAction -eq $Null)
        {
            #Add new custom action
            $UserCustomAction = $Ctx.Web.UserCustomActions.Add()
            #Set the Properties of the custom action
            $UserCustomAction.Name = $customActionTitle;
            $UserCustomAction.Description = "Banner msg added to top";
            $UserCustomAction.Location = "ScriptLink"
            $UserCustomAction.ScriptBlock = $js;
            $UserCustomAction.Sequence = $customActionSequenceNo;
            $UserCustomAction.Update();;
            ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
                        
        }
       
        # Add Properties
        if(-not [string]::IsNullOrEmpty($targetUrl)){
            $PropertyValues["DestinationUrl"] = $targetUrl;
        }
        else{
            $PropertyValues["DestinationUrl"] = "Site provisioning not yet completed";
        }

        # Get Existing Banner Color
        $Global:ExistingBannerColor = $PropertyValues["BannerColor"];
        $PropertyValues["BannerColor"] = $bannerColor
        $PropertyValues["MigrationDate"] =[String]$migrationDate
        $Web.Update();
        ExecuteQueryWithIncrementalRetry $Ctx 3 5000
        
    } 
    Catch
    {
       throw
    }
}
            
#endregion
# Add-Banner Execution End---

#Step1 Initiate Permission Process, once successful completion of the CustomListActions and AdderPropertyBags values
Function Init-ReverseMigration-Banner(){

    try{

        $Global:isIssueNotExist = $true;
	  	$isNextSiteExist = $true;

        #$Global:bannerReadySites = Get-PreMigBannerSite;
       
        $filepath = $scriptRoot + "\ReverseMigration.csv"
        #$filepath = $scriptRoot + "\Reverse_Banners.csv"
		$Global:bannerReadySites = Import-csv $filepath;
      
        foreach($Global:bannerReadySite in $Global:bannerReadySites){
              
              $elapsed = [System.Diagnostics.Stopwatch]::StartNew()

            if(-not [string]::IsNullOrEmpty($bannerReadySite.OriginalUrl)){
                #region "Read Site Detail"
                $Global:_siteId = $bannerReadySite.SiteId;
                $Global:_batchId = $bannerReadySite.BatchId;
                $Global:_originalurl = $bannerReadySite.OriginalUrl;
                $targetURL = $bannerReadySite.TargetUrl;
                $Global:_sourceType = $bannerReadySite.SourceType;
                $Global:_bannerType = $bannerReadySite.BannerType;              						  
			    $SiteURL = $_originalurl;
                $migrationDate = $bannerReadySite.MigrationDate
                $Global:fk_Site = $_siteId;
                $BannerTypes = @{ "T-3" = 'CREAM'; "T-2" = 'YELLOW'; "T-1" = 'ORANGE'; "T" = 'RED'; "T-4" = 'GRAY' }
                $_bannerColor = $BannerTypes[$_bannerType];
                $bannerReadySite.SiteId = $bannerReadySite.SiteId.ToString();
                 
                    if(-not [string]::IsNullOrEmpty($_batchId)){
                        $Global:fk_Batch = $_batchId;
                    }
                    else{
                        $Global:fk_Batch = 0;
                    }
                    #endregion "Read Site Detail"
            
                  Try
                  {
                                 
			        #Step2 Get Context for Source and Target sites
                    if($_sourceType.ToLower().Trim().IndexOf("intranet") -ne -1) {
                    $Global:Ctx = Get-SPContext $SiteURL $sourceCredentials.LoginId $sourceSecurePassword
                    }
                    elseif($_sourceType.ToLower().Trim().IndexOf("extranet") -ne -1) {
                        $Global:Ctx = Get-SPContext $SiteURL $sourceExtranetCredentials.LoginId $sourceExtranetSecurePassword
                    }
                    else {
                        $Global:Ctx = Get-SPContext $SiteURL $sourceSpoCredentials.LoginId $sourceSpoSecurePassword
                    }

                    #Get the Web
                    $Site = $Ctx.Site;
                    $Ctx.Load($Site)
                    $Web = $Ctx.Web;
                    $Ctx.Load($Web);
                    $UserWebCustomActions = $Ctx.Web.UserCustomActions;
                    $PropertyValues = $Ctx.Web.AllProperties;
                    $Ctx.Load($UserWebCustomActions);
                    $Ctx.Load($PropertyValues);
                    #-----------------------------------  Execute Site Context -------------------------------------
                    $LogMessage = "Execute Site Context";         
                    ExecuteQueryWithIncrementalRetry $Ctx 3 5000;

            
                    if($($Web.Url.ToLower() -ne $($_originalurl.ToLower()))) {

                        $exception = "This site is not a valid site. Original URL:$($_originalurl). CSOM URL:$($Web.Url)"

                        $spProcResetAllStepsAfterReprocess = "sp_reset_allsteps_after_reprocess_banner"
                        $qryResetAllStepsAfterReprocess = "DECLARE @return_value int, @Returncode int  EXEC @return_value = $($spProcResetAllStepsAfterReprocess) @SiteID = $($fk_Site), @ReProcessStatus = 0, @Returncode = @Returncode OUTPUT"
                        $updateResetAllStepsAfterReprocess = Get-ContentFromSqlQuery $sqlConnection $qryResetAllStepsAfterReprocess

                        ExceptionLogs-InputParameters $bannerReadySite $sprocExcepLogsDynamicParameters "900" "Reprocess Banner: " $exception $exception            
                        $inputParameters = $sprocExcepLogsInputParameters,$sprocExcepLogsDynamicParameters
                        Execute-StrdProcWithParameters $sqlConnection $sprocExcepLogging $inputParameters $null
                        continue
                    }
                    elseif($Site.ReadOnly -eq $true) {
                        $exception = "This site is read-only. Original URL:$($_originalurl). "
                        $spProcResetAllStepsAfterReprocess = "sp_reset_allsteps_after_reprocess_banner"
                        $qryResetAllStepsAfterReprocess = "DECLARE @return_value int, @Returncode int  EXEC @return_value = $($spProcResetAllStepsAfterReprocess) @SiteID = $($fk_Site), @ReProcessStatus = 0, @Returncode = @Returncode OUTPUT"
                        $updateResetAllStepsAfterReprocess = Get-ContentFromSqlQuery $sqlConnection $qryResetAllStepsAfterReprocess
        
                        ExceptionLogs-InputParameters $bannerReadySite $sprocExcepLogsDynamicParameters "900" "Reprocess Banner: " $exception $exception            
                        $inputParameters = $sprocExcepLogsInputParameters,$sprocExcepLogsDynamicParameters
                        Execute-StrdProcWithParameters $sqlConnection $sprocExcepLogging $inputParameters $null
                        continue
                    }
                    elseif($Web.WebTemplate.ToLower() -ne "app"){
                        $migrationDate = "05/25/2021";
                        Add-Banner $targetURL $migrationDate $_bannerColor
                        Add-Content -Path $Global:logPath -Value "Added Banner for the Site Id: $($_siteId)"

                    }
                    else
                    {
                        $logMsg = "The App-Web-"+$SiteURL+" job steps status has been cancelled" 
			            [string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
			            Add-Content -Path $Global:logPath -Value $logMessage

                        $permissionLevel = $null;
                        $Ctx.Dispose();
                        $Global:isSetPermissionSuccess = $true;
                        $isNextSiteExist = $true;

                        $logMsg = "Get Next Pre Migration Site";
			            [string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
			            Add-Content -Path $Global:logPath -Value $logMessage
                    }

                #endregion ---- Get SPCredential -----
                $Ctx.Dispose();

            }
              catch{
                $logMsg = "Init-PreMigBannerSite : " +$_.Exception.Message
			    [string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)
                Write-Host $logMessage;   
			    Add-Content -Path $Global:logPath -Value $logMessage	
			    $isNextSiteExist = $true;
                                
                $exception = $($_.Exception.Message).Replace('"', '`"')
                Write-Host "$($bannerReadySite.SiteId) - $exception"
              }
           
        else {
            $logMsg = "This site is already rollbacked. SiteID: $($bannerReadySite.SiteId) and Original URL: $($bannerReadySite.OriginalUrl)";
			[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
			Add-Content -Path $Global:logPath -Value $logMessage
            Write-Host $logMsg

          }
        }
		else {
			$logMsg = "Next banner site not found for ready to proceed";
			[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
			Add-Content -Path $Global:logPath -Value $logMessage
			$isNextSiteExist = $False;
		}
        }
    }
    catch
    {
        $logMsg = "Error on Init-PreMigBannerSite: " +$_.Exception.Message
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
    }
}


#Fetching SQL Server Details
$sqlServerInstance = $configXmlfile.ConfigSettings.SqlSettings.SqlDbServer
$sqlDatabase = $configXmlfile.ConfigSettings.SqlSettings.SqlDatabase

#StoredProcedure - Change Status
$sprocStatusChange = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ChangeStatus.Name
$sprocStatusChangeInputParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ChangeStatus.InputParameters
$sprocStatusChangeDynamicParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ChangeStatus.DynamicInputParameters

#StoredProcedure - Exception logging
$sprocExcepLogging = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ExceptionLogging.Name
$sprocExcepLogsInputParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ExceptionLogging.InputParameters
$sprocExcepLogsDynamicParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ExceptionLogging.DynamicInputParameters

#Fetch SQL and SharePoint Credentials from Azure KeyVault
$azAppId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.ApplicationId
$azTenantId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.TenantId
$azCertificates = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.CertificateThumbprint
$azVault = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.VaultName
$azOrchDbUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.OrchestrationUserId
$azOrchDbPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.OrchestrationPassword

$azSourceIntranetUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceIntranetUserId
$azSourceIntranetPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceIntranetPassword
$azSourceExtranetUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceExtranetUserId
$azSourceExtranetPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceExtranetPassword
$azSourceSpoUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceSPOUserId
$azSourceSpoPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceSPOPassword

$azTargetUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.TargetUserId
$azTargetPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.TargetPassword

try{
	
	#Fetch Source Sites Credentials from Azure keyvault
	$sourceCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azSourceIntranetUserId $azSourceIntranetPassword -WarningAction SilentlyContinue
	$sourceSecurePassword = $sourceCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force

	#Fetch Source Extranet Sites Credentials from Azure keyvault
    if(-not [string]::IsNullOrEmpty($azSourceExtranetUserId)){
	    $sourceExtranetCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azSourceExtranetUserId $azSourceExtranetPassword -WarningAction SilentlyContinue    
	    $sourceExtranetSecurePassword = $sourceExtranetCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force
    }
    #Fetch Source SPO Sites Credentials from Azure keyvault
    if(!([String]::IsNullOrEmpty($azSourceSpoUserId)) -and !([String]::IsNullOrEmpty($azSourceSpoPassword))) {
        $sourceSpoCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azSourceSpoUserId $azSourceSpoPassword  -WarningAction SilentlyContinue       
        $sourceSpoSecurePassword = $sourceSpoCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force
    }

}
catch{
	$logMsg = "Exception in fetching Azure Keyvault details `n"+$_.Exception.Message
	[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
    Add-Content -Path $Global:logPath -Value $logMessage
}

#StoredProcedure - Fetch Banner sites
$preMigGetBanner = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.GetPreMigNextBannerSite.SPName
$appInstanceId = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.GetPreMigNextBannerSite.AppInstance
$updatePreMigBanner = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.UpdatePreMigNextBannerSite.SPName
$setPreMigToReady = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.SetPreMigToReady.SPName
$preMigStopBannerProcess = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.PreMigStopBannerProcess.SPName
# Tables
$migSitesPermissions = $configXmlfile.ConfigSettings.SqlSettings.Table.MigSitesPermissions;
$migSitesPermissionsT3 = $configXmlfile.ConfigSettings.SqlSettings.Table.MigSitesPermissionsT3;

#Banner Properties
$userCustomActionCDNPath = $configXmlfile.ConfigSettings.sp.banner.customactioncdnpath;
$userCustomActionCssCDNPath = $configXmlfile.ConfigSettings.sp.banner.customactioncsscdnpath;
$customActionTitle = $configXmlfile.ConfigSettings.sp.banner.customactiontitle;
$customActionSequenceNo = $configXmlfile.ConfigSettings.sp.banner.customactionsequenceno;

if($Ctx -ne $null){
  $Ctx.Dispose();
} 

#Build SQL Connection
#$sqlConnection = New-Object System.Data.SqlClient.SqlConnection
#$sqlConnection.ConnectionString = Get-SqlConnectionString $dbCredentials.LoginId $secureDbPassword $sqlServerInstance $sqlDatabase
#$sqlConnection.Open();

Create-LogFile "Reprocess_AllBanners"
Write-Log "----------Banner Reprocess started.............";

Init-ReverseMigration-Banner

#$sqlConnection.Close();

$logMsg = "Init-PreMigCommunicationBanner method ended!";
[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
Add-Content -Path $Global:logPath -Value $logMessage

$logMsg = "----------Banner process ended.............";
[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
Add-Content -Path $Global:logPath -Value $logMessage

