﻿#region Banner Process Desceription
    #Steps
    #
    #1. Get all the configuration values from Configuration.XML file
    #2. Import xml and .psm1 files
    #3. Get Migration Orchestration UserId and Password from Azure Keyvalut using Azure ApplicationId,TenantId and CertificateThumbprint
    #4. Connect Migration Orchestration DB - Open Sql Connection
    #5. Init-PreMigBannerSite - Main Function
    #6. Get the Next Banner Site from SP - sp_premig_next_banner_site
    #7. Connect SP Context
    #8. Validate the Banner Types( T-3 or T-2 OR T-1,T and Gray Banner ) 
    #			
    #	case  T-3
    #		- Extract Site and Lists Permissions from the Source Site and Bulk insert into the Mig_Permission_T3 Table
    #		- Set Banner Color to Cream
    #		- Change the current jop step to completed and set the next job step to "Ready to Start"
    #			
    #	case  T-2
    #		- Extract Site and Lists Permissions from the Source Site and Bulk insert into the Mig_Permission Table
    #		- Set Banner Color to Yellow
    #		- Set Contribute Permission to all the Permission Level in the Source Site(Except Contribute, Read, View Only and Limited Access)
    #		- Change the current jop step to completed and set the next job step to "Ready to Start"
    #	
    #	case  T-1	
    #		- Set Banner Color to Orange
    #		- Change the current jop step to completed and set the next job step to "Ready to Start"
    #		
    #	case  T	
    #		- Set Banner Color to Red
    #		- Set Read Permission to all the Permission Level in the Source Site(Except Read, View Only and Limited Access)
    #		- Change the current jop step to completed and set the next job step to "Ready to Start"
    #		
    #	Methods
    #          -Init-PreMigBannerSite
    #		   -Init-SitePermissionsExtractProcess
    #		   -Add-Banner Method
    #				- Inject BannerCustomUserAction.js and BannerStyleSheet.css
    #				- Add Custom Action
    #				- Add Properties
    #		   -Init-SitePermissionsSetProcess
    #		   -Set-PreMigUpdateBannerStatus
    #		   -Exception
    #				Set-IsPermissionSuccess
    #		
    #	Dispose current SP Context
    #	Iterate Next Site
    #	
    #End Close the Sql Connection

#endregion

#region Variable Declaration
Get-Module | Remove-Module -Force
$Host.UI.RawUI.BackgroundColor = ($bckgrnd = 'DarkBlue')
$Host.UI.RawUI.ForegroundColor = 'White'
$Host.PrivateData.ErrorForegroundColor = 'Red'
$Host.PrivateData.ErrorBackgroundColor = $bckgrnd
$Host.PrivateData.WarningForegroundColor = 'Magenta'
$Host.PrivateData.WarningBackgroundColor = $bckgrnd
$Host.PrivateData.DebugForegroundColor = 'Yellow'
$Host.PrivateData.DebugBackgroundColor = $bckgrnd

Clear-Host
#Load XML Config File
$scriptRoot = Split-Path $MyInvocation.MyCommand.Path -Parent
$parentRoot = (Get-Item $scriptRoot).Parent.FullName
$configfolder = Join-Path $parentRoot.ToLower().Replace('\cts\','\ey\') "CTS-Mig-0Settings"
$xmlConfigPath =  Join-Path $configfolder "ConfigurationSettings.xml"
$configXmlfile = [xml]$(Get-Content $xmlConfigPath)

#Load Module files - Reusable methods, Apply Permissions
$modulesFolder = Join-Path $parentRoot $configXmlfile.ConfigSettings.CommonSettings.Modules.Name
$modulesPath = Join-Path $modulesFolder $configXmlfile.ConfigSettings.CommonSettings.Modules.Value
$rolebackPermissionsModule = Join-Path $scriptRoot $configXmlfile.ConfigSettings.CommonSettings.RolebackPermissions.Value
Import-Module -Name $modulesPath -WarningAction SilentlyContinue
Import-Module -Name $rolebackPermissionsModule -WarningAction SilentlyContinue

#Load SharePoint CSOM Assemblies
$spoModulesRefPath = $configXmlfile.ConfigSettings.CommonSettings.SPOnlineReferencesPath.Value
Import-Module -Name $spoModulesRefPath -DisableNameChecking
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client")
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client.Runtime")

#Load SharePoint PnP PowerShell Online Assemblies
$spPnPPSModulesRefPath = $configXmlfile.ConfigSettings.CommonSettings.SharePointPnPPowerShellOnline.Value
Import-Module -Name $spPnPPSModulesRefPath -DisableNameChecking

#Load Azure Moodules
$azureAccountsPsd = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.AzureAccountsPsd
$azureKeyvaultsPsd = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.AzureKeyvaultsPsd
Import-Module -Name $azureAccountsPsd
Import-Module -Name $azureKeyvaultsPsd

# Permission Level to be changed
$permissionLevel = $null;

#Add-Content -Path $logPath -Value "Adding datatable header"
$dataTable = New-Object System.Data.DataTable
$dataTable.Columns.Add("ID", "System.Int32") | Out-Null
$dataTable.Columns.Add("fk_site", "System.Int32") | Out-Null
$dataTable.Columns.Add("fk_batch", "System.Int32") | Out-Null
$dataTable.Columns.Add("TypeOfContent", "System.String") | Out-Null
$dataTable.Columns.Add("SiteName", "System.String") | Out-Null
$dataTable.Columns.Add("SourceURL", "System.String") | Out-Null
$dataTable.Columns.Add("Inheritance", "System.String") | Out-Null
$dataTable.Columns.Add("UserGroup", "System.String") | Out-Null
$dataTable.Columns.Add("Principaltype", "System.String") | Out-Null
$dataTable.Columns.Add("Accountname", "System.String") | Out-Null
$dataTable.Columns.Add("ContentPermissions", "System.String") | Out-Null
		
[int]$Global:fk_Site = 0;
[int]$Global:fk_Batch = 0;

$Global:ExistingBannerColor = "";
$Global:BannerType = "";
$Global:isSetPermissionSuccess = $true;

$_fullControl = "Full Control";
$_contribute = "Contribute";
$_read = "Read";
$_viewOnly = "View Only";
$_limitedAccess = "Limited Access";
$_editEdit = "Edit";

$Global:batchNo = 0;

#endregion

Function Create-LogFile($fileName){
    $date= Get-Date -format MMddyyyyHHmmss  
    $enddate = (Get-Date).tostring("yyyyMMddhhmmss")
    $logFileName = $fileName +"_"+ $enddate+"_Log.txt"   
    $Global:directoryPathForLog = $scriptRoot+"\"+"LogFiles"
    if(!(Test-Path -path $directoryPathForLog))  
    {  
        New-Item -ItemType directory -Path $directoryPathForLog          
    }
    $Global:logPath = $directoryPathForLog + "\" + $logFileName
    $Global:isLogFileCreated = $true
}

Function Write-Log([string]$logMsg)  
{   
    if(!$isLogFileCreated){   
        #Write-Host "Creating Log File..."   
        if(!(Test-Path -path $directoryPathForLog))  
        {  
            #Write-Host "Please Provide Proper Log Path" -ForegroundColor Red   
        }   
        else   
        {   
            $Global:isLogFileCreated = $true   
            [string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
            Add-Content -Path $Global:logPath -Value $logMessage   
        }   
    }   
    else   
    {   
        [string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage   
    }   
}

Create-LogFile "premigBanner"
Write-Log "----------Banner process started.............";

#Step7 To call a non-generic method Load
Function Invoke-LoadMethod() {
    param(
            [Microsoft.SharePoint.Client.ClientObject]$Object = $(throw "Please provide a Client Object"),
            [string]$PropertyName
        )
   $ctx = $Object.Context
   $load = [Microsoft.SharePoint.Client.ClientContext].GetMethod("Load")
   $type = $Object.GetType()
   $clientLoad = $load.MakeGenericMethod($type)
   
   $Parameter = [System.Linq.Expressions.Expression]::Parameter(($type), $type.Name)
   $Expression = [System.Linq.Expressions.Expression]::Lambda([System.Linq.Expressions.Expression]::Convert([System.Linq.Expressions.Expression]::PropertyOrField($Parameter,$PropertyName),[System.Object] ), $($Parameter))
   $ExpressionArray = [System.Array]::CreateInstance($Expression.GetType(), 1)
   $ExpressionArray.SetValue($Expression, 0)
   $clientLoad.Invoke($ctx,@($Object,$ExpressionArray))
}

#Step6 to Step7 Function to Get Permissions Applied on a particular Object, such as: Web, List or Item
Function GetSet-Permissions([Microsoft.SharePoint.Client.SecurableObject]$Object, 
[Parameter(Mandatory=$False)][String]$ProcessType="SetPermission",
[Parameter(Mandatory=$False)][String]$objectType="List")
{
    #Get permissions assigned to the object
    $Ctx.Load($Object.RoleAssignments)
    ExecuteQueryWithIncrementalRetry $Ctx 3 5000;

    if($ProcessType -eq "GetPermission"){
        #GetPermission
        #region Determine the type of the object
        Switch($Object.TypedObject.ToString())
        {
            "Microsoft.SharePoint.Client.Web"  { $ObjectType = "Site" ; $ObjectURL = $Object.URL }
            Default
            {
                $ObjectType = "List/Library"
                #Get the URL of the List or Library
                $Ctx.Load($Object.RootFolder)
                ExecuteQueryWithIncrementalRetry $Ctx 3 5000;           
                $ObjectURL = $("{0}{1}" -f $Ctx.Web.Url.Replace($Ctx.Web.ServerRelativeUrl,''), $Object.RootFolder.ServerRelativeUrl)
            }
        }
    #endregion 		
		
		$logMsg = $ObjectType + "("+ $Object.Title +") Extract Permission started-----------";
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
		
		$logMsg = $ObjectType + "("+ $Object.Title +") Role Assignments count is " + $Object.RoleAssignments.Count	
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
		
        Foreach($RoleAssignment in $Object.RoleAssignments)
        {
		    $Ctx.Load($RoleAssignment.Member);
		
		    #Get the Permissions on the given object
		    $Permissions=@()
		    $Ctx.Load($RoleAssignment.RoleDefinitionBindings)
		    ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
	
			$Permissions="";
		    Foreach ($RoleDefinition in $RoleAssignment.RoleDefinitionBindings)
		    {
		       if($RoleDefinition.Name -ne "Limited Access")
		       {
			    $Permissions += $RoleDefinition.Name +";"
		       }
		    }
			
			$LogMessage = "`tRole Assignment("+$RoleAssignment.Member.Title+")'s Role Definition Bindings count is " + $RoleAssignment.RoleDefinitionBindings.Count
			$logMsg = $LogMessage + " and their permission(s) are "+ $Permissions+" which excludes Limited Access";
			[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
			Add-Content -Path $Global:logPath -Value $logMessage
			
		    if(-not [string]::IsNullOrEmpty($Permissions))
		    {
			    #Check direct permissions
			    if($RoleAssignment.Member.PrincipalType -eq "User")
			    {
				    #$TargetAbsoluteURL=$($ObjectURL).Replace($($SourceURL),$($TargetURL))
				    $dataTable.Rows.Add(0,[int]$fk_Site,[int]$fk_Batch,$($ObjectType),$($Object.Title),$($ObjectURL),'Custom','User',$($RoleAssignment.Member.LoginName),$($RoleAssignment.Member.Title),$($Permissions)) | Out-Null
                }
			  
			    ElseIf($RoleAssignment.Member.PrincipalType -eq "SharePointGroup")
			    {       
				    $dataTable.Rows.Add(0,[int]$fk_Site,[int]$fk_Batch,$($ObjectType),$($Object.Title),$($ObjectURL),'Custom','SharePoint Group',$($RoleAssignment.Member.LoginName),$($RoleAssignment.Member.Title),$($Permissions)) | Out-Null
                }
			    ElseIf($RoleAssignment.Member.PrincipalType -eq "SecurityGroup")
			    {
				    $dataTable.Rows.Add(0,[int]$fk_Site,[int]$fk_Batch,$($ObjectType),$($Object.Title),$($ObjectURL),'Custom','Security Group',$($RoleAssignment.Member.LoginName),$($RoleAssignment.Member.Title),$($Permissions)) | Out-Null    
                }
                
	       }
        }
        
		$logMsg = $ObjectType + "("+ $Object.Title +") Extract Permission ended-----------";
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
    }
    else{
      #SetPermission

        $RoleDefinitions;
        try{
            $Ctx.Load($Object.RoleDefinitions)
            $RoleDefinitions = $Object.RoleDefinitions
        }
        catch{
            try
            {
                $Ctx.Load($Object.ParentWeb.RoleDefinitions)
                $RoleDefinitions = $Object.ParentWeb.RoleDefinitions
            }
            catch{
                $Ctx.Load($Object.ParentList.ParentWeb.RoleDefinitions)
                $RoleDefinitions = $Object.ParentList.ParentWeb.RoleDefinitions
            }
        }
   
        try{
		
        $Ctx.Load($RoleDefinitions);
        ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
    
        # Get object of the change permission level for updating the existing role
		$changeRole = $RoleDefinitions | Where-Object -FilterScript { $_.Name -eq $permissionLevel } 
            		
			Foreach($RoleAssignment in $Object.RoleAssignments)
			{
				$Ctx.Load($RoleAssignment.Member); 
				$Ctx.Load($RoleAssignment.RoleDefinitionBindings)
				ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
				
				$isRoleNotFountCnt = 0;

				if($permissionLevel -eq "Read"){
				   
					Foreach ($RoleDefinition in $RoleAssignment.RoleDefinitionBindings)
					{
						if(($RoleDefinition.Name -ne $_read) -and ($RoleDefinition.Name -ne $_viewOnly) -and
						($RoleDefinition.Name -ne $_limitedAccess))
						{
							$isRoleNotFountCnt++;
						}
					}
				}
				else{
					Foreach ($RoleDefinition in $RoleAssignment.RoleDefinitionBindings)
					{
						if(($RoleDefinition.Name -ne $_contribute) -and ($RoleDefinition.Name -ne $_read) -and 
						($RoleDefinition.Name  -ne $_viewOnly) -and ($RoleDefinition.Name -ne $_limitedAccess) -and 
						($RoleDefinition.Name -ne $_editEdit))
						{
						  $isRoleNotFountCnt++;
						}		   
					} 
				}
				if($isRoleNotFountCnt -gt 0) 
				{
					$RoleAssignment.RoleDefinitionBindings.RemoveAll()    
					$RoleAssignment.RoleDefinitionBindings.Add($changeRole);
					$RoleAssignment.Update();
					$logMsg = "`t Role " + $RoleAssignment.Member.Title +" Role(s) have been removed and replaced by "+ $permissionLevel;
					[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
					Add-Content -Path $Global:logPath -Value $logMessage
				}
				else{
					#$LogMessage = "Skipping this one since it is a Read Role : " + $RoleAssignment.Member.Name;
				} 
			}            
        }
        catch
        {
            Set-IsPermissionSuccess
            $logMsg = "Error on GetSet-Permissions!" +$_.Exception.Message
			[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
			Add-Content -Path $Global:logPath -Value $logMessage
            Set-ChangeStatus $logMsg $($_.ScriptStackTrace);
			Start-Sleep 5
        }
    }
}

#Step3 PowerShell to get SharePoint Site Permissions
Function Init-SitePermissionsExtractProcess([Microsoft.SharePoint.Client.ClientContext]$Ctx, [Microsoft.SharePoint.Client.Web]$Web)
{
    Try {
        $logMsg = "------------------ Getting the Permissions of Web started ----------------";
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
        
		$elapsed = [System.Diagnostics.Stopwatch]::StartNew()
		$Time = Get-Date #-format "yyyy-MM-dd-HH-mm-ss-ff"
        $logMsg = "Web Permission Extraction Start: "+$Time;
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
		
        #Check if Generate-SPOSitePermissionRpt the Web has unique permissions
        Invoke-LoadMethod -Object $Web -PropertyName "HasUniqueRoleAssignments"
        ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
        #If($web.HasUniqueRoleAssignments -eq $true) {  }
        GetSet-Permissions -Object $Web -ProcessType "GetPermission" -objectType "Web"

		$Time = Get-Date #-format "yyyy-MM-dd-HH-mm-ss-ff"
        $logMsg = "Web Permission Extraction End: "+$Time;
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
		
        $logMsg = "------------------ Getting the Permissions of Web ended----------------";
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
        
        $logMsg = "------------------ Getting the Permissions of Lists and Libraries started----------------";
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
        
		$elapsed = [System.Diagnostics.Stopwatch]::StartNew()
		$Time = Get-Date #-format "yyyy-MM-dd-HH-mm-ss-ff"
        $logMsg = "List(s) Permission Extraction Start: "+$Time;
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
		
        #Get All Lists from the web
        $Lists = $Web.Lists
        $Ctx.Load($Lists)
        ExecuteQueryWithIncrementalRetry $Ctx 3 5000;

        #Get Permissions of all lists from the web
        #Get all lists from the web  
        ForEach($List in $Lists)
        {
				
            #Exclude System Lists
            If($List.Hidden -eq $False)
            {
                    
                #Get the Lists with Unique permission
                Invoke-LoadMethod -Object $List -PropertyName "HasUniqueRoleAssignments"
                ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
  
                If( $List.HasUniqueRoleAssignments -eq $True)
                {
                    #Call the function to check permissions
                    GetSet-Permissions -Object $List -ProcessType "GetPermission" -objectType "List"
                }
            }
        }

		$Time = Get-Date #-format "yyyy-MM-dd-HH-mm-ss-ff"
        $logMsg = "List(s) Permission Extraction End: "+$Time;
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
 
        $logMsg = "List(s) Permission Extraction Duration -"+ $($elapsed.Elapsed.ToString());
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
        
		$logMsg = "------------------ Getting the Permissions of Lists and Libraries ended----------------";
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
        
		$elapsed = [System.Diagnostics.Stopwatch]::StartNew()
		$Time = Get-Date #-format "yyyy-MM-dd-HH-mm-ss-ff"
        $logMsg = "Execute Bulk Sql Query Start: "+$Time;
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
		
        if($BannerType -eq "T-3"){
            $tableName = $migSitesPermissionsT3;
        }
		else{
		   $tableName = $migSitesPermissions;
		}

        $itemCopy = Execute-BulkSqlQuery $sqlConnection $tableName $dataTable	
		$Time = Get-Date #-format "yyyy-MM-dd-HH-mm-ss-ff"
        
		$logMsg = "Execute Bulk Sql Query End: "+$Time;
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
        
		$logMsg = "Site("+$_siteId+") Permission Report Generated Successfully!";
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
    
	}
    Catch {
        $logMsg = "Error Generating Site Permission Report " +$_.Exception.Message
        Set-IsPermissionSuccess
		Set-ChangeStatus $logMsg $($_.ScriptStackTrace);
        Start-Sleep 5
    }
	finally{
	    $dataTable.Rows.Clear();
        $dataTable.Clear();
	}
}

Function Check-PreMigStopBannerProcess() {

    try {
        $sqlCommand = New-Object System.Data.SqlClient.SqlCommand
        $sqlCommand.CommandText = $preMigStopBannerProcess;
        $sqlCommand.Connection = $sqlConnection
        $sqlCommand.CommandType = [System.Data.CommandType]::StoredProcedure
        $sqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter  
        $sqlAdapter.SelectCommand = $sqlCommand
        $sqlAdapter.SelectCommand.CommandTimeout=0  
        #Creating Dataset  
        $dataSet = New-Object System.Data.DataSet   
        $sqlAdapter.Fill($dataSet)
		$data = $dataSet.Tables[0];
        
        $Global:isStopBannerProcess = $false;

        # 1 => Stop
        # 0 => Start

        if($appInstanceId -eq "7-2"){
            if($data.AUS_StartBannerProcess -eq 1){
                $Global:isStopBannerProcess = $true;
            }
        }
        if($appInstanceId -eq "47-2"){
            if($data.Canada_StartBannerProcess -eq 1){
                $Global:isStopBannerProcess = $true;
            }
        }
        if($appInstanceId -eq "23-2"){
            if($data.Ecuador_StartBannerProcess -eq 1){
                $Global:isStopBannerProcess = $true;
            }
        }
        if($appInstanceId -eq "59-2"){
            if($data.US_StartBannerProcess -eq 1){
                $Global:isStopBannerProcess = $true;
            }
        }
 
    }
    catch {
        $logMsg = $_.Exception.Message
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
    }  
}


# Execute the Stored Procedure to get the PreMigBanner next site
#Step0
Function Get-PreMigBannerSite() {
    $results;
    try {
        $sqlCommand = New-Object System.Data.SqlClient.SqlCommand
        $sqlCommand.CommandText = $preMigGetBanner;
        $sqlCommand.Connection = $sqlConnection
        $sqlCommand.CommandType = [System.Data.CommandType]::StoredProcedure

        $AppInstance = New-Object System.Data.SqlClient.SqlParameter;
        $AppInstance.ParameterName = "@AppInstance";
        $AppInstance.Direction = [System.Data.ParameterDirection]::Input
        $AppInstance.Value = $appInstanceId;

        $Returncode = New-Object System.Data.SqlClient.SqlParameter
        $Returncode.ParameterName = "@Returncode";
        $Returncode.Direction = [System.Data.ParameterDirection]::Output
        $Returncode.DbType = [System.Data.DbType]::Int32

        $ReloadCode = New-Object System.Data.SqlClient.SqlParameter
        $ReloadCode.ParameterName = "@ReloadCode";
        $ReloadCode.Direction = [System.Data.ParameterDirection]::Output
        $ReloadCode.DbType = [System.Data.DbType]::Int32
                        
        $sqlCommand.Parameters.Add($AppInstance) | Out-Null
        $sqlCommand.Parameters.Add($Returncode) | Out-Null
        $sqlCommand.Parameters.Add($ReloadCode) | Out-Null

        $sqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter  
        $sqlAdapter.SelectCommand = $sqlCommand
        $sqlAdapter.SelectCommand.CommandTimeout=0  
        #Creating Dataset  
        $dataSet = New-Object System.Data.DataSet   
        $sqlAdapter.Fill($dataSet)
        $_returnCode = $Returncode.Value
		
		if($_returnCode -eq 1){
		   #$results = (0, $dataSet.Tables[0].Rows)[$dataSet.Tables[0].Rows.Count -gt 0]
		   #Get single table from dataset
		   $data = $dataSet.Tables[0]
		   return $data;
		}
       
    }
    catch {
        $logMsg = $_.Exception.Message
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
    }  
}

# Execute the Stored Procedure to get the PreMigBanner next site
#Step0
Function Check-PreMigBannerPermissionValidation() {
    $results;
    try {
        $preMigBannerPermissionValidation = "sp_premig_banner_permissions_validation"
        $sqlCommand = New-Object System.Data.SqlClient.SqlCommand
        $sqlCommand.CommandText = $preMigBannerPermissionValidation
        $sqlCommand.Connection = $sqlConnection
        $sqlCommand.CommandType = [System.Data.CommandType]::StoredProcedure

        $SiteId = New-Object System.Data.SqlClient.SqlParameter
        $SiteId.ParameterName = "@SiteID"
        $SiteId.Direction = [System.Data.ParameterDirection]::Input
        $SiteId.Value = $Global:fk_Site;
        $sqlCommand.Parameters.Add($SiteId) | Out-Null

        $sqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter  
        $sqlAdapter.SelectCommand = $sqlCommand
        $sqlAdapter.SelectCommand.CommandTimeout=0  
        #Creating Dataset  
        $dataSet = New-Object System.Data.DataSet   
        $sqlAdapter.Fill($dataSet)
		$data = $dataSet.Tables[0]
        
        If($data.ReturnCode -eq 1){
            $Global:isT3PermissionExist = $true
        }
        Else{
            $Global:isT3PermissionExist = $false
            Set-IsPermissionSuccess
        }
		return $data;
    }
    catch {
        $logMsg = $_.Exception.Message
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
    }  
}



Function Check-IsSiteExist($sqlQuery) {
    try {
       
        $sqlCommand = New-Object System.Data.SqlClient.SqlCommand
        $sqlCommand.CommandText = $sqlQuery
        $sqlCommand.Connection = $sqlConnection
        $sqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter  
        $sqlAdapter.SelectCommand = $sqlCommand
        $sqlAdapter.SelectCommand.CommandTimeout=0   
        $dataSet = New-Object System.Data.DataSet  
        $sqlAdapter.Fill($dataSet)

        $results = (0, $dataSet.Tables[0].Rows)[$dataSet.Tables[0].Rows.Count -gt 0]
       
        return $results;

    }
    catch {
        $logMsg = $_.Exception.Message;
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)  
        Add-Content -Path $Global:logPath -Value $logMessage
    }    
    
}

#FinalStep Execute Stored Procedure to update the status of the successful completion of the Banner and Set Permision process
Function Set-PreMigUpdateBannerStatus($siteId,$bannerId,$currentJobStep,$nextJobStep) {
    try {
        
		$elapsed = [System.Diagnostics.Stopwatch]::StartNew()
		$Time = Get-Date #-format "yyyy-MM-dd-HH-mm-ss-ff"
		$logMsg = "Set PreMig Update Banner Status Start: "+$Time;
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
				
        $sqlCommand = New-Object System.Data.SqlClient.SqlCommand
        $sqlCommand.CommandText = $updatePreMigBanner;
        $sqlCommand.Connection = $sqlConnection
        $sqlCommand.CommandType = [System.Data.CommandType]::StoredProcedure

        $_siteId = [Int]$siteId
        $_bannerId = [Int]$bannerId
        $_currentJobStep = try { [Int]$currentJobStep } catch { 0 }
		$_nextJobStep = try { [Int]$nextJobStep } catch { 0 }

        $SiteID = New-Object System.Data.SqlClient.SqlParameter
        $SiteID.ParameterName = "@SiteID";
        $SiteID.Direction = [System.Data.ParameterDirection]::Input
        $SiteID.Value = $_siteId

        $BannerID = New-Object System.Data.SqlClient.SqlParameter
        $BannerID.ParameterName = "@BannerID";
        $BannerID.Direction = [System.Data.ParameterDirection]::Input
        $BannerID.Value = $_bannerId

        $CurrentJobStep = New-Object System.Data.SqlClient.SqlParameter
     	$CurrentJobStep.ParameterName = "@currentJobStep";
     	$CurrentJobStep.Direction = [System.Data.ParameterDirection]::Input
     	$CurrentJobStep.Value = $_currentJobStep
		
		$NextJobStep = New-Object System.Data.SqlClient.SqlParameter
     	$NextJobStep.ParameterName = "@NextJobStep";
     	$NextJobStep.Direction = [System.Data.ParameterDirection]::Input
     	$NextJobStep.Value = $_nextJobStep
        
        $Returncode = New-Object System.Data.SqlClient.SqlParameter
        $Returncode.ParameterName = "@Returncode";
        $Returncode.Direction = [System.Data.ParameterDirection]::Output
        $Returncode.DbType = [System.Data.DbType]::Int32
        
        $sqlCommand.Parameters.Add($SiteID) | Out-Null
        $sqlCommand.Parameters.Add($BannerID) | Out-Null
        $sqlCommand.Parameters.Add($CurrentJobStep) | Out-Null
		$sqlCommand.Parameters.Add($NextJobStep) | Out-Null
        $sqlCommand.Parameters.Add($Returncode) | Out-Null
		
        $sqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter  
        $sqlAdapter.SelectCommand = $sqlCommand
        $sqlAdapter.SelectCommand.CommandTimeout=0   
        #Creating Dataset  
        $dataSet = New-Object System.Data.DataSet   
        $sqlAdapter.Fill($dataSet)
        $_returnCode = $Returncode.Value

		$Time = Get-Date #-format "yyyy-MM-dd-HH-mm-ss-ff"
		$logMsg = "Set PreMig Update Banner Status End: "+$Time;
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
		
		$logMsg = "Set PreMig Update Banner Status Duration: "+$($elapsed.Elapsed.ToString());
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
				
        # Remove or rollback the permission, If issue ecist in the SQP Banner Update procedure
        if($_returnCode -eq 0){
            #Revoke-SPPropertyBagValues
        }
        if($_returnCode -eq 1){
            
            #*************************************************************************
                $logMsg = "`t Banner and Set Permission have been completed successfully!"
            #*************************************************************************
			[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
			Add-Content -Path $Global:logPath -Value $logMessage
        }
    }
    catch {
        $logMsg = $_.Exception.Message
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage       
    }    
}

#Step6 Required to revert back the previous Banner Color to the site
#Update the Property Bags values based on the set permission and migration banner update status in SQL
Function Revoke-SPPropertyBagValues(){
    #[Microsoft.SharePoint.Client.Web]$Web
    $credentials = Get-SPCredentials -Url $SiteURL -UserName $srcUserName -Password $srcPassword
   
    #Setup the context
    $Ctx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteURL)
    $Ctx.Credentials = $Credentials
    $Ctx.add_ExecutingWebRequest({
        param($objSender, $eventArgs)
        $eventArgs.WebRequestExecutor.WebRequest.Headers.Add("X-FORMS_BASED_AUTH_ACCEPTED", "f")
    }) 

    #Get the Web
    $Web = $Ctx.Web
    $Ctx.Load($Web)
    ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
    
    $propertyBagValues = $config.configsettings.sp.banner.propertybagvalues;
    $propertyBags = $propertyBagValues.split(";");

    $Ctx.Load($Web.AllProperties);
    ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
    $propDestinationUrl = "";
    try{
        foreach($propertyBag in $propertyBags){
            
            $bannerColors = @('CREAM','YELLOW','ORANGE','RED','GRAY');
            $bannerColor = $null;

            if($BannerType -eq "T-3"){
                $bannerColor = $null;
            }
            if($BannerType -eq "T-2"){
                $bannerColor = $bannerColors[0];
            }
            if($BannerType -eq "T-1"){
                $bannerColor = $bannerColors[1];
            }
            if($BannerType -eq "T"){
                $bannerColor = $bannerColors[2];
            }

            if($Web.AllProperties.FieldValues.ContainsKey($propertyBag)){
               $Web.AllProperties[$propertyBag] = $ExistingBannerColor; #$bannerColor;
               $Web.Update();
               ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
            }
        }

    }
    catch{
        $logMsg = $_.Exception.Message
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
    }
}

#Set value as False to the isSetPermissionSuccess variable
Function Set-IsPermissionSuccess(){
   $Global:isSetPermissionSuccess = $False;
}

#Step1 Initiate Permission Process, once successful completion of the CustomListActions and AdderPropertyBags values
Function Init-PreMigBannerSite(){

    try{

        # Get the next Banner Site
        # Dafault value - "isManual" is True
        # And the system loop again the function, If manula not exist and set the value as false to the variable "isManual"

        #-----------------------------------  Get PreMigration Process --------------------------------
        
        $StartTime = Get-Date
        $logMsg = "Banner Action Start Time: "+$StartTime;
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
		
        $Global:isIssueNotExist = $true;
	  	$isNextSiteExist = $true;

      while($isNextSiteExist){
		
		if($sqlConnection.State -ne "Open") {
            $sqlConnection.Open()
        }

        Check-PreMigStopBannerProcess;

        if($isStopBannerProcess -eq $False){
   
			
        $elapsed = [System.Diagnostics.Stopwatch]::StartNew();
		$StartTime = Get-Date
		
		$logMsg = "Get Banner Next Site From SP Start Time: "+$StartTime;
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
		#Get Banner Site Ready for Banner
		$Global:bannerReadySite = Get-PreMigBannerSite;
		
		$EndTime = Get-Date
		$logMsg = "Get Banner Next Site From SP End Time: "+$EndTime;
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
		
		$logMsg ="Get Banner Next Site Duration - "+ $($elapsed.Elapsed.ToString());
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
	    
        if(-not [string]::IsNullOrEmpty($bannerReadySite.SiteId)){

          #region "Read Site Detail"

                $Global:_siteId = $bannerReadySite.SiteId;
                $Global:_batchId = $bannerReadySite.BatchId;
                $_bannerId = $bannerReadySite.BannerId;
                $Global:_originalurl = $bannerReadySite.OriginalUrl;
                $Global:_targetUrl = $bannerReadySite.TargetUrl;
                $_bannerType = $bannerReadySite.BannerType;
                $_migrationDate = $bannerReadySite.MigrationStartDate;
			    $Global:currentJobStep = $bannerReadySite.currentJobStep;
                $_nextJobStep = $bannerReadySite.NextJobStep;
                $Global:_sourceType = $bannerReadySite.SourceType;
                $Global:_presentJobStep = [Int]$currentJobStep;
                                    						  
			    $SiteURL = $_originalurl;
                $BannerType = $_bannerType;
			    $permissionLevel = $null;
                $BannerTypes = @{ "T-3" = 'CREAM'; "T-2" = 'YELLOW'; "T-1" = 'ORANGE'; "T" = 'RED'; "T-4" = 'GRAY' }
                $_bannerColor = $BannerTypes[$_bannerType];
			
			    $PermissionLevels = @{ "T-2" = 'Contribute'; "T" = 'Read' }
			    $permissionLevel = $PermissionLevels[$_bannerType];

                $Global:isSetPermissionSuccess = $true;
			                          
			    $TextColors = @{ "T-3" = 'Cyan'; "T-2" = 'Yellow'; "T-1" = 'Magenta'; "T" = 'Red'; "T-4" = 'Gray' }
			    $TextColor = $TextColors[$_bannerType]

                $Global:fk_Site = $_siteId;
                if(-not [string]::IsNullOrEmpty($_batchId)){
                    $Global:fk_Batch = $_batchId;
                }
                else{
                    $Global:fk_Batch = 0;
                }
              
                if($Global:batchNo -ne $Global:fk_Batch){
                    $_fileName = "premigBanner_Batch"+$Global:fk_Batch;
                    $Global:batchNo = $Global:fk_Batch;
                    Create-LogFile $_fileName;
                }   			    

			
            Function BannerSiteInfo(){
                $logMsg = "Site Id:" +$_siteId;
					[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
					Add-Content -Path $Global:logPath -Value $logMessage
                $logMsg = "Batch Id:" +$_batchId;
					[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
					Add-Content -Path $Global:logPath -Value $logMessage
                $logMsg = "Source Site Url:" +$_originalurl;
					[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
					Add-Content -Path $Global:logPath -Value $logMessage
                $logMsg = "Target Site Url:" +$_targetUrl;
					[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
					Add-Content -Path $Global:logPath -Value $logMessage
                $logMsg = "Banner Id:" +$_bannerId;
					[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
					Add-Content -Path $Global:logPath -Value $logMessage
                $logMsg = "Banner Type:" +$BannerType;
					[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
					Add-Content -Path $Global:logPath -Value $logMessage
                $logMsg = "Banner Color:" +$_bannerColor;
					[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
					Add-Content -Path $Global:logPath -Value $logMessage
                $logMsg = "Migration Date:" +$_migrationDate;
					[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
					Add-Content -Path $Global:logPath -Value $logMessage
                $logMsg = "Source Type:" +$_sourceType;
					[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
					Add-Content -Path $Global:logPath -Value $logMessage
            }

            #-------------- Banner Site Info -----------
            BannerSiteInfo
            #-----------------------------------  Banner Site Info -------------------------------------

            #endregion "Read Site Detail"
           
            try
            {
                $jobFailuresTable = "Mig_Sites_MigrationJobFailures"
                $query_UpdateJobFailuresTable = "update [$jobFailuresTable] set DefectStatus='Closed' where fk_jobStep="+$([int]$_presentJobStep)+" and fk_Batch=" + $([int]$fk_Batch) + " and fk_Site=" + $([int]$fk_Site)
                Execute-SqlQuery $sqlConnection $query_UpdateJobFailuresTable
            }
            catch
            {
                $logMsg = "Update MigrationJobFailures Failure: " +$_.Exception.Message         
	            [string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
	            Add-Content -Path $Global:logPath -Value $logMessage
            }            
          Try
          {
            
                    
            #region ---- Get SPCredential -----

            $logMsg = "Get SPCredential for the Site Id: " + $_siteId         
			[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
			Add-Content -Path $Global:logPath -Value $logMessage
			
			#Step2 Get Context for Source and Target sites
            if($_sourceType.ToLower().Trim().IndexOf("intranet") -ne -1) {
            $Global:Ctx = Get-SPContext $SiteURL $sourceCredentials.LoginId $sourceSecurePassword
            }
            elseif($_sourceType.ToLower().Trim().IndexOf("extranet") -ne -1) {
                $Global:Ctx = Get-SPContext $SiteURL $sourceExtranetCredentials.LoginId $sourceExtranetSecurePassword
            }
            else {
                $Global:Ctx = Get-SPContext $SiteURL $sourceSpoCredentials.LoginId $sourceSpoSecurePassword
            }

            #Get the Web
            $Web = $Ctx.Web
            $Ctx.Load($Web)

            $UserCustomActions = $Ctx.Site.UserCustomActions
            $PropertyValues = $Ctx.Web.AllProperties
            $Ctx.Load($UserCustomActions)
            $Ctx.Load($PropertyValues)
            Invoke-LoadMethod -Object $Web -PropertyName "HasUniqueRoleAssignments"

            #-----------------------------------  Execute Site Context -------------------------------------
            $LogMessage = "Execute Site Context";         
            ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
			$logMsg = "Connection Established successfully for the Site: "+ $SiteURL;         
			[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
			Add-Content -Path $Global:logPath -Value $logMessage
            
            #endregion ---- Get SPCredential -----

            #Check if Web Template is AppWeb
            if($Web.WebTemplate.ToLower() -ne "app"){

			#Step4 Add-Banner Execution Start--  
            #region --- Add Banner Execution Start ---

            Function Add-Banner($targetUrl, $migrationDate, $bannerColor)
            {
                Try 
                {
				
				$elapsed = [System.Diagnostics.Stopwatch]::StartNew()
				$Time = Get-Date #-format "yyyy-MM-dd-HH-mm-ss-ff"
				$logMsg = "Add Banner Start: "+$Time;
				[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
				Add-Content -Path $Global:logPath -Value $logMessage
                
                $js = "$"+"("+"document"+")"+".ready(function(){
				
				    var cdnJSFilePath = window.location.protocol + ""//"" + window.location.host + ""/"+$userCustomActionCDNPath+""";
			        var cdnCSSFilePath = window.location.protocol + ""//"" + window.location.host + ""/"+$userCustomActionCssCDNPath+""";
					
				    var head = document.getElementsByTagName('head')[0];
                    var script = document.createElement('script');
                    script.type = 'text/javascript';
                    script.src = cdnJSFilePath;
                    head.appendChild(script);
					
					var head  = document.getElementsByTagName('head')[0];
			        var link  = document.createElement('link');
			        link.id   = 'cssId';
			        link.rel  = 'stylesheet';
			        link.type = 'text/css';
			        link.href = cdnCSSFilePath;
			        link.media = 'all';
			        head.appendChild(link);
					
                });";
								
                #Check if the Custom Action Exists already
                $CustomAction = $UserCustomActions | Where { $_.Sequence -eq $customActionSequenceNo } | Select ID, Title
					
					# Delete Custom Action, If already exist for brand new site.
					try
					{
						If($_bannerType -eq "T-3"){
							#Remove the custom action
		                    $Ctx.Site.UserCustomActions.GetById($CustomAction.Id).DeleteObject()
		                    ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
		                    $UserCustomActions = $Ctx.Site.UserCustomActions;
				            $Ctx.Load($UserCustomActions);
							ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
							$CustomAction = $UserCustomActions | Where { $_.Sequence -eq $customActionSequenceNo } | Select ID, Title
						}
					}
					catch{
						#Write-Host $_.Exception.Message
					}
					    
                    If($CustomAction -eq $Null)
                    {
                        #Add new custom action
                        $UserCustomAction = $Ctx.Site.UserCustomActions.Add()
                         #Set the Properties of the custom action
                        $UserCustomAction.Name = $customActionTitle;
                        $UserCustomAction.Description = "Banner msg added to top";
                        $UserCustomAction.Location = "ScriptLink"
                        $UserCustomAction.ScriptBlock = $js;
                        $UserCustomAction.Sequence = $customActionSequenceNo;
                        $UserCustomAction.Update();;
                        ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
                        
                        $logMsg = "`t Custom Action Added Successfully!"
						[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
						Add-Content -Path $Global:logPath -Value $logMessage
                    }
                    Else
                    {
                        $logMsg = "`t Custom Action Already Exists!";
						[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
						Add-Content -Path $Global:logPath -Value $logMessage
                    }
        
                    # Add Properties
                    if(-not [string]::IsNullOrEmpty($targetUrl)){
                        $PropertyValues["DestinationUrl"] = $targetUrl;
                    }
                    else{
                        $PropertyValues["DestinationUrl"] = "Site provisioning not yet completed";
                    }

                    # Get Existing Banner Color
                    $Global:ExistingBannerColor = $PropertyValues["BannerColor"];

                    $PropertyValues["MigrationDate"] =[String]$migrationDate
                    $PropertyValues["BannerColor"] = $bannerColor
            
                    $Web.Update();
                    ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
                    
                    $logMsg = "`t Banner "+$BannerType+ "(" +$bannerColor+") added successfully!"
					[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
					Add-Content -Path $Global:logPath -Value $logMessage
					
					$Time = Get-Date #-format "yyyy-MM-dd-HH-mm-ss-ff"
			        $logMsg = "Add Banner End: "+$Time;
					[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
					Add-Content -Path $Global:logPath -Value $logMessage
					 
			        $logMsg = "Add Banner Duration -"+ $($elapsed.Elapsed.ToString());
					[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
					Add-Content -Path $Global:logPath -Value $logMessage
                } 
                Catch
                {
                    Set-IsPermissionSuccess
                    $logMsg = "Error on Add-Bannere!" +$_.Exception.Message
					[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
					Add-Content -Path $Global:logPath -Value $logMessage
                    Start-Sleep 5
                    Set-ChangeStatus $logMsg $($_.ScriptStackTrace);
                }
            }
            
            #endregion
            # Add-Banner Execution End---
                        						
            
			#Step5 Set Permission
            #region ---- SharePoint Set Site Permissions Start ---
            
            Function Init-SitePermissionsSetProcess()
            {
                Try
                    {
					
					$elapsed = [System.Diagnostics.Stopwatch]::StartNew()
	                $Time = Get-Date #-format "yyyy-MM-dd-HH-mm-ss-ff"
	                $logMsg = "Init-SitePermissionsSetProcess Start: "+$Time;
					[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
					Add-Content -Path $Global:logPath -Value $logMessage
				
                    # RootWeb to get site collection permissions
                    $logMsg = "Site Id "+$_siteId+" Set Permission started..."
					[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
					Add-Content -Path $Global:logPath -Value $logMessage

                    #Invoke-LoadMethod -Object $Web -PropertyName "HasUniqueRoleAssignments"
                    #ExecuteQueryWithIncrementalRetry $Ctx 3 5000;					
                    
                    If( $Web.HasUniqueRoleAssignments -eq $True)
                    {
                    # -------------------- Root Site[Web Level Permission] ------------------------- #
                           GetSet-Permissions -Object $Web
					# ------------------------------------------------------------------------------ #
                    }
                    else
                    {
                        $logMsg = "Site Id "+$_siteId+" has an inherit permission..."
					    [string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
					    Add-Content -Path $Global:logPath -Value $logMessage
                    }
                    $logMsg = "Site Id "+$_siteId+" Set Permission ended..."
					[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
					Add-Content -Path $Global:logPath -Value $logMessage

                    #Step7 Get Permissions of all lists from the web
                    #Get All Lists from the web
                    $Lists = $Web.Lists
                    $Ctx.Load($Lists)
                    ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
                    #Exclude System Lists
                    $listCollection = $Lists | Where-Object -FilterScript { $_.Hidden -eq $False } 
                    
                    $logMsg = "Lists Permission Role binding process started ............."
					[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
					Add-Content -Path $Global:logPath -Value $logMessage

                    #Get all lists from the web  
                    ForEach($List in $listCollection)
                    {
                        $Ctx.Load($List)
                        ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
                        #Get the Lists with Unique permission
                        Invoke-LoadMethod -Object $List -PropertyName "HasUniqueRoleAssignments"
                        ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
  
                        If( $List.HasUniqueRoleAssignments -eq $True)
                        {
                            #Call the function to check permissions
                            GetSet-Permissions -Object $List
                        }
						
                        # Else not required to set permission to the List and ListItems, which are inheritance the permissions from the Roost Site
                            
                    }
					
                    try { ExecuteQueryWithIncrementalRetry $Ctx 3 5000; } catch { }
					
                    $logMsg = "Lists Permission Role binding process ended ............."                             
					[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
					Add-Content -Path $Global:logPath -Value $logMessage

					$Time = Get-Date #-format "yyyy-MM-dd-HH-mm-ss-ff"
	                $logMsg = "Init-SitePermissionsSetProcess End: "+$Time;
					[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
					Add-Content -Path $Global:logPath -Value $logMessage

	                $logMsg = "Init-SitePermissionsSetProcess Duration:" +$($elapsed.Elapsed.ToString());
					[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
					Add-Content -Path $Global:logPath -Value $logMessage
	                
					$logMsg = "Set Permission Process Completed Successfully!";
					[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
					Add-Content -Path $Global:logPath -Value $logMessage
                }
    
                Catch {
                    Set-IsPermissionSuccess
                    $logMsg = "Init-SitePermissionsSetProcess!" +$_.Exception.Message
					[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
					Add-Content -Path $Global:logPath -Value $logMessage
                    Start-Sleep 5
                    Set-ChangeStatus $logMsg $($_.ScriptStackTrace);
                }
            }                     
            
            #endregion
            # SharePoint Set Site Permissions End -----

            #Step3 Extract Permission

            #region Extract Permission from Site

            $Global:isT3PermissionExist = $true

            if(($_bannerType -eq  "T-3") -or ($_bannerType -eq  "T-2")){

            #$sqlQry = "select COUNT([fk_site]) as ItemCount from [dbo].[Mig_Sites_Permissions] where fk_site = "+$_siteId;
            $sqlQry = "select COUNT([fk_site]) as ItemCount from [dbo].["+$migSitesPermissions+"] where fk_site = "+$_siteId;
            
            if($_bannerType -eq  "T-3"){
                $sqlQry = "select COUNT([fk_site]) as ItemCount from [dbo].["+$migSitesPermissionsT3+"] where fk_site = "+$_siteId;
            }
                        
            If($BannerType -eq "T-2"){
              # If permission not exist in Mig_Sites_Permission_T3
              Check-PreMigBannerPermissionValidation
            }
            
            If($isSetPermissionSuccess -eq $true){
            #Check-IsSiteExist
                $resultData = Get-ContentFromSqlQuery $sqlConnection $sqlQry

				if($resultData.ItemCount -eq 0){
	                try{
					
					   $logMsg = "Begin Extracting Permission for the Site:"+$_siteId;
					   [string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
						Add-Content -Path $Global:logPath -Value $logMessage
#Step3 Generate Permission
Init-SitePermissionsExtractProcess $Ctx $Web;
	                    
	                    $logMsg = "End Extracting Permission for the Site Id: "+$_siteId;
						[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
						Add-Content -Path $Global:logPath -Value $logMessage
						
	                }
	                catch{
	                    Set-IsPermissionSuccess
						$logMsg = $_.Exception.Message;
	                    Start-Sleep 5
	                    Set-ChangeStatus $logMsg $($_.ScriptStackTrace);
	                }
	                
	                #-------------------------------------------------------------------
	            
	                $isSiteExist = $False
	            }else{
	                $isSiteExist = $true
	            }
              }
            }
            #endregion

            If($isSetPermissionSuccess -eq $true){
				# -------------- Add-Banner Start ----------------------------
				#Step4 Add-Banner
				Add-Banner $_targetUrl $_migrationDate $_bannerColor
				#-------------- Add-Banner End ----------------------------
            }
            
            #region Init Site Permission Set Process   
                                    
            If((($_bannerType -eq  "T-2") -or ($_bannerType -eq  "T")) -and $isSetPermissionSuccess -eq $true){

                $logMsg = "Init-SitePermissionsSetProcess for the Site Id: "+$_siteId
				[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
				Add-Content -Path $Global:logPath -Value $logMessage
                #--------------------- Site Permissions Set Process Start ----------------------------------------------                                 
#Step5 Initiate Site Permissions Set Proces    
Init-SitePermissionsSetProcess
				#--------------------- Site Permissions Set Process Start ----------------------------------------------
            }
            
			#********************* Update the status to SP
            
            #endregion Init Site Permission Process

            #region Execute Failure Process
            if($isSetPermissionSuccess -eq $true) { $excutedValue = "Process executed successfully"; } else { $excutedValue = "Process executed failure"; }
            $logMsg = $excutedValue;
			[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
			Add-Content -Path $Global:logPath -Value $logMessage
            #endregion
            
			If($isSetPermissionSuccess -eq $true){
				#-----------------------------------  Set-PreMigUpdateBannerStatus Start Process -------------------------------- 
				#FinalStep on SQL Update
				Set-PreMigUpdateBannerStatus $_siteId $_bannerId $_presentJobStep $_nextJobStep
				#-----------------------------------  Set-PreMigUpdateBannerStatus End Process --------------------------------
			#if($_bannerType -eq  "T"){			
			#	#-----------------------------------  Set-PreMigToReady Start Process --------------------------------  
			#	$PreMigToReady = Set-PreMigToReady;
			#    if($PreMigToReady.ReturnCode -eq 1){
			#        Write-Host -f Yellow "ReturnCode" $PreMigToReady.ReturnCode " PreMigSetToReady process updated succefully";
			#    }
			#    else{
			#        Write-host -f Yellow "ReturnCode" $PreMigToReady.ReturnCode " PreMigSetToReady process executed succefully";
			#    }
			#	
			#}
				#-----------------------------------  SetPreMigToReady End Process --------------------------------
		            if($isSetPermissionSuccess -eq $false){
						Revoke-SPPermissions $Ctx $_siteId $_batchId $_originalurl $_targetUrl
		            }
            }
			else
			{
				# Rollback Permission
				#Revoke-SPPropertyBagValues	
                If($Global:isT3PermissionExist -eq $true){		
                    $logMsg = "Set Permission success process failure!";
				    $ErrorStack = "Set Permission process has been failed due to some interuption, Please refer the log files for further info.";
				    [string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
				    Add-Content -Path $Global:logPath -Value $logMessage
                    Revoke-SPPermissions $Ctx $_siteId $_batchId $_originalurl $_targetUrl
                }
                Else{
                    $logMsg = "Permission not exist at the Mig_Sites_Permission_T3 table";
				    $ErrorStack = "Set Permission process has been failed due to extract permission issue at Cream Banner.";
				    [string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
				    Add-Content -Path $Global:logPath -Value $logMessage
                }
                
				Start-Sleep 5
                Set-ChangeStatus $logMsg $ErrorStack;
                
            }

            $permissionLevel = $null;
            $Ctx.Dispose();
            $Global:isSetPermissionSuccess = $true;
            $isNextSiteExist = $true;

            $logMsg = "Banner Process Completed Successfully!";
			[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
			Add-Content -Path $Global:logPath -Value $logMessage
            
		    $EndTime = Get-Date #-format "yyyy-MM-dd-HH-mm-ss-ff"
		    $logMsg = "Banner Action End Time for the Site Id: "+$_siteId;
			[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
			Add-Content -Path $Global:logPath -Value $logMessage

	        $DiffTime = New-TimeSpan -Start $StartTime -End $EndTime
	        $logMsg = "`t `tSiteID: "+$_siteId+"-Banner Action Duration: "+$DiffTime;
			[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
			Add-Content -Path $Global:logPath -Value $logMessage
		    $logMsg = "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
			[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
			Add-Content -Path $Global:logPath -Value $logMessage
            
            Start-Sleep 5

            $logMsg = "Get Next Pre Migration Site";
			[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
			Add-Content -Path $Global:logPath -Value $logMessage

            #Iterate the Init-Pre-Migrate-Get-Banner Process
         }
            else
            {
                $logMsg = "The App-Web-"+$SiteURL+" job steps status has been cancelled" 

                Set-AppWebJobStepStatusCancelled $logMsg
                                        
			    [string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
			    Add-Content -Path $Global:logPath -Value $logMessage

                $permissionLevel = $null;
                $Ctx.Dispose();
                $Global:isSetPermissionSuccess = $true;
                $isNextSiteExist = $true;

                $logMsg = "Get Next Pre Migration Site";
			    [string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
			    Add-Content -Path $Global:logPath -Value $logMessage
            }
           

        
        }
        catch
        {
            $logMsg = "Init-PreMigBannerSite Line No 1201: " +$_.Exception.Message
			[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
			Add-Content -Path $Global:logPath -Value $logMessage
            
			$Global:isSetPermissionSuccess = $true;
			#Iterate the Init-Pre-Migrate-Get-Banner Process due to the Existing Site got error          
            Set-ChangeStatus $logMsg $($_.ScriptStackTrace);
            Start-Sleep 5	
			$isNextSiteExist = $true;
         }

        }
        else
        {
            $logMsg = "Next banner site not found for ready to proceed";
			[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
			Add-Content -Path $Global:logPath -Value $logMessage
            $isNextSiteExist = $False;
        }

        }
        else{
            $logMsg = "Banner process has been stopped";
			[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
			Add-Content -Path $Global:logPath -Value $logMessage
            $isNextSiteExist = $False;
        }
      }

    }
    catch
    {
        $logMsg = "Error on Init-PreMigBannerSite: " +$_.Exception.Message
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
    }
}

#Set Stored Procedure Dynamic Input parameter values for Exception logs
Function Set-ExceptionLogsParameters {
    Param(      
        [Parameter(Mandatory = $true)] $parameters,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $process,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $exceptionMessage,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $exceptionStackTrace
    )
    try {
        $ipAddress = (Get-NetIPAddress -AddressFamily IPv4)[0].IPAddress
        $parameters = foreach($item in $parameters.Item) {    
            Switch($item.Name) {
                "@fk_jobstep" { $item.Value = [String]$_presentJobStep ; break }
                "@operation" { $item.Value = [String]$process + $ipAddress ; break }
                "@SiteId" { $item.Value = [String]$_siteId; break }
                "@BatchId" { $item.Value = [String]$_batchId; break }                     
                "@source" { $item.Value = [String]$_originalurl; break }
                "@target" { $item.Value = [String]$_targetUrl; break }
                "@information" { $item.Value = [String]$exceptionMessage; break }
                "@details" { $item.Value = [String]$exceptionStackTrace; break }
            }
        }
    }
    catch {
    
    }
}

Function Set-ChangeStatus($exceptionMsg,$ScriptStackTrace=$null){
	try {
        
        $sqlQry = "select appCodeIndex as appCodeIndex from [dbo].[MigDef_JobSteps] where id = "+$_presentJobStep;
        $jobStepData = Get-ContentFromSqlQuery $sqlConnection $sqlQry
        $_appCodeIndex = [Int]$jobStepData.appCodeIndex;

        ChangeStatus-InputParameters $_siteId $_batchId $sprocStatusChangeDynamicParameters $_appCodeIndex "600" $ScriptStackTrace
        $changeStatusParameters = $sprocStatusChangeInputParameters,$sprocStatusChangeDynamicParameters
        Execute-StrdProcWithParameters $sqlConnection $sprocStatusChange $changeStatusParameters $null
        
		$exceptionMsg = $($exceptionMsg).Replace('"', '`"');
        #Exception logs
        Set-ExceptionLogsParameters $sprocExcepLogsDynamicParameters "Automated-Banner" $exceptionMsg $ScriptStackTrace            
        $inputParameters = $sprocExcepLogsInputParameters,$sprocExcepLogsDynamicParameters
        Execute-StrdProcWithParameters $sqlConnection $sprocExcepLogging $inputParameters $null
		
	    $logMsg = "Marking this site("+$_siteId+") job step status("+$_presentJobStep+") as Failure - Completed in SQL DB";
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
    }
    catch {
        return $_.Exception.Message
    }
}

Function Set-AppWebJobStepStatusCancelled($ScriptStackTrace){
    try{
        $sqlQry = "select appCodeIndex as appCodeIndex from [dbo].[MigDef_JobSteps] where id = "+$_presentJobStep;
        $jobStepData = Get-ContentFromSqlQuery $sqlConnection $sqlQry
        $_appCodeIndex = [Int]$jobStepData.appCodeIndex;
        $_appCodeIndexProvision = 300;

        ChangeStatus-InputParameters $_siteId $_batchId $sprocStatusChangeDynamicParameters $_appCodeIndex "800" $ScriptStackTrace
        $changeStatusParameters = $sprocStatusChangeInputParameters,$sprocStatusChangeDynamicParameters
        Execute-StrdProcWithParameters $sqlConnection $sprocStatusChange $changeStatusParameters $null

        ChangeStatus-InputParameters $_siteId $_batchId $sprocStatusChangeDynamicParameters $_appCodeIndexProvision "800" $ScriptStackTrace
        $changeStatusParameters = $sprocStatusChangeInputParameters,$sprocStatusChangeDynamicParameters
        Execute-StrdProcWithParameters $sqlConnection $sprocStatusChange $changeStatusParameters $null

    }
    catch{
        $logMsg = "Error on Set-AppWeb-Cancelled: " +$_.Exception.Message
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
    }
}
 
# Execute the Stored Procedure to set the PreMigToReady
Function Set-PreMigToReady() {
    try {

        $elapsed = [System.Diagnostics.Stopwatch]::StartNew()
		$StartTime = Get-Date
		
		$logMsg = "Set Pre Migration To Ready To Start Action Start Time: "+$StartTime;
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage

        $sqlCommand = New-Object System.Data.SqlClient.SqlCommand
        $sqlCommand.CommandText = $setPreMigToReady;
        $sqlCommand.Connection = $sqlConnection
        $sqlCommand.CommandType = [System.Data.CommandType]::StoredProcedure
        $AppInstance = New-Object System.Data.SqlClient.SqlParameter;
        $AppInstance.ParameterName = "@AppInstance";
        $AppInstance.Direction = [System.Data.ParameterDirection]::Input
        $AppInstance.Value = $appInstanceId;
        $Returncode = New-Object System.Data.SqlClient.SqlParameter
        $Returncode.ParameterName = "@Returncode";
        $Returncode.Direction = [System.Data.ParameterDirection]::Output
        $Returncode.DbType = [System.Data.DbType]::Int32          
        $sqlCommand.Parameters.Add($AppInstance) | Out-Null
        $sqlCommand.Parameters.Add($Returncode) | Out-Null
        $sqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter  
        $sqlAdapter.SelectCommand = $sqlCommand
        $sqlAdapter.SelectCommand.CommandTimeout=0   
        #Creating Dataset  
        $dataSet = New-Object System.Data.DataSet   
        $sqlAdapter.Fill($dataSet)
        $formatResponse = $null
        $sqlCommand.Parameters | ForEach-Object {            
            $formatResponse += "$($_.ParameterName.Split('@')[1]) = $($_.Value)" | ConvertFrom-StringData
        }
        
        $Time = Get-Date #-format "yyyy-MM-dd-HH-mm-ss-ff"
		$logMsg = "Set Pre Migration To Ready To End Action Start Time: "+$Time;
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
		
		$logMsg = "Set PreMig Update Banner Status Duration: "+$($elapsed.Elapsed.ToString());
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
		
        return $formatResponse  
    }
    catch {
        $logMsg = $_.Exception.Message
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
    }  
}

Function IsAuthorizedSite(){
	try{

        $SiteURL = "https://eyonespace.ey.com/Sites/f33c90653d7345359be362b86d58bf58/42ddf96c9164464f9e245dd5e13e8cd4"
		$LogMessage = "Get SPCredential for the Site: " + $SiteURL         
        #Write-Host -f Yellow $LogMessage
        $_sourceType = "extranet";

        #$srcUserName = "ey\P.AUOPRTMIGP.1"
        #$srcPassword = "kqlUQ7JA6T8YKm!";

        #Get-SPContext -source $SiteURL -userId $srcUserName -securePassword $srcPassword
        if($_sourceType.ToLower().Trim().IndexOf("intranet") -ne -1) {
        $Global:Ctx = Get-SPContext $SiteURL $sourceCredentials.LoginId $sourceSecurePassword
        }
        elseif($_sourceType.ToLower().Trim().IndexOf("extranet") -ne -1) {
            $Global:Ctx = Get-SPContext $SiteURL $sourceExtranetCredentials.LoginId $sourceExtranetSecurePassword
        }
        else {
            $Global:Ctx = Get-SPContext $SiteURL $sourceSpoCredentials.LoginId $sourceSpoSecurePassword
        }

        #Get the Web
        $Web = $Ctx.Web;
        $Ctx.Load($Web);
        #-----------------------------------  Execute Site Context -------------------------------------
        $LogMessage = "Execute Site Context";         
        #Write-Host -f Yellow $LogMessage
        Invoke-LoadMethod -Object $Web -PropertyName "HasUniqueRoleAssignments"
        ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
		$LogMessage = "Connection Established successfully for the Site Url: "+ $SiteURL; 
        #Write-Host -f Yellow $LogMessage; 
        #Write-Host -f Yellow 'LogMessage';     
        
	}
	catch{
		$logMsg = $_.Exception.Message
        $_sId = 4804;
        $_bId = 153;
        $_pJobStep = 31;
        Set-ChangeStatus $logMsg $($_.ScriptStackTrace);
	}
	finally{
		$Ctx.Dispose();
	}
}

#Fetching SQL Server Details
$sqlServerInstance = $configXmlfile.ConfigSettings.SqlSettings.SqlDbServer
$sqlDatabase = $configXmlfile.ConfigSettings.SqlSettings.SqlDatabase

#StoredProcedure - Change Status
$sprocStatusChange = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ChangeStatus.Name
$sprocStatusChangeInputParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ChangeStatus.InputParameters
$sprocStatusChangeDynamicParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ChangeStatus.DynamicInputParameters

#StoredProcedure - Exception logging
$sprocExcepLogging = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ExceptionLogging.Name
$sprocExcepLogsInputParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ExceptionLogging.InputParameters
$sprocExcepLogsDynamicParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ExceptionLogging.DynamicInputParameters

#Fetch SQL and SharePoint Credentials from Azure KeyVault
$azAppId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.ApplicationId
$azTenantId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.TenantId
$azCertificates = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.CertificateThumbprint
$azVault = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.VaultName
$azOrchDbUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.OrchestrationUserId
$azOrchDbPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.OrchestrationPassword

$azSourceIntranetUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceIntranetUserId
$azSourceIntranetPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceIntranetPassword
$azSourceExtranetUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceExtranetUserId
$azSourceExtranetPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceExtranetPassword
$azSourceSpoUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceSPOUserId
$azSourceSpoPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceSPOPassword

$azTargetUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.TargetUserId
$azTargetPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.TargetPassword

try{
	#Fetch SQL DB Credentials from Azure Keyvault
	$dbCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azOrchDbUserId $azOrchDbPassword -WarningAction SilentlyContinue -ErrorAction Stop
	$secureDbPassword = $dbCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force

	#Fetch Source Sites Credentials from Azure keyvault
	$sourceCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azSourceIntranetUserId $azSourceIntranetPassword -WarningAction SilentlyContinue
	$sourceSecurePassword = $sourceCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force

	#Fetch Source Extranet Sites Credentials from Azure keyvault
    if(-not [string]::IsNullOrEmpty($azSourceExtranetUserId)){
	    $sourceExtranetCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azSourceExtranetUserId $azSourceExtranetPassword -WarningAction SilentlyContinue    
	    $sourceExtranetSecurePassword = $sourceExtranetCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force
    }
    #Fetch Source SPO Sites Credentials from Azure keyvault
    if(!([String]::IsNullOrEmpty($azSourceSpoUserId)) -and !([String]::IsNullOrEmpty($azSourceSpoPassword))) {
        $sourceSpoCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azSourceSpoUserId $azSourceSpoPassword  -WarningAction SilentlyContinue       
        $sourceSpoSecurePassword = $sourceSpoCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force
    }

	#Fetch Target Sites Credentials from Azure keyvault
    if(-not [string]::IsNullOrEmpty($azTargetUserId)){
	    $targetCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azTargetUserId $azTargetPassword -WarningAction SilentlyContinue    
        $targetSecurePassword = $targetCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force
    } 
}
catch{
	$logMsg = "Exception in fetching Azure Keyvault details `n"+$_.Exception.Message
	[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
    Add-Content -Path $Global:logPath -Value $logMessage
}

#StoredProcedure - Fetch Banner sites
$preMigGetBanner = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.GetPreMigNextBannerSite.SPName
$appInstanceId = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.GetPreMigNextBannerSite.AppInstance
$updatePreMigBanner = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.UpdatePreMigNextBannerSite.SPName
$setPreMigToReady = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.SetPreMigToReady.SPName
$preMigStopBannerProcess = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.PreMigStopBannerProcess.SPName
# Tables
$migSitesPermissions = $configXmlfile.ConfigSettings.SqlSettings.Table.MigSitesPermissions;
$migSitesPermissionsT3 = $configXmlfile.ConfigSettings.SqlSettings.Table.MigSitesPermissionsT3;

#Banner Properties
$userCustomActionCDNPath = $configXmlfile.ConfigSettings.sp.banner.customactioncdnpath;
$userCustomActionCssCDNPath = $configXmlfile.ConfigSettings.sp.banner.customactioncsscdnpath;
$customActionTitle = $configXmlfile.ConfigSettings.sp.banner.customactiontitle;
$customActionSequenceNo = $configXmlfile.ConfigSettings.sp.banner.customactionsequenceno;

if($Ctx -ne $null){
  $Ctx.Dispose();
} 

$logMsg = "Init-PreMigCommunicationBanner method started!";
[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
Add-Content -Path $Global:logPath -Value $logMessage

#Build SQL Connection
$sqlConnection = New-Object System.Data.SqlClient.SqlConnection
$sqlConnection.ConnectionString = Get-SqlConnectionString $dbCredentials.LoginId $secureDbPassword $sqlServerInstance $sqlDatabase
$sqlConnection.Open();

#Check-PreMigBannerPermissionValidation

Init-PreMigBannerSite

$sqlConnection.Close();

$logMsg = "Init-PreMigCommunicationBanner method ended!";
[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
Add-Content -Path $Global:logPath -Value $logMessage

$logMsg = "----------Banner process ended.............";
[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
Add-Content -Path $Global:logPath -Value $logMessage

#To Check whether the source site has right CSOM acccess!!!
#IsAuthorizedSite