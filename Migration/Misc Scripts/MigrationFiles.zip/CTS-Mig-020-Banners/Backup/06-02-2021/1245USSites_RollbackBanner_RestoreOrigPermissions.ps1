﻿#region Variable Declaration
Get-Module | Remove-Module -Force
Clear-Host
#Load XML Config File
$scriptRoot = Split-Path $MyInvocation.MyCommand.Path -Parent
$parentRoot = (Get-Item $scriptRoot).Parent.FullName
$configfolder = Join-Path $parentRoot.ToLower().Replace('\cts\','\ey\') "CTS-Mig-0Settings"
$xmlConfigPath =  Join-Path $configfolder "ConfigurationSettings.xml"
$Global:configXmlfile = [xml]$(Get-Content $xmlConfigPath)

#Load Module files - Reusable methods, Apply Permissions
$modulesFolder = Join-Path $parentRoot $configXmlfile.ConfigSettings.CommonSettings.Modules.Name
$modulesPath = Join-Path $modulesFolder $configXmlfile.ConfigSettings.CommonSettings.Modules.Value
Import-Module -Name $modulesPath -WarningAction SilentlyContinue

$rolebackPermissionsModule = Join-Path $scriptRoot $configXmlfile.ConfigSettings.CommonSettings.RolebackPermissions.Value
Import-Module -Name $modulesPath -WarningAction SilentlyContinue
Import-Module -Name $rolebackPermissionsModule -WarningAction SilentlyContinue

#Load SharePoint CSOM Assemblies
$spoModulesRefPath = $configXmlfile.ConfigSettings.CommonSettings.SPOnlineReferencesPath.Value
Import-Module -Name $spoModulesRefPath -DisableNameChecking
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client")
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client.Runtime")

#Load SharePoint PnP PowerShell Online Assemblies
$spPnPPSModulesRefPath = $configXmlfile.ConfigSettings.CommonSettings.SharePointPnPPowerShellOnline.Value
Import-Module -Name $spPnPPSModulesRefPath -DisableNameChecking

#Load Azure Moodules
$azureAccountsPsd = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.AzureAccountsPsd
$azureKeyvaultsPsd = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.AzureKeyvaultsPsd
Import-Module -Name $azureAccountsPsd
Import-Module -Name $azureKeyvaultsPsd
[int]$Global:fk_Site = 0;
[int]$Global:fk_Batch = 0;
$Global:batchNo = 0;

#endregion

Function Create-LogFile($fileName){
    $date= Get-Date -format MMddyyyyHHmmss  
    $enddate = (Get-Date).tostring("yyyyMMddhhmmss")
    $logFileName = $fileName +"_"+ $enddate+"_Log.txt"   
    $Global:directoryPathForLog = $scriptRoot+"\"+"LogFiles"
    if(!(Test-Path -path $directoryPathForLog))  
    {  
        New-Item -ItemType directory -Path $directoryPathForLog          
    }
    $Global:logPath = $directoryPathForLog + "\" + $logFileName
    $Global:isLogFileCreated = $true
}

Function Write-Log([string]$logMsg)  
{   
    if(!$isLogFileCreated){   
        #Write-Host "Creating Log File..."   
        if(!(Test-Path -path $directoryPathForLog))  
        {  
            #Write-Host "Please Provide Proper Log Path" -ForegroundColor Red   
        }   
        else   
        {   
            $Global:isLogFileCreated = $true   
            [string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
            Add-Content -Path $Global:logPath -Value $logMessage   
        }   
    }   
    else   
    {   
        [string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage   
    }   
}

Create-LogFile "1245USSites_RollbackBanner_RestoreOrigPermissions"
Write-Log "----------Banner process started.............";

Function Invoke-LoadMethod() {
    param(
            [Microsoft.SharePoint.Client.ClientObject]$Object = $(throw "Please provide a Client Object"),
            [string]$PropertyName
        )
   $ctx = $Object.Context
   $load = [Microsoft.SharePoint.Client.ClientContext].GetMethod("Load")
   $type = $Object.GetType()
   $clientLoad = $load.MakeGenericMethod($type)
   
   $Parameter = [System.Linq.Expressions.Expression]::Parameter(($type), $type.Name)
   $Expression = [System.Linq.Expressions.Expression]::Lambda([System.Linq.Expressions.Expression]::Convert([System.Linq.Expressions.Expression]::PropertyOrField($Parameter,$PropertyName),[System.Object] ), $($Parameter))
   $ExpressionArray = [System.Array]::CreateInstance($Expression.GetType(), 1)
   $ExpressionArray.SetValue($Expression, 0)
   $clientLoad.Invoke($ctx,@($Object,$ExpressionArray))
}

#Step1 Initiate Permission Process, once successful completion of the CustomListActions and AdderPropertyBags values
Function Init-Revert-Process(){

    try{

        $StartTime = Get-Date
        $logMsg = "Banner Action Start Time: "+$StartTime;
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
		
        $Global:isIssueNotExist = $true;
	  	$isNextSiteExist = $true;
        
        $filepath = $scriptRoot + "\1245USSites.csv"
		$Global:bannerReadySites = Import-csv $filepath;
         
        foreach($Global:bannerReadySite in $Global:bannerReadySites){
        

        if(-not [string]::IsNullOrEmpty($bannerReadySite.OriginalUrl)){
            #region "Read Site Detail"
            $Global:_siteId = $bannerReadySite.SiteId;
            $Global:_batchId = $bannerReadySite.BatchId;
            $Global:_originalurl = $bannerReadySite.OriginalUrl;
            $Global:_sourceType = $bannerReadySite.SourceType;               						  
			$SiteURL = $_originalurl;

            $Global:fk_Site = $_siteId;
            
            $chkRollbackStatus = "select fkRollBackStatus from MIG_SITES_REMOVE_BANNERS where ID = '$($bannerReadySite.SiteId)'"
            $RollbackStatus = Get-ContentFromSqlQuery $sqlConnection $chkRollbackStatus

        
        if(($RollbackStatus.fkRollBackStatus -eq "6") -or ($RollbackStatus.fkRollBackStatus -eq "10")) {
                if(-not [string]::IsNullOrEmpty($_batchId)){
                    $Global:fk_Batch = $_batchId;
                }
                else{
                    $Global:fk_Batch = 0;
                }
                #endregion "Read Site Detail"
            
              Try
              {
                $jobFailuresTable = "Mig_Sites_MigrationJobFailures"
                $query_UpdateJobFailuresTable = "update [$jobFailuresTable] set DefectStatus='Closed' where fk_jobStep=1000 and fk_Batch=" + $([int]$bannerReadySite.BatchId) + " and fk_Site=" + $([int]$bannerReadySite.SiteId)
                Execute-SqlQuery $sqlConnection $query_UpdateJobFailuresTable

			    #Step2 Get Context for Source and Target sites
                if($_sourceType.ToLower().Trim().IndexOf("intranet") -ne -1) {
                $Global:Ctx = Get-SPContext $SiteURL $sourceCredentials.LoginId $sourceSecurePassword
                }
                elseif($_sourceType.ToLower().Trim().IndexOf("extranet") -ne -1) {
                    $Global:Ctx = Get-SPContext $SiteURL $sourceExtranetCredentials.LoginId $sourceExtranetSecurePassword
                }
                else {
                    $Global:Ctx = Get-SPContext $SiteURL $sourceSpoCredentials.LoginId $sourceSpoSecurePassword
                }

                #Get the Web
                $Web = $Ctx.Web;
                $Ctx.Load($Web);
                $Site = $Ctx.Site;
                $Ctx.Load($Site);
                $UserCustomActions = $Ctx.Site.UserCustomActions;
                $UserWebCustomActions = $Ctx.Web.UserCustomActions;
                $PropertyValues = $Ctx.Web.AllProperties;
                $Ctx.Load($UserCustomActions);
                $Ctx.Load($UserWebCustomActions);
                $Ctx.Load($PropertyValues);
                #-----------------------------------  Execute Site Context -------------------------------------
                $LogMessage = "Execute Site Context";         
                ExecuteQueryWithIncrementalRetry $Ctx 3 5000;

            
                if($($Web.Url.ToLower() -ne $($_originalurl.ToLower()))) {

                    $exception = "This site is not a valid site. Original URL:$($_originalurl). CSOM URL:$($Web.Url)"
                    $spProcResetArchiveAfterRollback = "sp_reset_archive_after_rollback_1245"
                    $qryResetArchiveAfterRollback = "DECLARE @return_value int, @Returncode int  EXEC @return_value = $($spProcResetArchiveAfterRollback) @SiteID = $($fk_Site), @RollBackStatus = 0, @Returncode = @Returncode OUTPUT"
                    $updateResetArchiveAfterRollback = Get-ContentFromSqlQuery $sqlConnection $qryResetArchiveAfterRollback

                    ExceptionLogs-InputParameters $bannerReadySite $sprocExcepLogsDynamicParameters "1000" "Rollback Banner: " $exception $exception            
                    $inputParameters = $sprocExcepLogsInputParameters,$sprocExcepLogsDynamicParameters
                    Execute-StrdProcWithParameters $sqlConnection $sprocExcepLogging $inputParameters $null
                    continue
                }
                
                
                $elapsed = [System.Diagnostics.Stopwatch]::StartNew()
                $Time = Get-Date
                $logMsg = "----------Revoke Permissions Start for the Site ID: $($bannerReadySite.SiteId) , OriginalURL: $($_originalurl), Start Time: $($Time)";
		        [string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
                Add-Content -Path $Global:logPath -Value $logMessage
                Write-Host $logMessage;
               
                if($($bannerReadySite.YellowBannerStatus).ToLower() -eq "completed")
                {
                    $chkPermissionsQuery = "SELECT COUNT(*) as ItemsCount FROM Mig_Sites_Permissions WHERE fk_site = $($bannerReadySite.SiteId)"
                    $permsCount = Get-ContentFromSqlQuery $sqlConnection $chkPermissionsQuery
                    
                    if($permsCount.ItemsCount -gt 0) {

                        Revoke-SPPermissions $Ctx $_siteId $_batchId $_originalurl $_targetUrl $sqlConnection
                    }
                    else {
                        $exception = "No Permissions available in DB"
                        $spProcResetArchiveAfterRollback = "sp_reset_archive_after_rollback_1245"
                        $qryResetArchiveAfterRollback = "DECLARE @return_value int, @Returncode int  EXEC @return_value = $($spProcResetArchiveAfterRollback) @SiteID = $($fk_Site), @RollBackStatus = 0, @Returncode = @Returncode OUTPUT"
                        $updateResetArchiveAfterRollback = Get-ContentFromSqlQuery $sqlConnection $qryResetArchiveAfterRollback

                        ExceptionLogs-InputParameters $bannerReadySite $sprocExcepLogsDynamicParameters "1000" "Rollback Banner: " $exception $exception            
                        $inputParameters = $sprocExcepLogsInputParameters,$sprocExcepLogsDynamicParameters
                        Execute-StrdProcWithParameters $sqlConnection $sprocExcepLogging $inputParameters $null
                        continue
                    }
                }

                $Time = Get-Date #-format "yyyy-MM-dd-HH-mm-ss-ff"
                $logMsg = "Revoke Permissions End: "+$Time;
		        [string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
                Add-Content -Path $Global:logPath -Value $logMessage
                Write-Host $logMessage;

                $logMsg = "Revoke Permissions Duration: "+$($elapsed.Elapsed.ToString());
		        [string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
                Add-Content -Path $Global:logPath -Value $logMessage
                Write-Host $logMessage;

                $logMessage = "Permission has been rolled back to the original permission for the SiteID: "+$fk_Site;
                Write-Host $logMessage;
                Add-Content -Path $Global:logPath -Value $logMessage

                $PropertyValues["BannerColor"] = ""
                $PropertyValues["DestinationUrl"] = ""
                $PropertyValues["MigrationDate"] = ""
                $Web.Update();
                ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
                $logMessage = "Property Bag values have been removed"
                Write-Host $logMessage;
                Add-Content -Path $Global:logPath -Value $logMessage

                if ($($Web.Url.ToLower()) -eq $($Site.Url.ToLower())  ) {
                    $CustomAction = $UserCustomActions | Where { $_.Name -eq "BannerJS" } | Select ID, Name
                    If($CustomAction -ne $Null)
                    {
                        if ($CustomAction.count -gt 1) {
                            foreach($iCustomAction in $CustomAction){ 
                                $Ctx.Site.UserCustomActions.GetById($iCustomAction.Id).DeleteObject()                    
                                ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
                            }
                        }
                        else {
                            $Ctx.Site.UserCustomActions.GetById($CustomAction.Id).DeleteObject()
                            ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
                    
                        }

                        $logMessage = "Site user Custom Action has been removed from SiteID: " +$fk_Site + ", OriginalURL: $($_originalurl)";
                        Write-Host $logMessage;
                        Add-Content -Path $Global:logPath -Value $logMessage
                    }
                }

                $CustomWebAction = $UserWebCustomActions | Where { $_.Name -eq "BannerJS" } | Select ID, Name
                If($CustomWebAction -ne $Null)
                {

                    if ($CustomWebAction.count -gt 1) {
                        foreach($iCustomWebAction in $CustomWebAction){ 
                            $Ctx.Web.UserCustomActions.GetById($iCustomWebAction.Id).DeleteObject()                    
                            ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
                        }
                    }
                    else {
                        $Ctx.Web.UserCustomActions.GetById($CustomWebAction.Id).DeleteObject()
                        ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
                    
                    }

                    $logMessage = "Web user Custom Action has been removed from SiteID: " +$fk_Site + ", OriginalURL: $($_originalurl)";
                    Write-Host $logMessage;
                    Add-Content -Path $Global:logPath -Value $logMessage
                }


                $spProcResetArchiveAfterRollback = "sp_reset_archive_after_rollback_1245"
                $qryResetArchiveAfterRollback = "DECLARE @return_value int, @Returncode int  EXEC @return_value = $($spProcResetArchiveAfterRollback) @SiteID = $($fk_Site), @RollBackStatus = 1, @Returncode = @Returncode OUTPUT"
                $updateResetArchiveAfterRollback = Get-ContentFromSqlQuery $sqlConnection $qryResetArchiveAfterRollback
        
                #endregion ---- Get SPCredential -----
                $Ctx.Dispose();
			
            }
              catch{
                $logMsg = "Init-PreMigBannerSite : " +$_.Exception.Message
			    [string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)
                Write-Host $logMessage;   
			    Add-Content -Path $Global:logPath -Value $logMessage	
			    $isNextSiteExist = $true;
                $spProcResetArchiveAfterRollback = "sp_reset_archive_after_rollback_1245"
                $qryResetArchiveAfterRollback = "DECLARE @return_value int, @Returncode int  EXEC @return_value = $($spProcResetArchiveAfterRollback) @SiteID = $($fk_Site), @RollBackStatus = 0, @Returncode = @Returncode OUTPUT"
                $updateResetArchiveAfterRollback = Get-ContentFromSqlQuery $sqlConnection $qryResetArchiveAfterRollback

                #Exception logs
                Write-Host $_.Exception.Message -ForegroundColor Red
                $exception = $($_.Exception.Message).Replace('"', '`"')
                ExceptionLogs-InputParameters $bannerReadySite $sprocExcepLogsDynamicParameters "1000" "Rollback Banner: " $exception $($_.ScriptStackTrace)            
                $inputParameters = $sprocExcepLogsInputParameters,$sprocExcepLogsDynamicParameters
                Execute-StrdProcWithParameters $sqlConnection $sprocExcepLogging $inputParameters $null
              }
            }
        else {
            $logMsg = "This site is already rollbacked. SiteID: $($bannerReadySite.SiteId) and Original URL: $($bannerReadySite.OriginalUrl)";
			[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
			Add-Content -Path $Global:logPath -Value $logMessage
            Write-Host $logMsg

          }
        }
		else {
			$logMsg = "Next banner site not found for ready to proceed";
			[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
			Add-Content -Path $Global:logPath -Value $logMessage
			$isNextSiteExist = $False;
		}
        }
    }
    catch
    {
        $logMsg = "Error on Init-PreMigBannerSite: " +$_.Exception.Message
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
    }
}


#Fetching SQL Server Details
$sqlServerInstance = $configXmlfile.ConfigSettings.SqlSettings.SqlDbServer
$sqlDatabase = $configXmlfile.ConfigSettings.SqlSettings.SqlDatabase

#StoredProcedure - Change Status
$sprocStatusChange = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ChangeStatus.Name
$sprocStatusChangeInputParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ChangeStatus.InputParameters
$sprocStatusChangeDynamicParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ChangeStatus.DynamicInputParameters

#StoredProcedure - Exception logging
$sprocExcepLogging = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ExceptionLogging.Name
$sprocExcepLogsInputParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ExceptionLogging.InputParameters
$sprocExcepLogsDynamicParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ExceptionLogging.DynamicInputParameters

#Fetch SQL and SharePoint Credentials from Azure KeyVault
$azAppId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.ApplicationId
$azTenantId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.TenantId
$azCertificates = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.CertificateThumbprint
$azVault = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.VaultName
$azOrchDbUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.OrchestrationUserId
$azOrchDbPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.OrchestrationPassword

$azSourceIntranetUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceIntranetUserId
$azSourceIntranetPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceIntranetPassword
$azSourceExtranetUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceExtranetUserId
$azSourceExtranetPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceExtranetPassword
$azSourceSpoUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceSPOUserId
$azSourceSpoPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceSPOPassword

$azTargetUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.TargetUserId
$azTargetPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.TargetPassword

try{
	#Fetch SQL DB Credentials from Azure Keyvault
	$dbCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azOrchDbUserId $azOrchDbPassword -WarningAction SilentlyContinue -ErrorAction Stop
	$secureDbPassword = $dbCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force

	#Fetch Source Sites Credentials from Azure keyvault
	$sourceCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azSourceIntranetUserId $azSourceIntranetPassword -WarningAction SilentlyContinue
	$sourceSecurePassword = $sourceCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force

	#Fetch Source Extranet Sites Credentials from Azure keyvault
    if(-not [string]::IsNullOrEmpty($azSourceExtranetUserId)){
	    $sourceExtranetCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azSourceExtranetUserId $azSourceExtranetPassword -WarningAction SilentlyContinue    
	    $sourceExtranetSecurePassword = $sourceExtranetCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force
    }
    #Fetch Source SPO Sites Credentials from Azure keyvault
    if(!([String]::IsNullOrEmpty($azSourceSpoUserId)) -and !([String]::IsNullOrEmpty($azSourceSpoPassword))) {
        $sourceSpoCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azSourceSpoUserId $azSourceSpoPassword  -WarningAction SilentlyContinue       
        $sourceSpoSecurePassword = $sourceSpoCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force
    }

	#Fetch Target Sites Credentials from Azure keyvault
    if(-not [string]::IsNullOrEmpty($azTargetUserId)){
	    $targetCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azTargetUserId $azTargetPassword -WarningAction SilentlyContinue    
        $targetSecurePassword = $targetCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force
    } 
}
catch{
	$logMsg = "Exception in fetching Azure Keyvault details `n"+$_.Exception.Message
	[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
    Add-Content -Path $Global:logPath -Value $logMessage
}

#StoredProcedure - Fetch Banner sites
$preMigGetBanner = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.GetPreMigNextBannerSite.SPName
$appInstanceId = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.GetPreMigNextBannerSite.AppInstance
$updatePreMigBanner = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.UpdatePreMigNextBannerSite.SPName
$setPreMigToReady = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.SetPreMigToReady.SPName
$preMigStopBannerProcess = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.PreMigStopBannerProcess.SPName
# Tables
$migSitesPermissions = $configXmlfile.ConfigSettings.SqlSettings.Table.MigSitesPermissions;
$migSitesPermissionsT3 = $configXmlfile.ConfigSettings.SqlSettings.Table.MigSitesPermissionsT3;

#Banner Properties
$userCustomActionCDNPath = $configXmlfile.ConfigSettings.sp.banner.customactioncdnpath;
$userCustomActionCssCDNPath = $configXmlfile.ConfigSettings.sp.banner.customactioncsscdnpath;
$customActionTitle = $configXmlfile.ConfigSettings.sp.banner.customactiontitle;
$customActionSequenceNo = $configXmlfile.ConfigSettings.sp.banner.customactionsequenceno;

if($Ctx -ne $null){
  $Ctx.Dispose();
} 

$logMsg = "Init-PreMigCommunicationBanner method started!";
[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
Add-Content -Path $Global:logPath -Value $logMessage

#Build SQL Connection
$sqlConnection = New-Object System.Data.SqlClient.SqlConnection
$sqlConnection.ConnectionString = Get-SqlConnectionString $dbCredentials.LoginId $secureDbPassword $sqlServerInstance $sqlDatabase
$sqlConnection.Open();

Init-Revert-Process

$sqlConnection.Close();

$logMsg = "Init-PreMigCommunicationBanner method ended!";
[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
Add-Content -Path $Global:logPath -Value $logMessage

$logMsg = "----------Banner process ended.............";
[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
Add-Content -Path $Global:logPath -Value $logMessage

