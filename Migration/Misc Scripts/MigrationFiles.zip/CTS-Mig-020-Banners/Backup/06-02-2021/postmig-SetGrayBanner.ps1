﻿#region Banner Process Desceription
    #Steps
    #
    #1. Get all the configuration values from Configuration.XML file
    #2. Import xml and .psm1 files
    #3. Get Migration Orchestration UserId and Password from Azure Keyvalut using Azure ApplicationId,TenantId and CertificateThumbprint
    #4. Connect Migration Orchestration DB - Open Sql Connection
    #5. Init-PostMigBannerSite - Main Function
    #6. Get the Next Banner Site from SP - sp_postmig_next_banner_site
    #7. Connect SP Context
    #8. Validate the Banner Type( T-4 ) 
	
    #	case T-4 Gray Banner - Post Migration
    #		- Set Banner Color to Gray
    #		- Change the current jop step to completed and set the next job step to "Ready to Start"
    #		
    #	Methods
    #		   -Get-SPSourceType
    #          -Init-PostMigBannerSite
    #		   -Add-Banner Method
    #				- Inject BannerCustomUserAction.js and BannerStyleSheet.css
    #				- Add Custom Action
    #				- Add Properties
    #		   -Set-PostMigUpdateBannerStatus
    #		   -Exception
    #				Set-IsPermissionSuccess
    #		
    #	Dispose current SP Context
    #	Iterate Next Site
    #	
    #End Close the Sql Connection

#endregion

#region Variable Declaration
Get-Module | Remove-Module -Force
$Host.UI.RawUI.BackgroundColor = ($bckgrnd = 'DarkBlue')
$Host.UI.RawUI.ForegroundColor = 'White'
$Host.PrivateData.ErrorForegroundColor = 'Red'
$Host.PrivateData.ErrorBackgroundColor = $bckgrnd
$Host.PrivateData.WarningForegroundColor = 'Magenta'
$Host.PrivateData.WarningBackgroundColor = $bckgrnd
$Host.PrivateData.DebugForegroundColor = 'Yellow'
$Host.PrivateData.DebugBackgroundColor = $bckgrnd

Clear-Host
#Load XML Config File
$scriptRoot = Split-Path $MyInvocation.MyCommand.Path -Parent
$parentRoot = (Get-Item $scriptRoot).Parent.FullName
$configfolder = Join-Path $parentRoot.ToLower().Replace('\cts\','\ey\') "CTS-Mig-0Settings"
$xmlConfigPath =  Join-Path $configfolder "ConfigurationSettings.xml"
$configXmlfile = [xml]$(Get-Content $xmlConfigPath)

#Load Module files - Reusable methods, Apply Permissions
$modulesFolder = Join-Path $parentRoot $configXmlfile.ConfigSettings.CommonSettings.Modules.Name
$modulesPath = Join-Path $modulesFolder $configXmlfile.ConfigSettings.CommonSettings.Modules.Value
Import-Module -Name $modulesPath

#Load SharePoint CSOM Assemblies
$spoModulesRefPath = $configXmlfile.ConfigSettings.CommonSettings.SPOnlineReferencesPath.Value
Import-Module -Name $spoModulesRefPath -DisableNameChecking
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client")
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client.Runtime")

#Load SharePoint PnP PowerShell Online Assemblies
$spPnPPSModulesRefPath = $configXmlfile.ConfigSettings.CommonSettings.SharePointPnPPowerShellOnline.Value
Import-Module -Name $spPnPPSModulesRefPath -DisableNameChecking

#Load Azure Moodules
$azureAccountsPsd = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.AzureAccountsPsd
$azureKeyvaultsPsd = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.AzureKeyvaultsPsd
Import-Module -Name $azureAccountsPsd
Import-Module -Name $azureKeyvaultsPsd
		
[int]$Global:fk_Site = 0;
[int]$Global:fk_Batch = 0;

$Global:ExistingBannerColor = "";
$Global:BannerType = "";
$Global:isSetPermissionSuccess = $true;
$Global:batchNo = 0;

#endregion

Function Create-LogFile($fileName){
    $date= Get-Date -format MMddyyyyHHmmss  
    $enddate = (Get-Date).tostring("yyyyMMddhhmmss")
    $logFileName = $fileName +"_"+ $enddate+"_Log.txt"   
    $Global:directoryPathForLog = $scriptRoot+"\"+"LogFiles"
    if(!(Test-Path -path $directoryPathForLog))  
    {  
        New-Item -ItemType directory -Path $directoryPathForLog          
    }
    $Global:logPath = $directoryPathForLog + "\" + $logFileName
    $Global:isLogFileCreated = $true
}

Function Write-Log([string]$logMsg)  
{   
    if(!$isLogFileCreated){   
        Write-Host "Creating Log File..."   
        if(!(Test-Path -path $directoryPathForLog))  
        {  
            Write-Host "Please Provide Proper Log Path" -ForegroundColor Red   
        }   
        else   
        {   
            $Global:isLogFileCreated = $true   
            Write-Host "Log File ($logFileName) Created..."   
            [string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
            Add-Content -Path $Global:logPath -Value $logMessage   
        }   
    }   
    else   
    {   
        [string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage   
    }   
}

Create-LogFile "grayBanner"
Write-Log "----------Banner process started.............";

# Execute the Stored Procedure to get the PostMigBanner next site
#Step0
Function Get-PostMigBannerSite() {
    $results;
    try {
        $sqlCommand = New-Object System.Data.SqlClient.SqlCommand
        $sqlCommand.CommandText = $postMigGetBanner;
        $sqlCommand.Connection = $sqlConnection
        $sqlCommand.CommandType = [System.Data.CommandType]::StoredProcedure

        $AppInstance = New-Object System.Data.SqlClient.SqlParameter;
        $AppInstance.ParameterName = "@AppInstance";
        $AppInstance.Direction = [System.Data.ParameterDirection]::Input
        $AppInstance.Value = $appInstanceId;

        $Returncode = New-Object System.Data.SqlClient.SqlParameter
        $Returncode.ParameterName = "@Returncode";
        $Returncode.Direction = [System.Data.ParameterDirection]::Output
        $Returncode.DbType = [System.Data.DbType]::Int32

        $ReloadCode = New-Object System.Data.SqlClient.SqlParameter
        $ReloadCode.ParameterName = "@ReloadCode";
        $ReloadCode.Direction = [System.Data.ParameterDirection]::Output
        $ReloadCode.DbType = [System.Data.DbType]::Int32
                        
        $sqlCommand.Parameters.Add($AppInstance) | Out-Null
        $sqlCommand.Parameters.Add($Returncode) | Out-Null
        $sqlCommand.Parameters.Add($ReloadCode) | Out-Null

        $sqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter  
        $sqlAdapter.SelectCommand = $sqlCommand  
        $sqlAdapter.SelectCommand.CommandTimeout=30 
        #Creating Dataset  
        $dataSet = New-Object System.Data.DataSet   
        $sqlAdapter.Fill($dataSet)
        $_returnCode = $Returncode.Value
		
		if($_returnCode -eq 1){
		   #$results = (0, $dataSet.Tables[0].Rows)[$dataSet.Tables[0].Rows.Count -gt 0]
		   #Get single table from dataset
		   $data = $dataSet.Tables[0]
		   return $data;
		}
       
    }
    catch {
        $ErrorMessage = $_.Exception.Message
        Write-Log $ErrorMessage;
        #Add-Exception $_.Exception.Message
    }  
}


#FinalStep Execute Stored Procedure to update the status of the successful completion of the Banner and Set Permision process
Function Set-PostMigUpdateBannerStatus($siteId,$bannerId,$currentJobStep,$nextJobStep) {
    try {
        
        $sqlCommand = New-Object System.Data.SqlClient.SqlCommand
        $sqlCommand.CommandText = $updatePostMigBanner;
        $sqlCommand.Connection = $sqlConnection
        $sqlCommand.CommandType = [System.Data.CommandType]::StoredProcedure

        $_siteId = [Int]$siteId
        $_bannerId = [Int]$bannerId
        $_currentJobStep = try { [Int]$currentJobStep } catch { 0 }
		$_nextJobStep = try { [Int]$nextJobStep } catch { 0 }

        $SiteID = New-Object System.Data.SqlClient.SqlParameter
        $SiteID.ParameterName = "@SiteID";
        $SiteID.Direction = [System.Data.ParameterDirection]::Input
        $SiteID.Value = $_siteId

        $BannerID = New-Object System.Data.SqlClient.SqlParameter
        $BannerID.ParameterName = "@BannerID";
        $BannerID.Direction = [System.Data.ParameterDirection]::Input
        $BannerID.Value = $_bannerId

        $CurrentJobStep = New-Object System.Data.SqlClient.SqlParameter
     	$CurrentJobStep.ParameterName = "@currentJobStep";
     	$CurrentJobStep.Direction = [System.Data.ParameterDirection]::Input
     	$CurrentJobStep.Value = $_currentJobStep
		
		$NextJobStep = New-Object System.Data.SqlClient.SqlParameter
     	$NextJobStep.ParameterName = "@NextJobStep";
     	$NextJobStep.Direction = [System.Data.ParameterDirection]::Input
     	$NextJobStep.Value = $_nextJobStep
        
        $Returncode = New-Object System.Data.SqlClient.SqlParameter
        $Returncode.ParameterName = "@Returncode";
        $Returncode.Direction = [System.Data.ParameterDirection]::Output
        $Returncode.DbType = [System.Data.DbType]::Int32
        
        $sqlCommand.Parameters.Add($SiteID) | Out-Null
        $sqlCommand.Parameters.Add($BannerID) | Out-Null
        $sqlCommand.Parameters.Add($CurrentJobStep) | Out-Null
		$sqlCommand.Parameters.Add($NextJobStep) | Out-Null
        $sqlCommand.Parameters.Add($Returncode) | Out-Null
		
        $sqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter  
        $sqlAdapter.SelectCommand = $sqlCommand   
        $sqlAdapter.SelectCommand.CommandTimeout=30
        #Creating Dataset  
        $dataSet = New-Object System.Data.DataSet   
        $sqlAdapter.Fill($dataSet)
        $_returnCode = $Returncode.Value

        # Remove or rollback the permission, If issue ecist in the SQP Banner Update procedure
        if($_returnCode -eq 0){
            #Revoke-SPPropertyBagValues
        }
        if($_returnCode -eq 1){
            
            #*************************************************************************
                $LogMessage = "`t Banner and Set Permission have been completed successfully!"
            #*************************************************************************
            Write-Log $LogMessage;
        }
     

    }
    catch {
        $ErrorMessage = $_.Exception.Message
        Write-Log $ErrorMessage       
    }    
}

#Set value as False to the isSetPermissionSuccess variable
Function Set-IsPermissionSuccess(){
   $Global:isSetPermissionSuccess = $False;
}

Function Check-PostMigStopBannerProcess() {

    try {
        $sqlCommand = New-Object System.Data.SqlClient.SqlCommand
        $sqlCommand.CommandText = $postMigStopBannerProcess;
        $sqlCommand.Connection = $sqlConnection
        $sqlCommand.CommandType = [System.Data.CommandType]::StoredProcedure
        $sqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter  
        $sqlAdapter.SelectCommand = $sqlCommand
        $sqlAdapter.SelectCommand.CommandTimeout=30  
        #Creating Dataset  
        $dataSet = New-Object System.Data.DataSet   
        $sqlAdapter.Fill($dataSet)
		$data = $dataSet.Tables[0];
        
        $Global:isStopBannerProcess = $false;

        # 1 => Stop
        # 0 => Start

        if($appInstanceId -eq "7-2"){
            if($data.AUS_StartBannerProcess -eq 1){
                $Global:isStopBannerProcess = $true;
            }
        }
        if($appInstanceId -eq "47-2"){
            if($data.Canada_StartBannerProcess -eq 1){
                $Global:isStopBannerProcess = $true;
            }
        }
        if($appInstanceId -eq "23-2"){
            if($data.Ecuador_StartBannerProcess -eq 1){
                $Global:isStopBannerProcess = $true;
            }
        }
        if($appInstanceId -eq "59-2"){
            if($data.US_StartBannerProcess -eq 1){
                $Global:isStopBannerProcess = $true;
            }
        }
 
    }
    catch {
        $logMsg = $_.Exception.Message
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
        Add-Content -Path $Global:logPath -Value $logMessage
    }  
}


#Step1 Initiate Permission Process, once successful completion of the CustomListActions and AdderPropertyBags values
Function Init-PostMigBannerSite(){

    try{

        # Get the next Banner Site
        # Dafault value - "isManual" is True
        # And the system loop again the function, If manula not exist and set the value as false to the variable "isManual"

        #-----------------------------------  Get PostMigration Process --------------------------------
        
        $StartTime = Get-Date
        $LogMeggage = "Banner Action Start Time: "+$StartTime;
        Write-Log $LogMeggage
        $Global:isIssueNotExist = $true;
	  	$isNextSiteExist = $true;

      	while($isNextSiteExist){
		
		if($sqlConnection.State -ne "Open") {
            $sqlConnection.Open()
        }

        Check-PostMigStopBannerProcess;
        
        if($isStopBannerProcess -eq $False){
			
        $elapsed = [System.Diagnostics.Stopwatch]::StartNew();
		$StartTime = Get-Date
		$LogMeggage = "Get Banner Next Site Start Time: "+$StartTime;
		Write-Log $LogMeggage

		#Get Banner Site Ready for Banner
        
        Write-Log $LogMeggage;
		Write-Log "Get Banner Next Site Duration - "$elapsed.Elapsed.ToString();

		$Global:bannerReadySite = Get-PostMigBannerSite;
		
		$EndTime = Get-Date
		$LogMeggage = "Get Banner Next Site End Time: "+$EndTime;
		Write-Log $LogMeggage;
		Write-Log "Get Banner Next Site Duration - "$elapsed.Elapsed.ToString();
	    
        if(-not [string]::IsNullOrEmpty($bannerReadySite.SiteId)){

            #region "Read Site Detail"

            $Global:_siteId = $bannerReadySite.SiteId;
            $Global:_batchId = $bannerReadySite.BatchId;
            $_bannerId = $bannerReadySite.BannerId;
            $Global:_originalurl = $bannerReadySite.OriginalUrl;
            $Global:_targetUrl = $bannerReadySite.TargetUrl;
            $_bannerType = $bannerReadySite.BannerType;
            $_migrationDate = $bannerReadySite.MigrationStartDate;
			$Global:currentJobStep = $bannerReadySite.currentJobStep;
            $_nextJobStep = $bannerReadySite.NextJobStep;
            $Global:_sourceType = $bannerReadySite.SourceType;

            $Global:_presentJobStep = [Int]$currentJobStep;
                                    						  
			$SiteURL = $_originalurl;
            $BannerType = $_bannerType;
			$permissionLevel = $null;
            $BannerTypes = @{ "T-3" = 'CREAM'; "T-2" = 'YELLOW'; "T-1" = 'ORANGE'; "T" = 'RED'; "T-4" = 'GRAY' }
            $_bannerColor = $BannerTypes[$_bannerType];
			
			$PermissionLevels = @{ "T-2" = 'Contribute'; "T" = 'Read' }
			$permissionLevel = $PermissionLevels[$_bannerType];

            $Global:isSetPermissionSuccess = $true;
			                          
			$TextColors = @{ "T-3" = 'Cyan'; "T-2" = 'Yellow'; "T-1" = 'Magenta'; "T" = 'Red'; "T-4" = 'Gray' }
			$TextColor = $TextColors[$_bannerType]

            $Global:fk_Site = $_siteId;
            if(-not [string]::IsNullOrEmpty($_batchId)){
                $Global:fk_Batch = $_batchId;
            }
            else{
                $Global:fk_Batch = 0;
            }
			
            if($Global:batchNo -ne $Global:fk_Batch){
                $_fileName = "grayBanner_Batch"+$Global:fk_Batch;
                $Global:batchNo = $Global:fk_Batch;
                Create-LogFile $_fileName;
            }

            			
            Function BannerSiteInfo(){
               
                $LogMessage = "Site Id:" +$_siteId;
                    Write-Log $LogMessage;
                $LogMessage = "Batch Id:" +$_batchId;
                    Write-Log $LogMessage;
                $LogMessage = "Source Site Url:" +$_originalurl;
                    Write-Log $LogMessage;
                $LogMessage = "Target Site Url:" +$_targetUrl;
                    Write-Log $LogMessage
                $LogMessage = "Banner Id:" +$_bannerId;
                    Write-Log $LogMessage;
                $LogMessage = "Banner Type:" +$BannerType;
                    Write-Log $LogMessage;
                $LogMessage = "Banner Color:" +$_bannerColor;
                    Write-Log $LogMessage;
                $LogMessage = "Migration Date:" +$_migrationDate;
                 Write-Log $LogMessage;
                $LogMessage = "Source Type:" +$_sourceType;
                 Write-Log $LogMessage;
            }

            #-------------- Banner Site Info -----------
               
            BannerSiteInfo
            			
            #-----------------------------------  Banner Site Info -------------------------------------

            #endregion "Read Site Detail"

           Try
           {
                $jobFailuresTable = "Mig_Sites_MigrationJobFailures"
                $query_UpdateJobFailuresTable = "update [$jobFailuresTable] set DefectStatus='Closed' where fk_jobStep="+$([int]$_presentJobStep)+" and fk_Batch=" + $([int]$fk_Batch) + " and fk_Site=" + $([int]$fk_Site)
                Execute-SqlQuery $sqlConnection $query_UpdateJobFailuresTable
           }
           Catch
           {
                $logMsg = "Update MigrationJobFailures Failure: " +$_.Exception.Message         
			    [string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
			    Add-Content -Path $Global:logPath -Value $logMessage
           }
            
          Try
          {
            
            #region ---- Get SPCredential -----

            $LogMessage = "Get SPCredential for the Site Id: " + $_siteId         
            Write-Log $LogMessage
			
			#Step2 Get Context for Source and Target sites
            if($_sourceType.ToLower().Trim().IndexOf("intranet") -ne -1) {
            $Global:Ctx = Get-SPContext $SiteURL $sourceCredentials.LoginId $sourceSecurePassword
            }
            elseif($_sourceType.ToLower().Trim().IndexOf("extranet") -ne -1) {
                $Global:Ctx = Get-SPContext $SiteURL $sourceExtranetCredentials.LoginId $sourceExtranetSecurePassword
            }
            else {
                $Global:Ctx = Get-SPContext $SiteURL $sourceSpoCredentials.LoginId $sourceSpoSecurePassword
            }

            #Get the Web
            $Web = $Ctx.Web;
            $Ctx.Load($Web);
            $Site = $Ctx.Site
            $Ctx.Load($Site)

            $UserCustomActions = $Ctx.Web.UserCustomActions;
            $PropertyValues = $Ctx.Web.AllProperties;
            $Ctx.Load($UserCustomActions);
            $Ctx.Load($PropertyValues);

            #-----------------------------------  Execute Site Context -------------------------------------
            $LogMessage = "Execute Site Context";         
            ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
			$LogMessage = "Connection Established successfully for the Site: "+ $SiteURL;         
            Write-Log $LogMessage
			#endregion ---- Get SPCredential -----
			
            $Global:siteType = "cws"
            If($($Web.Url.ToLower() -eq $($Site.Url.ToLower())))
            {
                $Global:siteType = "ews"
            }

			#Step4 Add Banner   
            #region --- Add Banner Execution Start ---

            Function Add-Banner($targetUrl, $migrationDate, $bannerColor)
            {
                Try 
                {
                
                $js = "$"+"("+"document"+")"+".ready(function(){
				
				    var cdnJSFilePath = window.location.protocol + ""//"" + window.location.host + ""/"+$userCustomActionCDNPath+""";
			        var cdnCSSFilePath = window.location.protocol + ""//"" + window.location.host + ""/"+$userCustomActionCssCDNPath+""";
					
				    var head = document.getElementsByTagName('head')[0];
                    var script = document.createElement('script');
                    script.type = 'text/javascript';
                    script.src = cdnJSFilePath;
                    head.appendChild(script);
					
					var head  = document.getElementsByTagName('head')[0];
			        var link  = document.createElement('link');
			        link.id   = 'cssId';
			        link.rel  = 'stylesheet';
			        link.type = 'text/css';
			        link.href = cdnCSSFilePath;
			        link.media = 'all';
			        head.appendChild(link);
					
                });";
								
                #Check if the Custom Action Exists already
                $CustomAction = $UserCustomActions | Where { $_.Sequence -eq $customActionSequenceNo } | Select ID, Title
									    
                    If($CustomAction -eq $Null)
                    {
                        #Add new custom action
                        $UserCustomAction = $Ctx.Web.UserCustomActions.Add()
                         #Set the Properties of the custom action
                        $UserCustomAction.Name = $customActionTitle;
                        $UserCustomAction.Description = "Banner msg added to top";
                        $UserCustomAction.Location = "ScriptLink"
                        $UserCustomAction.ScriptBlock = $js;
                        $UserCustomAction.Sequence = $customActionSequenceNo;
                        $UserCustomAction.Update();;
                        ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
                        
                        $LogMessage = "`t Custom Action Added Successfully!"
                        Write-Log $LogMessage;
                    }
                    Else
                    {
                        Write-Log "`t Custom Action Already Exists!";
                    }
                    
						
					$existingDestinationUrl = $PropertyValues["DestinationUrl"]
					$logMsg = "Propery Bag existing target url: "+$existingDestinationUrl
					[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)
					Add-Content -Path $Global:logPath -Value $logMessage
						
					$logMsg = "DB current target url: "+$_targetUrl
					[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)
					Add-Content -Path $Global:logPath -Value $logMessage
						
					# Add Properties
					Try
					{
						if(-not [string]::IsNullOrEmpty($existingDestinationUrl) -and -not [string]::IsNullOrEmpty($_targetUrl)){
							if($existingDestinationUrl.ToLower().Trim() -ne $_targetUrl.ToLower().Trim()){
							$logMsg = "The current target url is not equal to the existing property bag target url."
							[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)
							Add-Content -Path $Global:logPath -Value $logMessage
							   
							$PropertyValues["DestinationUrl"] = $_targetUrl;
							$logMsg = "The Property Bag target url has been updated by current target url."
							[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)
							Add-Content -Path $Global:logPath -Value $logMessage
							}
							else{
							$logMsg = "The current target url is equal to the existing property bag target url."
							[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)
							Add-Content -Path $Global:logPath -Value $logMessage
							$isValidProcess = $False
							}
						}
						elseif(-not [string]::IsNullOrEmpty($_targetUrl)){
							$PropertyValues["DestinationUrl"] = $_targetUrl;
							$logMsg = "Since the Property Bag target url is empty, the new target url is updated."
							[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)
							Add-Content -Path $Global:logPath -Value $logMessage
						}
						else{
							$PropertyValues["DestinationUrl"] = "Site provisioning not completed yet.";
							$logMsg = "Site provisioning not completed yet for the Site Id "+$_siteId
							[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)
							Add-Content -Path $Global:logPath -Value $logMessage
						}
					}
					Catch{
						$logMsg = "Error on Add-Banner!" +$_.Exception.Message
						[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)
						Add-Content -Path $Global:logPath -Value $logMessage
                        throw
					}
                    
					$PropertyValues["BannerColor"] = $bannerColor
                    $PropertyValues["SiteType"] = $siteType

					$Web.Update();
					ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
						
					$LogMessage = "`t Banner "+$BannerType+ "(" +$bannerColor+") added successfully!"
					Write-Log $LogMessage;
				

                } 
                Catch
                {
                    Set-IsPermissionSuccess
                    $ErrorMessage = "Error on Add-Banner!" +$_.Exception.Message
                    Write-Log $ErrorMessage;
                    Start-Sleep 5
                    Set-ChangeStatus $ErrorMessage $($_.ScriptStackTrace);
                }
            }
            
            #endregion
            # Add-Banner Execution End---
                         
            If($isSetPermissionSuccess -eq $true){
			#      -------------- Add-Banner Start ----------------------------

		$elapsed = [System.Diagnostics.Stopwatch]::StartNew()
		$Time = Get-Date #-format "yyyy-MM-dd-HH-mm-ss-ff"
		$LogMeggage = "Add Banner Start: "+$Time;
		Write-Log $LogMeggage;

#Step4 Add-Banner
Add-Banner $_targetUrl $_migrationDate $_bannerColor

		$Time = Get-Date #-format "yyyy-MM-dd-HH-mm-ss-ff"
        $LogMeggage = "Add Banner End: "+$Time;
        Write-Log $LogMeggage;
        $logMsg = "Add Banner Duration -"+ $($elapsed.Elapsed.ToString());
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
		Add-Content -Path $Global:logPath -Value $logMessage
                    
            }
                        
            #region Execute Failure Process
            if($isSetPermissionSuccess -eq $true) { $excutedValue = "Process executed successfully"; } else { $excutedValue = "Process executed failure"; }
            Write-Log $excutedValue;

            If($isSetPermissionSuccess -eq $true){

			$elapsed = [System.Diagnostics.Stopwatch]::StartNew()
			$Time = Get-Date #-format "yyyy-MM-dd-HH-mm-ss-ff"
			$LogMeggage = "Set PostMig Update Banner Status Start: "+$Time;
			Write-Log $LogMeggage;
		
#FinalStep on SQL Update
Set-PostMigUpdateBannerStatus $_siteId $_bannerId $_presentJobStep $_nextJobStep

			$Time = Get-Date #-format "yyyy-MM-dd-HH-mm-ss-ff"
			$LogMeggage = "Set PostMig Update Banner Status End: "+$Time;
			Write-Log $LogMeggage;
			Write-Log "Set PostMig Update Banner Status Duration: " $($elapsed.Elapsed.ToString());
			}
			else
			{
				# Rollback Permission
				#Revoke-SPPropertyBagValues
				
                $ErrorMessage = "Set Permission success process failure!";
				$ErrorStack = "Set Permission process has been failed due to some interuption, Please refer the log files for further info.";
                Write-Log $ErrorMessage;
                Start-Sleep 5
                Set-ChangeStatus $ErrorMessage $ErrorStack;
            }

            $permissionLevel = $null;
            $Ctx.Dispose();

            $LogMeggage = "Banner Process Completed Successfully!";
            Write-Log $LogMeggage
            
		    $EndTime = Get-Date #-format "yyyy-MM-dd-HH-mm-ss-ff"
		    $LogMeggage = "Banner Action End Time for the Site Id: "+$EndTime;
		    Write-Log $LogMeggage

		    $DiffTime = New-TimeSpan -Start $StartTime -End $EndTime
	        $LogMeggage = "`t `tSiteID: "+$_siteId+"-Banner Action Duration: "+$DiffTime;
	        Write-Log $LogMeggage
		    Write-Log "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
            
            Start-Sleep 5
            $LogMeggage = "Initiate Next Post Migration Site";
            Write-Log $LogMeggage
            $Global:isSetPermissionSuccess = $true;
            $isNextSiteExist = $true;
            #Iterate the Init-Post-Migrate-Get-Banner Process

        }
          catch{
            $ErrorMessage = "Init-PostMigBannerSite Line No 637: " +$_.Exception.Message
            Write-Log $ErrorMessage;
            $Global:isSetPermissionSuccess = $true;
			#Iterate the Init-Post-Migrate-Get-Banner Process due to the Existing Site got error          
            Set-ChangeStatus $ErrorMessage $($_.ScriptStackTrace);
            Start-Sleep 5	
			$isNextSiteExist = $true;
          }

        }
        
		else
        {
            Write-Log "Next banner site not found for ready to proceed";
            $isNextSiteExist = $False;
        }
      
        }
        else{
            $logMsg = "Banner process has been stopped";
			[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
			Add-Content -Path $Global:logPath -Value $logMessage
            $isNextSiteExist = $False;
        }
      }
    }
    catch
    {
        $ErrorMessage = "Error on Init-PostMigBannerSite: " +$_.Exception.Message
         Write-Log $ErrorMessage;
    }
}

#Set Stored Procedure Dynamic Input parameter values for Exception logs
Function Set-ExceptionLogsParameters {
    Param(      
        [Parameter(Mandatory = $true)] $parameters,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $process,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $exceptionMessage,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $exceptionStackTrace
    )
    try {
        $ipAddress = (Get-NetIPAddress -AddressFamily IPv4)[0].IPAddress
        $parameters = foreach($item in $parameters.Item) {    
            Switch($item.Name) {
                "@fk_jobstep" { $item.Value = [String]$_presentJobStep ; break }
                "@operation" { $item.Value = [String]$process + $ipAddress ; break }
                "@SiteId" { $item.Value = [String]$_siteId; break }
                "@BatchId" { $item.Value = [String]$_batchId; break }                     
                "@source" { $item.Value = $_originalurl; break }
                "@target" { $item.Value = $_targetUrl; break }
                "@information" { $item.Value = $exceptionMessage; break }
                "@details" { $item.Value = $exceptionStackTrace; break }
            }
        }
    }
    catch {
                
    }
}

Function Set-ChangeStatus($exceptionMsg,$ScriptStackTrace=$null){
	try {
        
        $sqlQry = "select appCodeIndex as appCodeIndex from [dbo].[MigDef_JobSteps] where id = "+$_presentJobStep;
        $jobStepData = Get-ContentFromSqlQuery $sqlConnection $sqlQry
        $_appCodeIndex = [Int]$jobStepData.appCodeIndex;

        ChangeStatus-InputParameters $_siteId $_batchId $sprocStatusChangeDynamicParameters $_appCodeIndex "600" $ScriptStackTrace
        $changeStatusParameters = $sprocStatusChangeInputParameters,$sprocStatusChangeDynamicParameters
        Execute-StrdProcWithParameters $sqlConnection $sprocStatusChange $changeStatusParameters $null
        
		$exceptionMsg = $($exceptionMsg).Replace('"', '`"');
        #Exception logs
        Set-ExceptionLogsParameters $sprocExcepLogsDynamicParameters "Automated-Banner" $exceptionMsg $ScriptStackTrace            
        $inputParameters = $sprocExcepLogsInputParameters,$sprocExcepLogsDynamicParameters
        Execute-StrdProcWithParameters $sqlConnection $sprocExcepLogging $inputParameters $null
		
	    $LogMessage = "Marking this site("+$_siteId+") job step status("+$_presentJobStep+") as Failure - Completed in SQL DB";
		Write-Log $LogMessage;
       
    }
    catch {
        return $_.Exception.Message
    }
}

Function IsAuthorizedSite(){
	try{

        $SiteURL = "https://eytaxca.sharepoint.com/Sites/12543c35bc51476a8cd959e64995ef70"
		$LogMessage = "Get SPCredential for the Site: " + $SiteURL         
        Get-SPContext -source $SiteURL -userId $srcUserName -securePassword $srcPassword

        #Get the Web
        $Web = $Ctx.Web;
        $Ctx.Load($Web);
        #-----------------------------------  Execute Site Context -------------------------------------
        $LogMessage = "Execute Site Context";         
        ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
		$LogMessage = "Connection Established successfully for the Site Url: "+ $SiteURL; 
        
	}
	catch{
		$ErrorMessage = $_.Exception.Message
        Set-ChangeStatus $ErrorMessage $($_.ScriptStackTrace);
	}
	finally{
		$Ctx.Dispose();
	}
}

#Fetching SQL Server Details
$sqlServerInstance = $configXmlfile.ConfigSettings.SqlSettings.SqlDbServer
$sqlDatabase = $configXmlfile.ConfigSettings.SqlSettings.SqlDatabase

#StoredProcedure - Change Status
$sprocStatusChange = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ChangeStatus.Name
$sprocStatusChangeInputParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ChangeStatus.InputParameters
$sprocStatusChangeDynamicParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ChangeStatus.DynamicInputParameters

#StoredProcedure - Exception logging
$sprocExcepLogging = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ExceptionLogging.Name
$sprocExcepLogsInputParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ExceptionLogging.InputParameters
$sprocExcepLogsDynamicParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ExceptionLogging.DynamicInputParameters

#Fetch SQL and SharePoint Credentials from Azure KeyVault
$azAppId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.ApplicationId
$azTenantId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.TenantId
$azCertificates = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.CertificateThumbprint
$azVault = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.VaultName
$azOrchDbUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.OrchestrationUserId
$azOrchDbPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.OrchestrationPassword

$azSourceIntranetUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceIntranetUserId
$azSourceIntranetPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceIntranetPassword
$azSourceExtranetUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceExtranetUserId
$azSourceExtranetPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceExtranetPassword
$azSourceSpoUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceSPOUserId
$azSourceSpoPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceSPOPassword
#$azSourceSpoUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.Banner.SourceSPOUserId
#$azSourceSpoPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.Banner.SourceSPOPassword

$azTargetUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.TargetUserId
$azTargetPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.TargetPassword

try{
	#Fetch SQL DB Credentials from Azure Keyvault
	$dbCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azOrchDbUserId $azOrchDbPassword -WarningAction SilentlyContinue -ErrorAction Stop   
	$secureDbPassword = $dbCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force

	#Fetch Source Sites Credentials from Azure keyvault
	$sourceCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azSourceIntranetUserId $azSourceIntranetPassword -WarningAction SilentlyContinue -ErrorAction Stop
	$sourceSecurePassword = $sourceCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force

	#Fetch Source Extranet Sites Credentials from Azure keyvault
    if(-not [string]::IsNullOrEmpty($azSourceExtranetUserId)){
	    $sourceExtranetCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azSourceExtranetUserId $azSourceExtranetPassword -WarningAction SilentlyContinue -ErrorAction Stop    
	    $sourceExtranetSecurePassword = $sourceExtranetCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force
    }

    #Fetch Source SPO Sites Credentials from Azure keyvault
    if(!([String]::IsNullOrEmpty($azSourceSpoUserId)) -and !([String]::IsNullOrEmpty($azSourceSpoPassword))) {
        $sourceSpoCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azSourceSpoUserId $azSourceSpoPassword  -WarningAction SilentlyContinue       
        $sourceSpoSecurePassword = $sourceSpoCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force
    }

	#Fetch Target Sites Credentials from Azure keyvault
    if(-not [string]::IsNullOrEmpty($azTargetUserId)){
	    $targetCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azTargetUserId $azTargetPassword -WarningAction SilentlyContinue -ErrorAction Stop
        $targetSecurePassword = $targetCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force
    } 
}
catch{
	Write-Log "Exception in fetching Azure Keyvault details `n"+$_.Exception.Message
}

#StoredProcedure - Fetch Banner sites
$postMigGetBanner = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.GetPostMigNextBannerSite.SPName
$appInstanceId = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.GetPostMigNextBannerSite.AppInstance
$updatePostMigBanner = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.UpdatePostMigNextBannerSite.SPName
$postMigStopBannerProcess = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.PostMigStopBannerProcess.SPName

#Banner Properties
$userCustomActionCDNPath = $configXmlfile.ConfigSettings.sp.banner.customactioncdnpath;
$userCustomActionCssCDNPath = $configXmlfile.ConfigSettings.sp.banner.customactioncsscdnpath;
$customActionTitle = $configXmlfile.ConfigSettings.sp.banner.customactiontitle;
$customActionSequenceNo = $configXmlfile.ConfigSettings.sp.banner.customactionsequenceno;

if($Ctx -ne $null){
  $Ctx.Dispose();
} 

Write-Log "Init-PostMigCommunicationBanner method started!";

#Build SQL Connection
$sqlConnection = New-Object System.Data.SqlClient.SqlConnection
$sqlConnection.ConnectionString = Get-SqlConnectionString $dbCredentials.LoginId $secureDbPassword $sqlServerInstance $sqlDatabase
$sqlConnection.Open();

#To Check whether the source site has right CSOM acccess!!!
#IsAuthorizedSite

Function Fill-Data() {
    try {
        $sqlQuery = "DECLARE @Returncode INT;
DECLARE @ReloadCode INT;
EXEC sp_postmig_get_gray_banner_next_site '23-2', @Returncode OUTPUT,@ReloadCode OUTPUT,0
"
        $sqlCommand = New-Object System.Data.SqlClient.SqlCommand
        $sqlCommand.CommandText =  $sqlQuery #"EXEC sp_postmig_get_gray_banner_next_site_0410"
        $sqlCommand.Connection = $sqlConnection
        $sqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter  
        $sqlAdapter.SelectCommand = $sqlCommand
        $sqlAdapter.SelectCommand.CommandTimeout=30   
        $dataSet = New-Object System.Data.DataSet  
        $sqlAdapter.Fill($dataSet)

        $results = (0, $dataSet.Tables[0].Rows)[$dataSet.Tables[0].Rows.Count -gt 0]
       
        return $results;

    }
    catch {
        $logMsg = $_.Exception.Message;
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)  
        Add-Content -Path $Global:logPath -Value $logMessage
    }    
    
}

#Fill-Data

Init-PostMigBannerSite

Try{
    # Added on 04/29/2021
    $sqlConnection.Dispose();
}
Catch { }
$sqlConnection.Close();

Write-Log "Init-PostMigCommunicationBanner method ended!";

Write-Log "----------Banner process ended.............";


