


function Dispose-All 
{
    <#  .DESCRIPTION         Disposes of all memory used.,        .EXAMPLE        Dispose-All    #>
	
Get-Variable -exclude Runspace | Where-Object {$_.Value -is [System.IDisposable] -and $_.Value.GetType().Name -ne "SqlBulkCopy"} | 
		Foreach-Object { $_.Value.Dispose() }
}

Function Invoke-LoadMethod() {
param(
   [Microsoft.SharePoint.Client.ClientObject]$Object = $(throw "Please provide a Client Object"),
   [string]$PropertyName
) 
   $ctx = $Object.Context
   $load = [Microsoft.SharePoint.Client.ClientContext].GetMethod("Load") 
   $type = $Object.GetType()
   $clientLoad = $load.MakeGenericMethod($type) 


   $Parameter = [System.Linq.Expressions.Expression]::Parameter(($type), $type.Name)
   $Expression = [System.Linq.Expressions.Expression]::Lambda(
            [System.Linq.Expressions.Expression]::Convert(
                [System.Linq.Expressions.Expression]::PropertyOrField($Parameter,$PropertyName),
                [System.Object]
            ),
            $($Parameter)
   )
   $ExpressionArray = [System.Array]::CreateInstance($Expression.GetType(), 1)
   $ExpressionArray.SetValue($Expression, 0)
   $clientLoad.Invoke($ctx,@($Object,$ExpressionArray))
}

#To call a non-generic method Load
  
#Function to Get Webs's Permissions from given URL
Function Get-SPOWebPermission([Microsoft.SharePoint.Client.ClientContext]$Ctx)
{
    $web = $Ctx.Web;
    $Ctx.Load($web) 
    ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
   
    #Call the function to Get Lists of the web
    #Write-host -f Yellow "Getting the Permissions of Web "$web.URL"..."
    #    "Iterating through Permissions of web in the List:"+ $web.URL| 
    #
    ##Check if the Web has unique permissions
    Invoke-LoadMethod -Object $web -PropertyName "HasUniqueRoleAssignments"
    ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
  
    #Get the Web's Permissions
    If($web.HasUniqueRoleAssignments -eq $true)
    {
        Get-Permissions $Ctx -Object $web -SiteURL $SiteURL
    }
  
    #Scan Lists with Unique Permissions
    #Write-host -f Yellow "`t Getting the Permissions of Lists and Libraries in "$Web.URL"..."
    
    Get-SPOListPermission $Ctx $web
   
   
}

        #Function to Get Permissions of all lists from the web
Function Get-SPOListPermission([Microsoft.SharePoint.Client.ClientContext]$Ctx, [Microsoft.SharePoint.Client.Web]$Web)
{
    #Get All Lists from the web
    Try{
        $Lists = $Web.Lists
        $Ctx.Load($Lists)
        ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
  
        #Get all lists from the web  
        ForEach($List in $Lists)
        {
            #Exclude System Lists
            If($List.Hidden -eq $False)
            {
                #Get List Items Permissions
                # Get-SPOListItemsPermission $List 

  
                #Get the Lists with Unique permission
                Invoke-LoadMethod -Object $List -PropertyName "HasUniqueRoleAssignments"
                ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
  
                If( $List.HasUniqueRoleAssignments -eq $True)
                {
                    #Call the function to check permissions
                    Get-Permissions $Ctx -Object $List -SiteURL $SiteURL
                }
            }
        }
    }
    Catch{        
        $logMsg = $_.Exception.Message         
		$logMsg = "Init-SitePermissionsSetProcess for the Site Id: "+$_siteId
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)
        throw
    }
}
  
  
#Function to Get Permissions Applied on a particular Object, such as: Web, List or Item
Function Get-Permissions([Microsoft.SharePoint.Client.ClientContext]$Ctx,
[Microsoft.SharePoint.Client.SecurableObject]$Object, $SiteURL)
{
    Try{
       #Determine the type of the object
        Switch($Object.TypedObject.ToString())
        {
            "Microsoft.SharePoint.Client.Web"  { $ObjectType = "Site" ; $ObjectURL = $Object.URL }
       
           Default
            {
                $ObjectType = "List/Library"
                #Get the URL of the List or Library
                $Ctx.Load($Object.RootFolder)
                ExecuteQueryWithIncrementalRetry $Ctx 3 5000;  
       
                $ObjectURL = $("{0}{1}" -f $Ctx.Web.Url.Replace($Ctx.Web.ServerRelativeUrl,''), $Object.RootFolder.ServerRelativeUrl)
            }
        }
  
        #Get permissions assigned to the object
        $Ctx.Load($Object.RoleAssignments)
        ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
  
        Foreach($RoleAssignment in $Object.RoleAssignments)
        {
            $Ctx.Load($RoleAssignment.Member)
            ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
                  
            #Get the Permissions on the given object
            $Permissions=@()
            $Ctx.Load($RoleAssignment.RoleDefinitionBindings)
            ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
            $accName= $RoleAssignment.Member.LoginName 
            try {
            Edit-SPOSitePermission -Context $Ctx -SiteURL $SiteURL  -ObjectType $ObjectType -RoleAssignment $RoleAssignment -ObjectTitle $Object.Title -ObjectURL  $ObjectURL -accName $accName 
            }
            catch {
                if($_.Exception.Message.ToLower().Contains("too many")) {
                    Write-Host $_.Exception.Message -ForegroundColor Red
                }
                else {
                    throw
                }
            }
        }
    }
    Catch{        
        $logMsg = $_.Exception.Message         
        $logMsg = "Init-SitePermissionsSetProcess for the Site Id: "+$_siteId
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)
        Write-Host $_.Exception.Message -ForegroundColor Red
        throw
    }
}


#Function to Edit Permissions 
Function Edit-SPOSitePermission([Microsoft.SharePoint.Client.ClientContext]$Context, $SiteURL,$ObjectType,$RoleAssignment,$ObjectTitle,$ObjectURL,$accName)
{
Try{#$accName= $RoleAssignment.Member.LoginName 
    if(($RoleAssignment.Member.PrincipalType -eq "SharePointGroup") -or ($RoleAssignment.Member.PrincipalType -eq "SecurityGroup") -or ($RoleAssignment.Member.PrincipalType -eq "User"))
         {      $ReadRole = �Read�
                $RnPRole = �Read and Personalize"
                $vRole = �View Only"
                $cRole  = "Contribute"             
                $Inheritance = "Custom"            
                #$selColumns = "Type","Name","URL","Inheritance","User/group","Principaltype","Accountname","Permissions","TargetURL","DesURL"	
                $selColumns = "TypeOfContent","SiteName","SourceURL","Inheritance","UserGroup","Principaltype","Accountname","ContentPermissions" #,"TargetURL","DesURL"	
                $perSource = $getPostMigrationSiteDetails | Select-Object -Property $selColumns
                

                $cdtn = ( ($_.ContentPermissions -notmatch $ReadRole) -or ($_.ContentPermissions -notmatch $RnPRole) -or ($_.ContentPermissions -notmatch $vRole) )
                #Write-Host $ObjectType $ObjectTitle $ObjectURL
                
                $selSPOPer +=  $perSource| Where-Object {( $_.SourceURL -match  $ObjectURL) -and ($_.Inheritance -match  $Inheritance) -and ($_.TypeOfContent -match $ObjectType) -and (($_.AccountName -like $RoleAssignment.Member.LoginName) -or($_.AccountName.replace("\","\\") -match $RoleAssignment.Member.Title.replace("\","\\"))) -and $cdtn}| Select-Object  {$_.ContentPermissions} 
         if($selSPOPer.'$_.ContentPermissions' -ne $null)
            {    $selSPOPerArr =$selSPOPer.'$_.ContentPermissions'.Split(";")

                 #Get the Permissions on the given object
                 $Permissions=@()
                 Foreach ($RoleDefinition in $RoleAssignment.RoleDefinitionBindings)                    
                    { $Permissions += $RoleDefinition.Name }
                 
                  
              
                                                                                  
           $counter = $selSPOPerArr.Count - 1
          for($i=0;$i -lt $counter ;$i++)  
            { #Get Permission Levels to add and remove
                    $AddPermission = $selSPOPerArr[$i]
                    $DispPermission ="No"
                                    
                    if($AddPermission -ne "Site Collection Administrator")
                    {  
                     if($AddPermission.Length -ne 0){ $RoleDefToAdd = $Ctx.web.RoleDefinitions.GetByName($AddPermission)
                     #Add Permission level to the group
                      if (($RoleAssignment.RoleDefinitionBindings.Name -notcontains $AddPermission ))
                       {
                          $RoleAssignment.RoleDefinitionBindings.Add($RoleDefToAdd)                                                                                        
                          $RoleAssignment.Update()
                           
                       } 
                       }
                       
                       if (($selSPOPerArr -notcontains $ReadRole) -and ($RoleAssignment.RoleDefinitionBindings.Name -contains $ReadRole ))
                       {
                          $RoleDefToRmvRead = $Ctx.web.RoleDefinitions.GetByName($ReadRole)  
                          $RoleAssignment.RoleDefinitionBindings.Remove($RoleDefToRmvRead)                                                                                        
                          $RoleAssignment.Update()
                          $DispPermission = $ReadRole    
                       }
                       elseif(($selSPOPerArr -notcontains $RnPRole) -and ($RoleAssignment.RoleDefinitionBindings.Name -contains $RnPRole ))
                       {  
                          $RoleDefToRmvRnP = $Ctx.web.RoleDefinitions.GetByName($RnPRole) 
                          $RoleAssignment.RoleDefinitionBindings.Remove($RoleDefToRmvRnP)                                                                                        
                          $RoleAssignment.Update()
                          $DispPermission = $RnPRole 
                       }
                       elseif( ($selSPOPerArr -notcontains $vRole) -and ($RoleAssignment.RoleDefinitionBindings.Name -contains $vRole ))
                       {  
                          $RoleDefToRmvVO = $Ctx.web.RoleDefinitions.GetByName($vRole) 
                          $RoleAssignment.RoleDefinitionBindings.Remove($RoleDefToRmvVO)                                                                                        
                          $RoleAssignment.Update()
                          $DispPermission = $RnPRole 
                        }
                        elseif( ($selSPOPerArr -notcontains $cRole) -and ($RoleAssignment.RoleDefinitionBindings.Name -contains $cRole ))
                       {  
                          $RoleDefToRmvCon = $Ctx.web.RoleDefinitions.GetByName($cRole)
                          $RoleAssignment.RoleDefinitionBindings.Remove($RoleDefToRmvCon)                                                                                        
                          $RoleAssignment.Update()
                          $DispPermission = $RnPRole 
                        }
                       ExecuteQueryWithIncrementalRetry $Ctx 3 5000;
                       
                    } 
                }  
               }
            
             
              }
             }
     Catch{
        if($_.Exception.Message.ToLower().Contains("permission level specified is already added to the collection")) {
            Write-Host $_.Exception.Message -ForegroundColor Red
        }
        else {
            $logMsg = $_.Exception.Message  
            #The permission level specified is already added to the collection.       
            $logMsg = "Init-SitePermissionsSetProcess for the Site Id: "+$_siteId
		    [string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)
            Write-Host $logMsg
            throw
            }
     }
}

Function Fetch-PermissionsMigration(){
    Param(
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $storedProcedure,        
        [Parameter(Mandatory = $true)] $inputParameters,
        [Parameter(Mandatory = $false)] $outputParameters
    )
    try {
                
        $sqlCommand = New-Object System.Data.SqlClient.SqlCommand
        $sqlCommand.CommandText = $storedProcedure
        $sqlCommand.Connection = $sqlConnection
        $sqlCommand.CommandType = [System.Data.CommandType]::StoredProcedure
        $sqlCommand.Parameters.Clear()
        
        #Build the Inuput/Output parameters
        $strParameters = Format-StrdProcParameters $inputParameters $outputParameters "sqlCommand"
        Invoke-Expression $strParameters
        
        $sqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter  
        $sqlAdapter.SelectCommand = $sqlCommand 
        $sqlAdapter.SelectCommand.CommandTimeout=300  
        
        #Creating Dataset  
        $dataSet = New-Object System.Data.DataSet  
        $sqlAdapter.Fill($dataSet)       


        $results = (0, $dataSet.Tables[0])[$dataSet.Tables[0].Rows.Count -gt 0]
        return $results
       
    }
    catch {
        $logMsg = $_.Exception.Message         
        $logMsg = "Init-SitePermissionsSetProcess for the Site Id: "+$_siteId
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)
        throw        
    }
    
} 

#Build Input/Output parameters for StoredProcedure
Function Format-StrdProcParameters() {
    Param(
        [Parameter(Mandatory = $true)] $inputParameters,
        [Parameter(Mandatory = $false)] $outputParameters,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $inputString
    )
    try {
        [String]$ioParameters = $null
        $counter = 0
        $inputParameters.SelectNodes("Item") | ForEach-Object {
            $counter++
            $parameter = "$" + "param" + $counter
            if($_.Type.ToLower().Trim() -eq "string") {
                $ioParameters += "$parameter = New-Object System.Data.SqlClient.SqlParameter `n"
                $ioParameters += "$parameter.ParameterName = `"$($_.Name)`" `n"
                $ioParameters += "$parameter.Direction = [System.Data.ParameterDirection]::Input `n"
                $ioParameters += "$parameter.Value = `"$($_.Value)`" `n"
                $ioParameters += "$" + "$inputString.Parameters.Add($parameter) `n"
            }
            if($_.Type.ToLower().Trim() -eq "int32") {
                $ioParameters += "$parameter = New-Object System.Data.SqlClient.SqlParameter `n"
                $ioParameters += "$parameter.ParameterName = `"$($_.Name)`" `n"
                $ioParameters += "$parameter.Direction = [System.Data.ParameterDirection]::Input `n"
                $ioParameters += "$parameter.Value = `"$($_.Value)`" `n"
                $ioParameters += "$" + "$inputString.Parameters.Add($parameter) `n"       
            }    
        }
        if($outputParameters -ne $null) {
            $outputParameters.SelectNodes("Item") | ForEach-Object {
                $counter++
                $parameter = "$" + "param" + $counter
                if($_.Type.ToLower().Trim() -eq "string") {
            
                    $ioParameters += "$parameter = New-Object System.Data.SqlClient.SqlParameter `n"
                    $ioParameters += "$parameter.ParameterName = `"$($_.Name)`" `n"
                    $ioParameters += "$parameter.Direction = [System.Data.ParameterDirection]::Output `n"
                    $ioParameters += "$parameter.DbType = [System.Data.DbType]::String `n"
                    $ioParameters += "$parameter.Size = $($_.CharLength) `n"
                
                 
                }
                if($_.Type.ToLower().Trim() -eq "int32") {
                    $ioParameters += "$parameter = New-Object System.Data.SqlClient.SqlParameter `n"
                    $ioParameters += "$parameter.ParameterName = `"$($_.Name)`" `n"
                    $ioParameters += "$parameter.Direction = [System.Data.ParameterDirection]::Output `n"
                    $ioParameters += "$parameter.DbType = [System.Data.DbType]::Int32 `n"       
                }
                $ioParameters += "$" +"$inputString.Parameters.Add($parameter) | Out-Null `n"            
            }
        }
        return $ioParameters
    }
    catch {
        #Write-Host "Failed in BuildStoredProcedureParameters: " $_.Exception.Message -ForegroundColor Red
        throw
    }    
}

#Set parameter values

#$ReportFile=".\SitePermissionRpt.csv"
$BatchSize = 500
$accName = $null

Function Revoke-SPPermissions([Microsoft.SharePoint.Client.ClientContext]$Ctx,$siteId,$batchId,$sourceUrl,$targetUrl,$sqlConnection){

    try{
	
		$logMsg = "Revoke-SPPermissions started ............."
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
		Add-Content -Path $Global:logPath -Value $logMessage
		
        $sprocSitesForPostMigration = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.GetPostMigration_PermissionDetails.Name
        $sprocInputParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.GetPostMigration_PermissionDetails.InputParameters
        Write-Host $sprocInputParameters
        $sprocInputParameters.InnerXml = "<Item Name='@Siteid' Type='Int32' Value='"+$siteId+"' />"
        $sprocOutputParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.GetPostMigration_PermissionDetails.OutputParameters
         
        $getPostMigrationSiteDetails = Fetch-PermissionsMigration $sprocSitesForPostMigration $sprocInputParameters $sprocOutputParameters
        $getPostMigrationSiteDetails  = $getPostMigrationSiteDetails | select -Skip 2

        #$SiteURL = $site.TargetURL
        $SiteURL = $sourceUrl
        $SiteURL = $SiteURL.Trim()
        $SiteURL = $SiteURL.TrimEnd('/')
        
        #Call the function
        Get-SPOWebPermission $Ctx

        $endTime = Get-Date
		
		$logMsg = "Revoke-SPPermissions ended ............."
		[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)   
		Add-Content -Path $Global:logPath -Value $logMessage
    
    }
    catch{

            $logMsg = "Revoke-SPPermissions:373" +$_.Exception.Message
            $logMsg = "Init-SitePermissionsSetProcess for the Site Id: "+$_siteId
			[string]$logMessage = [System.String]::Format("[$(Get-Date)] - {0}", $logMsg)
			#Start-Sleep 5
            throw
    }
}