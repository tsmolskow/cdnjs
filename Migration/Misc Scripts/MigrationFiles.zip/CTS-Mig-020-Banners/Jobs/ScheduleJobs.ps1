﻿
Register-ScheduledTask -Xml (get-content 'C:\0-install\CTS\projects\CTS-Mig-020-Banners\Jobs\PreMigration-Banner-CreamToOrange_Bypass.xml' | out-string) -TaskName "PreMigration-Banner-CreamToOrange_Bypass" –Force
Register-ScheduledTask -Xml (get-content 'C:\0-install\CTS\projects\CTS-Mig-020-Banners\Jobs\PreMigration-Banner-CreamToOrange_Inst_1.xml' | out-string) -TaskName "PreMigration-Banner-CreamToOrange_Inst_1" –Force
Register-ScheduledTask -Xml (get-content 'C:\0-install\CTS\projects\CTS-Mig-020-Banners\Jobs\PreMigration-Banner-CreamToOrange_Inst_2.xml' | out-string) -TaskName "PreMigration-Banner-CreamToOrange_Inst_2" –Force
Register-ScheduledTask -Xml (get-content 'C:\0-install\CTS\projects\CTS-Mig-020-Banners\Jobs\PreMigration-Banner-Red_Bypass.xml' | out-string) -TaskName "PreMigration-Banner-Red_Bypass" –Force
Register-ScheduledTask -Xml (get-content 'C:\0-install\CTS\projects\CTS-Mig-020-Banners\Jobs\PreMigration-Banner-Red_Inst_1.xml' | out-string) -TaskName "PreMigration-Banner-Red_Inst_1" –Force
Register-ScheduledTask -Xml (get-content 'C:\0-install\CTS\projects\CTS-Mig-020-Banners\Jobs\PreMigration-Banner-Red-Child_Inst_1.xml' | out-string) -TaskName "PreMigration-Banner-Red-Child_Inst_1" –Force
Register-ScheduledTask -Xml (get-content 'C:\0-install\CTS\projects\CTS-Mig-020-Banners\Jobs\PostMigration-Set-Gray-Banner.xml' | out-string) -TaskName "PostMigration-Set-Gray-Banner" –Force
