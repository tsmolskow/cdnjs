﻿#Build SQL ConnectionString
function Get-SqlConnectionString {
    Param(
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $userId,
        [Parameter(Mandatory = $true)] $password,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $server,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $database
    )
    try {        
        $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($password)
        $dbPassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
        return "Server=$server;Database=$database;timeout=1800;UId=$userId; Pwd='$dbPassword'"
    }
    catch {
        Write-Host "Failed in generating SQL Connection: " $_.Exception.Message -ForegroundColor Red
    }
}

#Build Input/Output parameters for StoredProcedure
function Format-StrdProcParameters {
    Param(
        [Parameter(Mandatory = $true)] $inputParameters,
        [Parameter(Mandatory = $false)] $outputParameters,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $inputString
    )
    try {
        [String]$ioParameters = $null
        $counter = 0
        $inputParameters.SelectNodes("Item") | ForEach-Object {
            $counter++
            $parameter = "$" + "param" + $counter
            if($_.Type.ToLower().Trim() -eq "string") {
                $ioParameters += "$parameter = New-Object System.Data.SqlClient.SqlParameter `n"
                $ioParameters += "$parameter.ParameterName = `"$($_.Name)`" `n"
                $ioParameters += "$parameter.Direction = [System.Data.ParameterDirection]::Input `n"
                $ioParameters += "$parameter.Value = `"$($_.Value)`" `n"
                $ioParameters += "$" + "$inputString.Parameters.Add($parameter) `n"
            }
            if($_.Type.ToLower().Trim() -eq "int32") {
                $ioParameters += "$parameter = New-Object System.Data.SqlClient.SqlParameter `n"
                $ioParameters += "$parameter.ParameterName = `"$($_.Name)`" `n"
                $ioParameters += "$parameter.Direction = [System.Data.ParameterDirection]::Input `n"
                $ioParameters += "$parameter.Value = `"$($_.Value)`" `n"
                $ioParameters += "$" + "$inputString.Parameters.Add($parameter) `n"       
            }    
        }
        if($outputParameters -ne $null) {
            $outputParameters.SelectNodes("Item") | ForEach-Object {
                $counter++
                $parameter = "$" + "param" + $counter
                if($_.Type.ToLower().Trim() -eq "string") {
            
                    $ioParameters += "$parameter = New-Object System.Data.SqlClient.SqlParameter `n"
                    $ioParameters += "$parameter.ParameterName = `"$($_.Name)`" `n"
                    $ioParameters += "$parameter.Direction = [System.Data.ParameterDirection]::Output `n"
                    $ioParameters += "$parameter.DbType = [System.Data.DbType]::String `n"
                    $ioParameters += "$parameter.Size = $($_.CharLength) `n"
                
                 
                }
                if($_.Type.ToLower().Trim() -eq "int32") {
                    $ioParameters += "$parameter = New-Object System.Data.SqlClient.SqlParameter `n"
                    $ioParameters += "$parameter.ParameterName = `"$($_.Name)`" `n"
                    $ioParameters += "$parameter.Direction = [System.Data.ParameterDirection]::Output `n"
                    $ioParameters += "$parameter.DbType = [System.Data.DbType]::Int32 `n"       
                }                
                $ioParameters += "$" +"$inputString.Parameters.Add($parameter) | Out-Null `n"            
            }
        }
        return $ioParameters
    }
    catch {
        Write-Host "Failed in BuildStoredProcedureParameters: " $_.Exception.Message -ForegroundColor Red
        throw
    }    
}

#Execute Stored Procedure with Input/Output parameters
function Execute-StrdProcWithParameters {
    Param(        
        [Parameter(Mandatory = $true)] $sqlConnection,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $storedProcedure,        
        [Parameter(Mandatory = $true)] $inputParameters,
        [Parameter(Mandatory = $false)] $outputParameters
    )
    try {
        $sqlCommand = New-Object System.Data.SqlClient.SqlCommand
        $sqlCommand.CommandText = $storedProcedure
        $sqlCommand.Connection = $sqlConnection
        $sqlCommand.CommandType = [System.Data.CommandType]::StoredProcedure
        $sqlCommand.Parameters.Clear()
        
        #Build the Inuput/Output parameters
        $strParameters = Format-StrdProcParameters $inputParameters $outputParameters "sqlCommand"
        Invoke-Expression $strParameters
        
        $sqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter  
        $sqlAdapter.SelectCommand = $sqlCommand 
        $sqlAdapter.SelectCommand.CommandTimeout=300  
        
        #Creating Dataset  
        $dataSet = New-Object System.Data.DataSet  
        $sqlAdapter.Fill($dataSet)       
        if($outputParameters -ne $null) {
            $formatResponse = $null
            $sqlCommand.Parameters | ForEach-Object {            
                $formatResponse += "$($_.ParameterName.Split('@')[1]) = $($_.Value)" | ConvertFrom-StringData
            }        
            return $formatResponse      
        }        
    }
    catch {
        Write-Host "$($_.Exception.Message) `n" -ForegroundColor Red        
    }
    finally {
        $sqlCommand.Dispose()
    }
}

##Fetch content from SQL
function Get-ContentFromSqlQuery {
    Param(
        [Parameter(Mandatory = $true)] $sqlConnection,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $sqlQuery
    )
    try {        
        $sqlCommand = New-Object System.Data.SqlClient.SqlCommand  
        $sqlCommand.CommandText = $sqlQuery  
        $sqlCommand.Connection = $sqlConnection
        $sqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter  
        $sqlAdapter.SelectCommand = $sqlCommand   
        #Creating Dataset  
        $dataSet = New-Object System.Data.DataSet  
        $sqlAdapter.Fill($dataSet)        
        $results = (0, $dataSet.Tables[0].Rows)[$dataSet.Tables[0].Rows.Count -gt 0]
        return $results
    }
    catch {
        Write-Host "$($_.Exception.Message) `n" -ForegroundColor Red
        throw
    }
    finally {
        $sqlCommand.Dispose()
    }  
}

#Execute SQL Query
function Execute-SqlQuery {
    Param(
        [Parameter(Mandatory = $true)] $sqlConnection,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $sqlQuery
    )
    try {
        $sqlCommand = New-Object System.Data.SQLClient.SQLCommand
        $sqlCommand.CommandText = $sqlQuery
        $sqlCommand.Connection = $sqlConnection
        $sqlCommand.ExecuteNonQuery() | Out-Null        
        #return $true
    }
    catch {
        Write-Host "Failed in executing Query $($sqlQuery): `n" $_.Exception.Message -ForegroundColor Red
        throw
    }
    finally {
        $sqlCommand.Dispose()
    }
}

#Execute SQL Query for Bulk Upload
function Execute-BulkSqlQuery {
    Param(
        [Parameter(Mandatory = $true)] $sqlConnection,
        [Parameter(Mandatory = $true)] [string]$TableName, 
        [Parameter(Mandatory = $true)] $Data
    )
    try {
        $sqlCommand = New-Object System.Data.SQLClient.SQLCommand
        $sqlCommand.Connection = $sqlConnection
        $bulkCopy = new-object ("Data.SqlClient.SqlBulkCopy") $sqlConnection
        $bulkCopy.DestinationTableName = $TableName 
        $bulkCopy.BatchSize = 5000
        $bulkCopy.BulkCopyTimeout = 0
        $bulkCopy.WriteToServer($Data) 
    }
    catch {
        throw
    }
    finally {
        $sqlCommand.Dispose()
    }
}

#Fetch SharePoint Context
function Get-SPContext {
    Param(
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $source,                
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $userId,
        [Parameter(Mandatory = $true)] $securePassword
    )
    try {
        $context = $null
        #Context for Online sites
        if($source.ToLower().contains("sharepoint.com") -or $source.ToLower().contains("sites.ey.com")) {
            #$credentials = New-Object System.Management.Automation.PSCredential($userId,$securePassword)            
            #Connect-PnPOnline -Url $source -Credentials $credentials
            #$context = Get-PnPContext
            $context = New-Object Microsoft.SharePoint.Client.ClientContext($source)  
            $context.Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($userId,$securePassword)                        
            $context.add_ExecutingWebRequest({
                param($objSender, $eventArgs)
                $request = $eventArgs.WebRequestExecutor.WebRequest
                $request.UserAgent = "NONISV|Cognizant|CTSRemediation/1.0"
            })
        }
        else {
            #Context for OnPrem sites
            $context = New-Object Microsoft.SharePoint.Client.ClientContext($source)
            $context.Credentials = New-Object System.Net.NetworkCredential($userId, $securePassword)
            $context.add_ExecutingWebRequest({
                param($objSender, $eventArgs)
                $eventArgs.WebRequestExecutor.WebRequest.Headers.Add("X-FORMS_BASED_AUTH_ACCEPTED", "f")
            })
        }
        return $context
    }
    catch {
        Write-Host "Failed in executing Get-SPContext method: $($_.Exception.Message) `n"  -ForegroundColor Red
        throw
    }
}

#Fetch Credential details from Azure Keyvault
function Get-CredentialsFromKeyvault {
    Param(
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $azureAppId,                
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $azureTenantId,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $azureCertThumb,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $azureKeyvault,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $userId,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $userPassword
    )
    try {
        Connect-AzAccount -ServicePrincipal -ApplicationId $azureAppId -Tenant $azureTenantId -CertificateThumbprint $azureCertThumb
        $userIdResponse = (Get-AzKeyVaultSecret -vaultName $azureKeyvault -name $userId).SecretValueText.Trim()
        $userPwdResponse = (Get-AzKeyVaultSecret -vaultName $azureKeyvault -name $userPassword).SecretValueText.Trim()
        $formatResponse = @{
                                "LoginId" = $userIdResponse
                                "LoginPassword" = $userPwdResponse
                           }
        return $formatResponse
    }
    catch {
        Write-Host "Failed in fetching details from Azure Keyvault: $($_.Exception.Message) `n"  -ForegroundColor Red
        throw
    }
}


#Set Stored Procedure Dynamic Input parameter values for Exception logs
function ExceptionLogs-InputParameters {
    Param(
        [Parameter(Mandatory = $true)] $siteDetails,        
        [Parameter(Mandatory = $true)] $parameters,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $jobStep,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $process,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $exceptionMessage,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $exceptionStackTrace
    )
    try {
        $ipAddress = (Get-NetIPAddress -AddressFamily IPv4)[0].IPAddress
        $siteId = @($siteDetails.SiteID, $siteDetails.fk_Site)[$siteDetails.SiteID.Contains('-')]
        $parameters = foreach($item in $parameters.Item) {    
            Switch($item.Name) {
                "@fk_jobstep" { $item.Value = $jobStep ; break }
                "@operation" { $item.Value = $process + $ipAddress ; break }
                "@SiteId" { $item.Value = $siteId; break }
                "@BatchId" { $item.Value = $siteDetails.BatchID; break }                     
                "@source" { $item.Value = $siteDetails.OriginalURL; break }
                "@target" { $item.Value = $siteDetails.TargetURL; break }
                "@information" { $item.Value = $exceptionMessage; break }
                "@details" { $item.Value = $exceptionStackTrace; break }
            }
        }
    }
    catch {
        Write-Host $_.Exception.Message -ForegroundColor Red        
    }
}

#Set Stored Procedure Dynamic Input parameter values for Changing Status
function ChangeStatus-InputParameters {
    Param(
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $siteId,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $batchId,
        [Parameter(Mandatory = $true)] $parameters,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $jobStep,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $statusCode,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $strMessage        
    )
    try {        
        $parameters = foreach($item in $parameters.Item) {
            Switch($item.Name) {
                "@Status" { $item.Value = $statusCode; break }
                "@JobStep" { $item.Value = $jobStep; break }
                "@fk_Site" { $item.Value = $siteId; break }
                "@fk_Batch" { $item.Value = $batchId; break }                     
                "@MigDescription" { $item.Value = $strMessage; break }                
            }
        }
    }
    catch {
        Write-Host $_.Exception.Message -ForegroundColor Red
    }
}

#Port of the ExecuteQueryWithIncrementalRetry from the OfficeDev PnP
function ExecuteQueryWithIncrementalRetry($context, $retryCount, $delay) { 
    if ($retryCount -eq $null) { $retryCount = 5 } # default to 5
    if ($delay -eq $null) { $delay = 500 } # default to 500
    $retryAttempts = 0
    $backoffInterval = $delay
    if ($retryCount -le 0)
    {
        throw New-Object ArgumentException("Provide a retry count greater than zero.")
    }

    if ($delay -le 0)
    {
        throw New-Object ArgumentException("Provide a delay greater than zero.")
    }

    # Do while retry attempt is less than retry count
    while ($retryAttempts -lt $retryCount)
    {
        try
        {
            $context.ExecuteQuery()
            return
        }
        catch [System.Net.WebException]
        {
            $response = [System.Net.HttpWebResponse]$_.Exception.Response
            # Check if request was throttled - http status code 429
            # Check is request failed due to server unavailable - http status code 503
            if ($response -ne $null -and ($response.StatusCode -eq 429 -or $response.StatusCode -eq 503))
            {
                # Output status to console. Should be changed as Debug.WriteLine for production usage.
                Write-Host "CSOM request frequency exceeded usage limits. Sleeping for $backoffInterval seconds before retrying."

                # Add delay for retry
                Start-Sleep -m $backoffInterval

                # Add to retry count and increase delay.
                $retryAttempts++
                $backoffInterval = $backoffInterval * 2
            }
            else
            {
                throw
            }
        }
    }
    throw New-Object Exception("Maximum retry attempts $retryCount, has be attempted.")
}
