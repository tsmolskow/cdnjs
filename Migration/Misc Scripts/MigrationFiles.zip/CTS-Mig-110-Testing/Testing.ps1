﻿Get-Module | Remove-Module -Force
Clear-Host
#Load XML Config File
$scriptRoot = Split-Path $MyInvocation.MyCommand.Path -Parent
$parentRoot = (Get-Item $scriptRoot).Parent.FullName
$configfolder = Join-Path $parentRoot.ToLower().Replace('\cts\','\ey\') "CTS-Mig-0Settings"
$xmlConfigPath =  Join-Path $configfolder "ConfigurationSettings.xml"
$configXmlfile = [xml]$(Get-Content $xmlConfigPath)

#Fetching SQL Server Details
$sqlServerInstance = $configXmlfile.ConfigSettings.SqlSettings.SqlDbServer
$sqlDatabase = $configXmlfile.ConfigSettings.SqlSettings.SqlDatabase

#StoredProcedure - Testing
$sprocName = $configXmlfile.ConfigSettings.TestingSettings.StoredProcedure.Name
$sprocParameters = $configXmlfile.ConfigSettings.TestingSettings.StoredProcedure.Parameter

#StoredProcedure - Exception logging
$sprocExcepLogging = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ExceptionLogging.Name
$sprocExcepLogsInputParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ExceptionLogging.InputParameters
$sprocExcepLogsDynamicParameters = $configXmlfile.ConfigSettings.SqlSettings.StoredProcedures.ExceptionLogging.DynamicInputParameters

#Load Module files - Reusable methods, Apply Permissions
$modulesFolder = Join-Path $parentRoot $configXmlfile.ConfigSettings.CommonSettings.Modules.Name
$modulesPath = Join-Path $modulesFolder $configXmlfile.ConfigSettings.CommonSettings.Modules.Value
Import-Module -Name $modulesPath

#Fetch SQL and SharePoint Credentials from Azure KeyVault
$azureAccountsPsd = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.AzureAccountsPsd
$azureKeyvaultsPsd = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.AzureKeyvaultsPsd
Import-Module -Name $azureAccountsPsd
Import-Module -Name $azureKeyvaultsPsd

$azAppId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.ApplicationId
$azTenantId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.TenantId
$azCertificates = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.CertificateThumbprint
$azVault = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.VaultName
$azOrchDbUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.OrchestrationUserId
$azOrchDbPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.OrchestrationPassword
$azSourceIntranetUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceIntranetUserId
$azSourceIntranetPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceIntranetPassword
$azSourceExtranetUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceExtranetUserId
$azSourceExtranetPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.SourceExtranetPassword
$azTargetUserId = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.TargetUserId
$azTargetPassword = $configXmlfile.ConfigSettings.AzureKeyVaultSettings.TargetPassword

#Load ConsoleApp exe file for migrating WorkflowHistory List, QuickLaunch and Connected Lists/Library Items
$consoleAppExeFileContainer = Join-Path  $scriptRoot $configXmlfile.ConfigSettings.TestingSettings.ConsoleAppUtility.Folder
$consoleAppExeFile = $configXmlfile.ConfigSettings.TestingSettings.ConsoleAppUtility.Value
$consoleAppExeFilePath = Join-Path  $consoleAppExeFileContainer $consoleAppExeFile

#Execute Console application
function Execute-ConsoleAppUtilities {
    Param(
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $sqlServer,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $sqlDatabase,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $storedProcedureQuery,        
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $dboUserID,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $dboPassword,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $sourceIntranetUserId,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $sourceIntranetPassword,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $sourceExtranetUserId,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $sourceExtranetPassword,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $targetUserId,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String] $targetPassword
    )
    try {
        & $consoleAppExeFilePath $sqlServer $sqlDatabase $storedProcedureQuery $dboUserID $dboPassword $sourceIntranetUserId $sourceIntranetPassword $sourceExtranetUserId $sourceExtranetPassword $targetUserId $targetPassword                     
    }
    catch {
        Write-Host $_.Exception.Message -ForegroundColor Red        
    }
}

try {
    #Fetch SQL DB Credentials from Azure Keyvault
    $dbCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azOrchDbUserId $azOrchDbPassword    
    $secureDbPassword = $dbCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force
  
    #Fetch Source Sites Credentials from Azure keyvault
    $sourceCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azSourceIntranetUserId $azSourceIntranetPassword
    $sourceSecurePassword = $sourceCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force

    #Fetch Source Extranet Sites Credentials from Azure keyvault
    $sourceExtranetCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azSourceExtranetUserId $azSourceExtranetPassword     
    $sourceExtranetSecurePassword = $sourceExtranetCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force

    #Fetch Target Sites Credentials from Azure keyvault
    $targetCredentials = Get-CredentialsFromKeyvault $azAppId $azTenantId $azCertificates $azVault $azTargetUserId $azTargetPassword     
    $targetSecurePassword = $targetCredentials.LoginPassword | ConvertTo-SecureString -AsPlainText -Force

    Write-Host "------------------------------Testing process Starts------------------------------`n"

    try {
        $parameters = $sprocParameters | ForEach-Object { "$($_.Name)=$($_.Value)," }
        $strStrdProcQuery =  "EXEC $($sprocName) " + $parameters
        $strStrdProcQuery = $strStrdProcQuery.SubString(0,$strStrdProcQuery.Length-1)
        Execute-ConsoleAppUtilities $sqlServerInstance $sqlDatabase $strStrdProcQuery $dbCredentials.LoginId $dbCredentials.LoginPassword $sourceCredentials.LoginId $sourceCredentials.LoginPassword $sourceExtranetCredentials.LoginId $sourceExtranetCredentials.LoginPassword $targetCredentials.LoginId $targetCredentials.LoginPassword
    }
    catch {        
        Write-Host $_.Exception.Message -ForegroundColor Red        
    }
}
catch {
    Write-Host "Exception in fetching Azure Keyvault details `n" $_.Exception.Message -ForegroundColor Red
}

Write-Host "------------------------------Testing process Ends------------------------------"
