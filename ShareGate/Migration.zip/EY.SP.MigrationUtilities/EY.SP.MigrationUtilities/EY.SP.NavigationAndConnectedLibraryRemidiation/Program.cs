﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Configuration;


namespace AddQuickLaunchValues
{
    public class Program
    {

        public static void Main(string[] args)
        {
            Dictionary<string, string> AllMappingDetails = new Dictionary<string, string>();
            Credential credPrem = null;
            Credential credOnline = null;
            Console.WriteLine("Please enter below choice:");
            Console.WriteLine("Type 1 for running Utility on Set:");
            Console.WriteLine("Type 2 for running Utility on Waves:");
            string choice = Console.ReadLine();
            List<Migrate> allUrls = ReadCSV("input.csv");
            List<Migrate> CompleteURLs = ReadCSV("AllURL.csv");
            LogInfo("Choice " + choice + " is selected", " ", " ");

            foreach (Migrate item in CompleteURLs)
            {
                AllMappingDetails.Add(item.Source.ToLowerInvariant(), item.Destination.ToLowerInvariant());
            }
            if (choice == "1")
            {
                Console.WriteLine("Enter OnPrem Credential:");
                credPrem = GetCredential();
                Console.WriteLine();
            }
            Console.WriteLine("Enter Online Credential:");
            credOnline = GetCredential();
            Console.WriteLine();
            Console.WriteLine("Process started at " + DateTime.Now.ToString());
            LogInfo("Process started at " + DateTime.Now.ToString(), "", "");
            int count = 1;
            foreach (Migrate url in allUrls)
            {

                if (choice == "1")
                {
                    Console.WriteLine("Row: " + count + " Checking Source URL: " + url.Source);
                    GetQuickLaunchValue(url, credPrem, credOnline, AllMappingDetails);
                    ConnectedLibraryOperations(url, credPrem, credOnline, AllMappingDetails);
                }
                else
                {
                    Console.WriteLine("Row: " + count + " Checking Destination URL: " + url.Destination);
                    ReplaceQuickLaunchValue(url, credOnline, AllMappingDetails);
                    ReplaceConnectedLibraryLinks(url, credOnline, AllMappingDetails);
                }
                count++;

            }
            Console.WriteLine("");
            Console.WriteLine("Process completed at " + DateTime.Now.ToString());
            LogInfo("Process completed at " + DateTime.Now.ToString(), "", "");
            Console.WriteLine("Please click on any key to exit");
            Console.ReadLine();
        }

        private static void ReplaceConnectedLibraryLinks(Migrate url, Credential credOnline, Dictionary<string, string> CompleteURLs)
        {
            LogInfo("ReplaceConnectedLibraryLinks Started", url.Source, url.Destination);
            List<string> lstResult = new List<string>();
            string sourceSiteUrl = url.Source.TrimEnd('/').Trim();
            string destinationSiteUrl = url.Destination.TrimEnd('/').Trim();
            List<string> lstLibraries = new List<string>();
            lstLibraries.Add("Connected Libraries");
            lstLibraries.Add("Connected Lists");

            try
            {
                if (CompleteURLs != null && CompleteURLs.Count > 0)
                {

                    List<string> groupsChanged = new List<string>();

                    if (!string.IsNullOrEmpty(sourceSiteUrl))
                    {

                        #region Process Each Site

                        string status = string.Empty;
                        try
                        {
                            using (ClientContext clientContext = GetClientContext(destinationSiteUrl, credOnline, true))
                            {
                                clientContext.Load(clientContext.Web.Lists);
                                var lstcollection = clientContext.Web.Lists;

                                // Connected Libraries
                                foreach (string lst in lstLibraries)
                                {
                                    List currentLib = lstcollection.GetByTitle(lst);
                                    ListItemCollection currentLibItems = currentLib.GetItems(CamlQuery.CreateAllItemsQuery());
                                    clientContext.Load(currentLibItems, lists => lists.Include(i1 => i1["URL"]));
                                    clientContext.ExecuteQuery();
                                    foreach (ListItem currentItem in currentLibItems)
                                    {
                                        try
                                        {
                                            string newUrl = string.Empty;
                                            var currentItemUrl = ((FieldUrlValue)currentItem["URL"]).Url;
                                            var currentItemDesc = ((FieldUrlValue)currentItem["URL"]).Description;
                                            if (currentItemUrl.ToLowerInvariant().Contains(ConfigurationManager.AppSettings["SourceHost"]))
                                            {
                                                newUrl = CheckMigratedAndReplace(CompleteURLs, currentItemUrl, url.Destination, url.Source);
                                                if (!string.IsNullOrEmpty(newUrl) && !newUrl.ToLowerInvariant().Contains(ConfigurationManager.AppSettings["SourceHost"]))
                                                {
                                                    var updatedUrlField = new FieldUrlValue();
                                                    updatedUrlField.Url = newUrl;
                                                    updatedUrlField.Description = currentItemDesc;
                                                    currentItem["URL"] = updatedUrlField;
                                                    currentItem.Update();
                                                    clientContext.ExecuteQuery();
                                                    LogReplacedSites(url.Source, url.Destination, currentItemUrl, newUrl);

                                                }
                                            }

                                        }
                                        catch (Exception ex)
                                        {
                                            LogInfo("ReplaceConnectedLibraryLinks Exception: " + ex.Message, url.Source, url.Destination);

                                        }
                                    }


                                }

                            }
                        }
                        catch (Exception ex)
                        {
                            LogInfo("ReplaceConnectedLibraryLinks Exception: " + ex.Message, url.Source, url.Destination);

                        }

                        #endregion
                    }

                }
                LogInfo("ReplaceConnectedLibraryLinks Completed", url.Source, url.Destination);

            }
            catch (Exception exc)
            {
                LogInfo("ConnectedLibraryOperations Exception: " + exc.Message, url.Source, url.Destination);
            }
        }

        private static void ConnectedLibraryOperations(Migrate url, Credential credPrem, Credential credOnline, Dictionary<string, string> CompleteURLs)
        {
            LogInfo("ConnectedLibraryOperations Started", url.Source, url.Destination);
            List<string> lstResult = new List<string>();
            string sourceSiteUrl = url.Source.TrimEnd('/').Trim();
            string destinationSiteUrl = url.Destination.TrimEnd('/').Trim();
            List<string> lstLibraries = new List<string>();
            lstLibraries.Add("Connected Libraries");
            lstLibraries.Add("Connected Lists");

            try
            {
                if (CompleteURLs != null && CompleteURLs.Count > 0)
                {

                    List<string> groupsChanged = new List<string>();

                    if (!string.IsNullOrEmpty(sourceSiteUrl))
                    {

                        #region Process Each Site

                        string status = string.Empty;
                        try
                        {
                            foreach (string lst in lstLibraries)
                            {
                                using (ClientContext clientContext = GetClientContext(sourceSiteUrl, credPrem, false))
                                {
                                    clientContext.Load(clientContext.Web.Lists);
                                    var lstcollection = clientContext.Web.Lists;

                                    // Connected Libraries

                                    List currentLib = lstcollection.GetByTitle(lst);
                                    ListItemCollection currentLibItems = currentLib.GetItems(CamlQuery.CreateAllItemsQuery());
                                    clientContext.Load(currentLibItems, lists => lists.Include(i1 => i1["URL"]));
                                    clientContext.ExecuteQuery();
                                    foreach (ListItem currentItem in currentLibItems)
                                    {
                                        try
                                        {
                                            string newUrl = string.Empty;
                                            var currentItemUrl = ((FieldUrlValue)currentItem["URL"]).Url;
                                            var currentItemDesc = ((FieldUrlValue)currentItem["URL"]).Description;
                                            if (sourceSiteUrl.ToLowerInvariant() != GetSiteURL(currentItemUrl).ToLowerInvariant())
                                            {
                                                newUrl = CheckMigratedAndReplace(CompleteURLs, currentItemUrl, url.Destination, url.Source);
                                                if (!string.IsNullOrEmpty(newUrl))
                                                {
                                                    var newUrlField = new FieldUrlValue();
                                                    newUrlField.Url = newUrl;
                                                    newUrlField.Description = currentItemDesc;
                                                    using (ClientContext onlineContext = GetClientContext(destinationSiteUrl, credOnline, true))
                                                    {
                                                        List currentList = onlineContext.Web.Lists.GetByTitle(lst);
                                                        ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();
                                                        ListItem newItem = currentList.AddItem(itemCreateInfo);
                                                        newItem["URL"] = newUrlField;
                                                        newItem.Update();
                                                        onlineContext.ExecuteQuery();
                                                        LogReplacedSites(url.Source, url.Destination, currentItemUrl, newUrl);
                                                    }
                                                }
                                            }

                                        }
                                        catch (Exception ex)
                                        {
                                            LogInfo("ConnectedLibraryOperations Exception: " + ex.Message, url.Source, url.Destination);

                                        }
                                    }


                                }

                            }
                        }
                        catch (Exception ex)
                        {
                            LogInfo("ConnectedLibraryOperations Exception: " + ex.Message, url.Source, url.Destination);

                        }

                        #endregion
                    }

                }
                LogInfo("ConnectedLibraryOperations Completed", url.Source, url.Destination);

            }
            catch (Exception exc)
            {
                LogInfo("ConnectedLibraryOperations Exception: " + exc.Message, url.Source, url.Destination);
            }
        }

        #region QuickLaunch

        public static void GetQuickLaunchValue(Migrate url, Credential credPrem, Credential credOnline, Dictionary<string, string> CompleteURLs)
        {
            try
            {
                LogInfo("GetQuickLaunchValue Started", url.Source, url.Destination);
                ClientContext ctxPrem = GetClientContext(url.Source, credPrem, false);
                ClientContext ctxOnline = GetClientContext(url.Destination, credOnline, true);
                NavigationNodeCollection qlNodesDestination = ctxOnline.Web.Navigation.QuickLaunch;
                ctxOnline.Load(qlNodesDestination);
                ctxOnline.ExecuteQuery();
                NavigationNodeCollection qlNodesSource = ctxPrem.Web.Navigation.QuickLaunch;
                ctxPrem.Load(qlNodesSource);
                ctxPrem.ExecuteQuery();
                AddMissingLink(url, ctxPrem, ctxOnline, qlNodesSource, qlNodesDestination, CompleteURLs);
                LogInfo("GetQuickLaunchValue Ended", url.Source, url.Destination);

            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception occured in Method: GetQuickLaunchValue, Message: " + ex.Message);
                LogInfo("GetQuickLaunchValue Exception: " + ex.Message, url.Source, url.Destination);

            }
        }


        public static void AddMissingLink(Migrate url, ClientContext ctxPrem, ClientContext ctxOnline, NavigationNodeCollection qlNodesSource, NavigationNodeCollection qlNodesDestination, Dictionary<string, string> CompleteURLs)
        {
            string prvNode = "";
            string nodeNow = "";
            try
            {
                LogInfo("AddMissingLink Started", url.Source, url.Destination);
                List<string> SkipTitle = new List<string>() { "---------------------------", "Calendar", "Contacts", "Recent", "Recycle Bin", "Engagement Tools", "Manage Access", "Engagement Tasks", "Help", "Global Tools", "Engagement Locator", "EYI My Documents Home" };
                foreach (NavigationNode sourceNode in qlNodesSource)
                {

                    nodeNow = sourceNode.Title;
                    #region For Each Source Node
                    try
                    {
                        if (!SkipTitle.Contains(sourceNode.Title))
                        {
                            bool flag = false;
                            bool flagForChild = false;
                            NavigationNodeCreationInformation newNavNode = new NavigationNodeCreationInformation();
                            ctxPrem.Load(sourceNode.Children);
                            ctxPrem.ExecuteQuery();
                            foreach (NavigationNode destNode in qlNodesDestination)
                            {
                                try
                                {
                                    if (!SkipTitle.Contains(destNode.Title))
                                    {
                                        ctxOnline.Load(destNode.Children);
                                        ctxOnline.ExecuteQuery();
                                        if (sourceNode.Title == destNode.Title)
                                        {
                                            flag = true;
                                            foreach (NavigationNode itemsourceNode in sourceNode.Children)
                                            {
                                                flagForChild = false;
                                                NavigationNodeCreationInformation newChildNavNode = new NavigationNodeCreationInformation();
                                                foreach (NavigationNode itemDestNode in destNode.Children)
                                                {
                                                    if (itemDestNode.Title == itemsourceNode.Title)
                                                    {
                                                        flagForChild = true;
                                                        break;
                                                    }

                                                }
                                                if (flagForChild == false)
                                                {
                                                    //Check if link is migrated or not.
                                                    //If Yes then get the migrated EWS URL and replcae in link
                                                    string newUrl = CheckMigratedAndReplace(CompleteURLs, itemsourceNode.Url, url.Destination, url.Source);
                                                    newChildNavNode.Title = itemsourceNode.Title;
                                                    newChildNavNode.Url = newUrl;
                                                    newChildNavNode.AsLastNode = true;
                                                    destNode.Children.Add(newChildNavNode);
                                                    destNode.Update();
                                                    ctxOnline.ExecuteQuery();
                                                    LogReplacedSites(url.Source, url.Destination, itemsourceNode.Url, newUrl);

                                                }
                                            }
                                        }
                                        foreach (NavigationNode itemDestNode in destNode.Children)
                                        {
                                            if (itemDestNode.Title == sourceNode.Title)
                                            {
                                                flag = true;
                                                break;
                                            }


                                        }

                                    }
                                }
                                catch (Exception ex)
                                {
                                    LogInfo("AddMissingLink Exception: " + ex.Message, "", "");
                                }
                            }

                            if (flag == false)
                            {
                                string newUrl = string.Empty;

                                if (!String.IsNullOrEmpty(prvNode))
                                {

                                    newUrl = CheckMigratedAndReplace(CompleteURLs, sourceNode.Url, url.Destination, url.Source);
                                    newNavNode.PreviousNode = qlNodesDestination.Where(Node => Node.Title == prvNode).FirstOrDefault();
                                    newNavNode.Title = sourceNode.Title;
                                    newNavNode.Url = newUrl;
                                    qlNodesDestination.Add(newNavNode);
                                    ctxOnline.Load(qlNodesDestination);
                                    ctxOnline.ExecuteQuery();
                                    LogReplacedSites(url.Source, url.Destination, sourceNode.Url, newUrl);


                                }
                                else
                                {

                                    newUrl = CheckMigratedAndReplace(CompleteURLs, sourceNode.Url, url.Destination, url.Source);
                                    newNavNode.Title = sourceNode.Title;
                                    newNavNode.Url = newUrl;
                                    qlNodesDestination.Add(newNavNode);
                                    ctxOnline.Load(qlNodesDestination);
                                    ctxOnline.ExecuteQuery();
                                    LogReplacedSites(url.Source, url.Destination, sourceNode.Url, newUrl);


                                }




                            }


                        }
                    }
                    catch (Exception ex)
                    {
                        LogInfo("AddMissingLink Exception: " + ex.Message, "", "");
                    }
                    #endregion
                    prvNode = nodeNow;

                }
                LogInfo("AddMissingLink Ended", url.Source, url.Destination);
            }
            catch (Exception ex)
            {
                LogInfo("AddMissingLink Exception: " + ex.Message, "", "");
            }

        }

        private static void ReplaceQuickLaunchValue(Migrate url, Credential credOnline, Dictionary<string, string> CompleteURLs)
        {
            try
            {
                LogInfo("ReplaceQuickLaunchValue Started", url.Source, url.Destination);
                ClientContext ctxOnline = GetClientContext(url.Destination, credOnline, true);
                NavigationNodeCollection qlNodesDestination = ctxOnline.Web.Navigation.QuickLaunch;
                ctxOnline.Load(qlNodesDestination);
                ctxOnline.ExecuteQuery();

                int count = 0;
                List<string> SkipTitle = new List<string>() { "---------------------------", "Calendar", "Contacts", "Recent", "Recycle Bin", "Engagement Tools", "Manage Access", "Engagement Tasks", "Help", "Global Tools", "Engagement Locator", "EYI My Documents Home" };
                foreach (NavigationNode destNode in qlNodesDestination)
                {
                    try
                    {
                        if (!SkipTitle.Contains(destNode.Title))
                        {
                            ctxOnline.Load(destNode.Children);
                            ctxOnline.ExecuteQuery();
                            foreach (NavigationNode itemDestNode in destNode.Children)
                            {

                                if (itemDestNode.Url.ToLowerInvariant().Contains(ConfigurationManager.AppSettings["SourceHost"]))
                                {
                                    string newUrl = CheckMigratedAndReplace(CompleteURLs, itemDestNode.Url, url.Destination, url.Source);
                                    itemDestNode.Url = newUrl;
                                    itemDestNode.Update();
                                    ctxOnline.ExecuteQuery();
                                    LogReplacedSites(url.Source, url.Destination, itemDestNode.Url, newUrl);
                                }
                            }

                            if (destNode.Url.ToLowerInvariant().Contains(ConfigurationManager.AppSettings["SourceHost"]))
                            {
                                string newUrl = CheckMigratedAndReplace(CompleteURLs, destNode.Url, url.Destination, url.Source);
                                destNode.Url = newUrl;
                                destNode.Update();
                                ctxOnline.ExecuteQuery();
                                LogReplacedSites(url.Source, url.Destination, destNode.Url, newUrl);

                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        LogInfo("ReplaceQuickLaunchValue Exception: " + ex.Message, url.Source, url.Destination);

                    }


                }

                LogInfo("ReplaceQuickLaunchValue Ended", url.Source, url.Destination);


                count++;
            }
            catch (Exception ex)
            {
                LogInfo("ReplaceQuickLaunchValue Exception: " + ex.Message, url.Source, url.Destination);


            }
        }

        #endregion

        #region Connected Libraries

        public static void ConnectedLibraryOperations(Migrate url, Credential credOnline, Dictionary<string, string> CompleteURLs)
        {
            LogInfo("ConnectedLibraryOperations Started", url.Source, url.Destination);
            List<string> lstResult = new List<string>();
            string siteUrl = url.Destination.TrimEnd('/').Trim();
            List<string> lstLibraries = new List<string>();
            lstLibraries.Add("Connected Libraries");
            lstLibraries.Add("Connected Lists");

            try
            {
                if (CompleteURLs != null && CompleteURLs.Count > 0)
                {

                    List<string> groupsChanged = new List<string>();

                    if (!string.IsNullOrEmpty(siteUrl))
                    {

                        #region Process Each Site

                        string status = string.Empty;
                        try
                        {
                            using (ClientContext clientContext = GetClientContext(siteUrl, credOnline, true))
                            {
                                clientContext.Load(clientContext.Web.Lists);
                                clientContext.ExecuteQuery();
                                var lstcollection = clientContext.Web.Lists;

                                // Connected Libraries
                                foreach (string lst in lstLibraries)
                                {
                                    List currentLib = lstcollection.GetByTitle(lst);
                                    ListItemCollection currentLibItems = currentLib.GetItems(CamlQuery.CreateAllItemsQuery());
                                    clientContext.Load(currentLibItems, lists => lists.Include(i1 => i1["URL"], i2 => i2["Title"], i2 => i2["Id"]));
                                    clientContext.ExecuteQuery();

                                    Dictionary<string, string> trackForDuplicates = new Dictionary<string, string>();
                                    Dictionary<string, int> trackForDuplicateDescription = new Dictionary<string, int>();
                                    List<int> lstDuplicatesTobeDeleted = new List<int>();

                                    foreach (ListItem currentItem in currentLibItems)
                                    {
                                        try
                                        {
                                            string newUrl = string.Empty;
                                            var currentItemUrl = ((FieldUrlValue)currentItem["URL"]).Url;
                                            var currentItemDesc = ((FieldUrlValue)currentItem["URL"]).Description;
                                            if (!currentItemUrl.ToLowerInvariant().Contains(ConfigurationManager.AppSettings["DestinationHost"]))
                                            {
                                                newUrl = CheckMigratedAndReplace(CompleteURLs, currentItemUrl, url.Destination, url.Source);

                                                // Replace the old urls with new SPO urls if applicable
                                                if (!string.IsNullOrEmpty(newUrl))
                                                {
                                                    var updatedUrlField = new FieldUrlValue();
                                                    updatedUrlField.Url = newUrl;
                                                    updatedUrlField.Description = currentItemDesc;
                                                    currentItem["URL"] = updatedUrlField;

                                                    currentItem.Update();
                                                    clientContext.ExecuteQuery();
                                                    LogReplacedSites(url.Source, url.Destination, currentItemUrl, newUrl);
                                                }
                                            }
                                            currentItemUrl = HttpUtility.UrlDecode(currentItemUrl);

                                            if (!trackForDuplicates.Keys.Contains(currentItemUrl))
                                            {
                                                if (trackForDuplicates.Values.Contains(currentItemDesc.Trim()))
                                                {
                                                    trackForDuplicateDescription.Add(currentItemUrl, currentItem.Id);
                                                    LogInfo("EDL issue item will be Deleted with Title: " + currentItemDesc.Trim() + " and URL: " + currentItemUrl, url.Source, url.Destination);
                                                }
                                                trackForDuplicates.Add(currentItemUrl, currentItemDesc.Trim());
                                            }
                                            else
                                            {
                                                //delete item
                                                lstDuplicatesTobeDeleted.Add(currentItem.Id);
                                                LogInfo("Duplicate item will be Deleted with Title: " + currentItemDesc + " and URL: " + currentItemUrl, url.Source, url.Destination);

                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            LogInfo("ConnectedLibraryOperations Exception: " + ex.Message, url.Source, url.Destination);

                                        }
                                    }

                                    //Delete the duplicate items created due to content migration
                                    if (lstDuplicatesTobeDeleted.Count > 0)
                                    {
                                        try
                                        {

                                            foreach (int itemId in lstDuplicatesTobeDeleted)
                                            {
                                                ListItem itemDupTobeDeleted = currentLib.GetItemById(itemId);
                                                itemDupTobeDeleted.DeleteObject();
                                                clientContext.ExecuteQuery();


                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            LogInfo("ConnectedLibraryOperations Exception: " + ex.Message, url.Source, url.Destination);

                                        }
                                    }

                                    //Check and Delete if Duplicate Description found
                                    if (trackForDuplicateDescription.Count() > 0)
                                    {
                                        foreach (var item in trackForDuplicateDescription)
                                        {
                                            try
                                            {
                                                if (!CheckIfLibraryExists(item.Key, credOnline))
                                                {
                                                    ListItem itemDupTobeDeleted = currentLib.GetItemById(item.Value);
                                                    itemDupTobeDeleted.DeleteObject();
                                                    clientContext.ExecuteQuery();
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                LogInfo("ConnectedLibraryOperations Exception: " + ex.Message, url.Source, url.Destination);

                                            }
                                        }

                                    }
                                }

                            }
                        }
                        catch (Exception ex)
                        {
                            LogInfo("ConnectedLibraryOperations Exception: " + ex.Message, url.Source, url.Destination);

                        }

                        #endregion
                    }

                }
                LogInfo("ConnectedLibraryOperations Completed", url.Source, url.Destination);

            }
            catch (Exception exc)
            {
                LogInfo("ConnectedLibraryOperations Exception: " + exc.Message, url.Source, url.Destination);
            }

        }

        private static bool CheckIfLibraryExists(string url, Credential credOnline)
        {
            bool isExist = false;
            string currentItemSiteUrl = url.Substring(0, (url.LastIndexOf('/')));
            string libName = url.Substring(url.LastIndexOf('/')).TrimStart('/');
            try
            {

                using (ClientContext clientContext = GetClientContext(currentItemSiteUrl, credOnline, true))
                {
                    List EDL = clientContext.Web.Lists.GetByTitle(libName);
                    clientContext.Load(EDL);
                    clientContext.ExecuteQuery();
                    isExist = true;
                }

            }
            catch (Exception)
            {
                try
                {
                    using (ClientContext clientContext = GetClientContext(currentItemSiteUrl, credOnline, true))
                    {
                        List EDL = clientContext.Web.GetList(url);
                        clientContext.Load(EDL);
                        clientContext.ExecuteQuery();
                        isExist = true;
                    }

                }
                catch (Exception)
                {

                }
            }
            return isExist;


        }
        #endregion

        #region Common


        /// <summary>
        /// Gets EWS link only from URL, no need of getting CWS as the CWS sussite URL will alwasy be same
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        private static string GetSiteURL(string url)
        {
            string siteURL = string.Empty;
            string[] TargetDetails = url.Split('/');
            for (int i = 0; i < 5; i++)
            {
                siteURL += TargetDetails[i] + '/';
            }
            siteURL = siteURL.TrimEnd('/');

            return siteURL;
        }

        private static string CheckMigratedAndReplace(Dictionary<string, string> completeURLs, string URLToReplace, string destinationURL, string source)
        {
            string newURL = string.Empty;
            if (!string.IsNullOrEmpty(URLToReplace))
            {
                if (URLToReplace.StartsWith("/Sites/"))
                {
                    string guidSource = URLToReplace.Split('/')[2];
                    string guidbDestination = destinationURL.Split('/')[4];
                    newURL = URLToReplace.Replace(guidSource, guidbDestination);
                }
                else
                {
                    string sourceURL = GetSiteURL(URLToReplace);
                    if (completeURLs.ContainsKey(sourceURL.ToLowerInvariant()))
                    {
                        newURL = completeURLs[sourceURL.ToLowerInvariant()].ToString();
                        newURL = URLToReplace.Replace(sourceURL, newURL);
                    }
                    else
                    {
                        newURL = URLToReplace;
                        WriteOnPremSites(source, destinationURL);
                    }
                }
            }
            return newURL;
        }

        public static void WriteOnPremSites(string sourceURL, string destinationURL)
        {

            try
            {
                string exepath = System.Reflection.Assembly.GetExecutingAssembly().Location;
                string exedir = System.IO.Path.GetDirectoryName(exepath);
                if (!System.IO.Directory.Exists(exedir + "\\OnPremSites" + DateTime.Today.ToString("yyyyMMdd")))
                {
                    System.IO.Directory.CreateDirectory(exedir + "\\OnPremSites" + DateTime.Today.ToString("yyyyMMdd"));
                }

                exedir = exedir + "\\OnPremSites" + DateTime.Today.ToString("yyyyMMdd") + "\\";

                string filePath = exedir + "OnPremSiteURL.csv";
                if (!System.IO.File.Exists(filePath))
                {
                    System.IO.File.Create(filePath).Close();
                    System.IO.File.AppendAllText(filePath, "OnPremUrl," + "OnlineURL" + Environment.NewLine);
                }
                StringBuilder sb = new StringBuilder();

                sb.AppendLine(sourceURL + "," + destinationURL);

                System.IO.File.AppendAllText(filePath, sb.ToString());
            }
            catch (Exception ex)
            {

            }
        }

        public static void LogReplacedSites(string sourceURL, string destinationURL, string oldURL, string newURL)
        {
            //common funtion which is used to write the output in to CSV file.
            //string filePath = "c:\\" +  FileName;

            try
            {
                string exepath = System.Reflection.Assembly.GetExecutingAssembly().Location;
                string exedir = System.IO.Path.GetDirectoryName(exepath);
                if (!System.IO.Directory.Exists(exedir + "\\LogReplacedSites" + DateTime.Today.ToString("yyyyMMdd")))
                {
                    System.IO.Directory.CreateDirectory(exedir + "\\LogReplacedSites" + DateTime.Today.ToString("yyyyMMdd"));
                }

                exedir = exedir + "\\LogReplacedSites" + DateTime.Today.ToString("yyyyMMdd") + "\\";

                string filePath = exedir + "LogReplacedSites.csv";
                if (!System.IO.File.Exists(filePath))
                {
                    System.IO.File.Create(filePath).Close();
                    System.IO.File.AppendAllText(filePath, "OnPremUrl," + "OnlineURL," + "Old URL," + "New URL" + Environment.NewLine);
                }
                StringBuilder sb = new StringBuilder();

                sb.AppendLine(sourceURL + "," + destinationURL + "," + oldURL + "," + newURL);
                System.IO.File.AppendAllText(filePath, sb.ToString());
            }
            catch (Exception ex)
            {

            }
        }

        public static void LogInfo(string content, string sourceURL, string destinationURL)
        {
            try
            {
                string exepath = System.Reflection.Assembly.GetExecutingAssembly().Location;
                string exedir = System.IO.Path.GetDirectoryName(exepath);
                if (!System.IO.Directory.Exists(exedir + "\\Log" + DateTime.Today.ToString("yyyyMMdd")))
                {
                    System.IO.Directory.CreateDirectory(exedir + "\\Log" + DateTime.Today.ToString("yyyyMMdd"));
                }

                exedir = exedir + "\\Log" + DateTime.Today.ToString("yyyyMMdd") + "\\";

                string filePath = exedir + "LogInfo.csv";
                if (!System.IO.File.Exists(filePath))
                {
                    System.IO.File.Create(filePath).Close();
                    System.IO.File.AppendAllText(filePath, "Content," + "OnPremUrl," + "OnlineUrl," + "Time," + "LoggedInUserID" + Environment.NewLine);
                }
                StringBuilder sb = new StringBuilder();

                string combine = content + "," + sourceURL + "," + destinationURL;
                string currentUserID = ",Time: " + DateTime.Now + ",LoggedIn UserId: " + System.Environment.UserDomainName + "\\" + System.Environment.UserName + ",IP Address: " + GetclientIP();
                sb.AppendLine(combine + currentUserID);
                System.IO.File.AppendAllText(filePath, sb.ToString());
            }
            catch (Exception ex)
            {

            }
        }

        public static string GetclientIP()
        {
            string result = string.Empty;
            string hostName = Dns.GetHostName(); // Retrive the Name of HOST  
            result = Dns.GetHostAddresses(hostName)[1].ToString();
            return result;
        }

        public static ClientContext GetClientContext(string siteURL, Credential cred, bool isSPO = false)
        {
            try
            {
                if (siteURL.Trim().EndsWith("/"))
                {
                    siteURL.TrimEnd('/');
                }
                ClientContext ctx = new ClientContext(siteURL);
                if (!isSPO)
                {

                    System.Net.NetworkCredential SrcCredential = new System.Net.NetworkCredential(cred.UserId, cred.Password);
                    ctx.Credentials = SrcCredential;
                    ctx.ExecutingWebRequest += new EventHandler<WebRequestEventArgs>(context_ExecutingWebRequest);
                }
                else
                {
                    ctx.Credentials = new SharePointOnlineCredentials(cred.UserId, cred.Password);
                }
                return ctx;
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        public static void context_ExecutingWebRequest(object sender, WebRequestEventArgs e)
        {
            HttpWebRequest webReq = e.WebRequestExecutor.WebRequest;
            webReq.Headers.Add("X-FORMS_BASED_AUTH_ACCEPTED", "f");
        }
        public static List<Migrate> ReadCSV(string fileName)
        {
            try
            {
                Console.WriteLine(fileName + " is loading...");
                List<Migrate> migrateSiteUrls = new List<Migrate>();
                using (var reader = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + "/" + fileName))
                {
                    int i = 0;
                    while (!reader.EndOfStream)
                    {
                        var url = reader.ReadLine();
                        if (i > 0)
                        {
                            var splitInput = url.Split(',');
                            if (splitInput.Length > 2)
                            {

                                migrateSiteUrls.Add(new Migrate()
                                {
                                    Source = splitInput[0].Trim(),
                                    Destination = splitInput[splitInput.Length - 1].Trim()

                                });
                            }
                            else
                            {
                                migrateSiteUrls.Add(new Migrate()
                                {
                                    Source = splitInput[0].Trim(),
                                    Destination = splitInput[1].Trim()

                                });
                            }
                        }
                        i++;
                    }
                }
                Console.WriteLine("CSV loaded successfully...");
                return migrateSiteUrls;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception occured in Method: ReadCSV, Message: " + ex.Message);
                return null;
            }
        }
        public static Credential GetCredential()
        {
            Credential cred = new Credential();
            Console.WriteLine("Enter User ID: ");
            string userId = Console.ReadLine();
            SecureString password = new SecureString();
            Console.WriteLine("Enter password: ");

            ConsoleKeyInfo nextKey = Console.ReadKey(true);

            while (nextKey.Key != ConsoleKey.Enter)
            {
                if (nextKey.Key == ConsoleKey.Backspace)
                {
                    if (password.Length > 0)
                    {
                        password.RemoveAt(password.Length - 1);
                        Console.Write(nextKey.KeyChar);
                        Console.Write(" ");
                        Console.Write(nextKey.KeyChar);
                    }
                }
                else
                {
                    password.AppendChar(nextKey.KeyChar);
                    Console.Write("*");
                }
                nextKey = Console.ReadKey(true);
            }
            password.MakeReadOnly();
            cred.UserId = userId;
            cred.Password = password;
            return cred;
        }

        #endregion
    }


    public class Migrate
    {
        public string Source { get; set; }
        public string Destination { get; set; }


    }

    public class Credential
    {
        public string UserId { get; set; }
        public SecureString Password { get; set; }


    }
}
