﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace EY.SP.MigrateWorkflowHistoryItems
{
    class Program
    {
        public static void Main(string[] args)
        {
            try
            {
                Credential credPrem = null;
                Credential credOnline = null;
                List<Migrate> allUrls = ReadCSV();
                Console.WriteLine("Workflow History Items migration Utility..");

                Console.WriteLine("Enter OnPrem Credential:");
                credPrem = GetCredential();
                Console.WriteLine();
                Console.WriteLine("Enter Online Credential:");
                credOnline = GetCredential();
                Console.WriteLine();
                int i = 1;
                foreach (Migrate url in allUrls)
                {
                    Console.WriteLine("Row Count: " + i);

                    MigrateHistoryItems(url.Source, credPrem, url.Destination, credOnline);

                    i++;

                }
                Console.WriteLine("Workflow History Items Moved Successfully, Please Check logs to verify");
                WriteToLog("Execution Completed Successfully");
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception occured in Method: Main, Message: " + ex.Message);
                WriteToLog("Exception occured in Method: Main, Message: " + ex.Message);
            }
        }

        private static void MigrateHistoryItems(string source, Credential credPrem, string destination, Credential credOnline)
        {

            ClientContext ctxprm = GetClientContext(source, credPrem);
            Web srcweb = ctxprm.Web;
            ctxprm.Load(srcweb);
            ctxprm.ExecuteQuery();
            List sourceList = ctxprm.Web.Lists.GetByTitle("EDLWorkflowHistory");
            ctxprm.Load(sourceList);
            ctxprm.ExecuteQuery();

            ClientContext ctxtrg = GetClientContext(destination, credOnline);
            Web trgweb = ctxtrg.Web;
            ctxtrg.Load(trgweb);
            List destList = ctxtrg.Web.Lists.GetByTitle("EDLWorkflowHistory");
            ctxtrg.Load(destList);
            ctxtrg.ExecuteQuery();
            CamlQuery camlQuery = new CamlQuery();
            camlQuery.ViewXml = "<View/>";
            ListItemCollection listItems = sourceList.GetItems(camlQuery);
            ctxprm.Load(listItems);
            ctxprm.ExecuteQuery();
            string gudold = "";
            string gudNew = "";
            Guid gudtrg = Guid.Empty;

            foreach (ListItem item in listItems)
            {
                ListItemCreationInformation newItemInfo = new ListItemCreationInformation();
                ListItem newItem = destList.AddItem(newItemInfo);

                try
                {
                    FieldUserValue userValue = (FieldUserValue)item["User"];
                    User user = ctxprm.Web.GetUserById(userValue.LookupId);
                    ctxprm.Load(user, x => x.Email);
                    ctxprm.ExecuteQuery();
                    string userEmail = user.Email;
                    User trguser = ctxtrg.Web.EnsureUser(userEmail);
                    ctxtrg.Load(trguser);


                    gudold = item["List"].ToString();
                    if (gudold != gudNew)
                    {
                        List srcWFlist = ctxprm.Web.Lists.GetById(Guid.Parse(gudold));
                        ctxprm.Load(srcWFlist);
                        ctxprm.ExecuteQuery();

                        String srcttl = srcWFlist.Title;
                        List trgWFlist = ctxtrg.Web.Lists.GetByTitle(srcttl);
                        ctxtrg.Load(trgWFlist);
                        ctxtrg.ExecuteQuery();

                        gudtrg = trgWFlist.Id;
                        newItem["List"] = string.Concat("{" + gudtrg + "}");
                        gudNew = gudold;

                    }
                    else
                    {
                        newItem["List"] = string.Concat("{" + gudtrg + "}");
                        gudNew = gudold;
                    }

                    newItem["User"] = trguser;


                }
                catch (Exception)
                {
                    gudold = item["List"].ToString();

                    List srcWFlist = ctxprm.Web.Lists.GetById(Guid.Parse(gudold));
                    ctxprm.Load(srcWFlist);
                    ctxprm.ExecuteQuery();

                    String srcttl = srcWFlist.Title;
                    List trgWFlist = ctxtrg.Web.Lists.GetByTitle(srcttl);
                    ctxtrg.Load(trgWFlist);
                    ctxtrg.ExecuteQuery();

                    gudtrg = trgWFlist.Id;
                    newItem["List"] = string.Concat("{" + gudtrg + "}");
                    newItem["User"] = item["User"];
                }


                newItem["WorkflowInstance"] = item["WorkflowInstance"];
                newItem["WorkflowAssociation"] = item["WorkflowAssociation"];
                newItem["WorkflowTemplate"] = item["WorkflowTemplate"];
                newItem["Item"] = item["Item"];
                newItem["Occurred"] = item["Occurred"];
                newItem["Event"] = item["Event"];
                newItem["Group"] = item["Group"];
                newItem["Outcome"] = item["Outcome"];
                newItem["Duration"] = item["Duration"];
                newItem["Description"] = item["Description"];
                newItem["Data"] = item["Data"];

                newItem.Update();
            }
            ctxtrg.ExecuteQuery();


        }

        public static List<Migrate> ReadCSV()
        {
            try
            {
                Console.WriteLine("CSV loading...");
                List<Migrate> migrateSiteUrls = new List<Migrate>();
                using (var reader = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + "/input.csv"))
                {
                    int i = 0;
                    while (!reader.EndOfStream)
                    {
                        var url = reader.ReadLine();
                        if (i > 0)
                        {
                            var splitInput = url.Split(',');

                            migrateSiteUrls.Add(new Migrate()
                            {
                                Source = splitInput[0].Trim(),

                                Destination = splitInput[1].Trim()

                            });

                        }
                        i++;
                    }
                }
                Console.WriteLine("CSV loaded successfully...");
                return migrateSiteUrls;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception occured in Method: ReadCSV, Message: " + ex.Message);
                WriteToLog("Exception occured in Method: ReadCSV, Message: " + ex.Message);
                return null;
            }
        }


        public static ClientContext GetClientContext(string siteURL, Credential cred)
        {
            try
            {
                bool isSPO = false;
                if (siteURL.Trim().EndsWith("/"))
                {
                    siteURL.TrimEnd('/');
                }
                if (siteURL.Contains("sharepoint.com"))
                {
                    isSPO = true;
                }
                ClientContext ctx = new ClientContext(siteURL);
                if (!isSPO)
                {


                    System.Net.NetworkCredential SrcCredential = new System.Net.NetworkCredential(cred.UserId, cred.Password);
                    ctx.Credentials = SrcCredential;
                    ctx.ExecutingWebRequest += new EventHandler<WebRequestEventArgs>(context_ExecutingWebRequest);
                }
                else
                {

                    ctx.Credentials = new SharePointOnlineCredentials(cred.UserId, cred.Password);
                }
                return ctx;
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        public static void context_ExecutingWebRequest(object sender, WebRequestEventArgs e)
        {
            HttpWebRequest webReq = e.WebRequestExecutor.WebRequest;

            webReq.Headers.Add("X-FORMS_BASED_AUTH_ACCEPTED", "f");
        }

        public static Credential GetCredential()
        {
            Credential cred = new Credential();
            Console.WriteLine("Enter User ID: ");
            string userId = Console.ReadLine();
            SecureString password = new SecureString();
            Console.WriteLine("Enter password: ");

            ConsoleKeyInfo nextKey = Console.ReadKey(true);

            while (nextKey.Key != ConsoleKey.Enter)
            {
                if (nextKey.Key == ConsoleKey.Backspace)
                {
                    if (password.Length > 0)
                    {
                        password.RemoveAt(password.Length - 1);
                        // erase the last * as well
                        Console.Write(nextKey.KeyChar);
                        Console.Write(" ");
                        Console.Write(nextKey.KeyChar);
                    }
                }
                else
                {
                    password.AppendChar(nextKey.KeyChar);
                    Console.Write("*");
                }
                nextKey = Console.ReadKey(true);
            }
            password.MakeReadOnly();
            cred.UserId = userId;
            cred.Password = password;
            return cred;
        }
        public static string GetclientIP()
        {
            string result = string.Empty;
            string hostName = Dns.GetHostName(); // Retrive the Name of HOST  
            result = Dns.GetHostAddresses(hostName)[1].ToString();
            return result;
        }
        public static void WriteToLog(string message, string onPremSiteUrl = "", string docLib = "", string onLineSiteUrl = "", string onPremValue = "", string onLineValue = "", string fieldTitle = "", string fieldInternalName = "", string category = "", string change = "")
        {


            try
            {
                string exepath = System.Reflection.Assembly.GetExecutingAssembly().Location;
                string exedir = System.IO.Path.GetDirectoryName(exepath);
                if (!System.IO.Directory.Exists(exedir + "\\Logging"))
                {
                    System.IO.Directory.CreateDirectory(exedir + "\\Logging");
                }
                if (!System.IO.Directory.Exists(exedir + "\\Logging\\" + DateTime.Today.ToString("yyyyMMdd")))
                {
                    System.IO.Directory.CreateDirectory(exedir + "\\Logging\\" + DateTime.Today.ToString("yyyyMMdd"));
                }
                exedir = exedir + "\\Logging\\" + DateTime.Today.ToString("yyyyMMdd") + "\\";

                string filePath = exedir + "log.csv";
                if (!System.IO.File.Exists(filePath))
                {
                    System.IO.File.Create(filePath).Close();
                    System.IO.File.AppendAllText(filePath, "OnPremUrl," + "DocLibName," + "OnlineUrl," + "FieldTitle," + "FieldIntrnalName," + "Category," + "OnPremFieldTypeValue," + "OnLineFieldTypeValue," + "Change," + "Message," + "Time," + "LoggedInUserID" + Environment.NewLine);
                }

                StringBuilder sb = new StringBuilder();
                if (message.Contains("Exception"))
                {
                    category = "Exception";
                }

                string prefix = onPremSiteUrl + "," + docLib.Replace(",", "") + "," + onLineSiteUrl + "," + fieldTitle.Replace(",", "") + "," + fieldInternalName + "," + category + "," + onPremValue + "," + onLineValue + "," + change + ",";
                string currentUserID = ",Time: " + DateTime.Now + ",LoggedIn UserId: " + System.Environment.UserDomainName + "\\" + System.Environment.UserName;

                sb.AppendLine(prefix + message.Replace(",", "") + currentUserID);
                System.IO.File.AppendAllText(filePath, sb.ToString());
            }
            catch (Exception ex)
            {

            }
        }
    }

    public class Migrate
    {
        public string Source { get; set; }
        public string Destination { get; set; }

        public string DocLibrary { get; set; }
    }
    public class Credential
    {
        public string UserId { get; set; }
        public SecureString Password { get; set; }


    }
}
