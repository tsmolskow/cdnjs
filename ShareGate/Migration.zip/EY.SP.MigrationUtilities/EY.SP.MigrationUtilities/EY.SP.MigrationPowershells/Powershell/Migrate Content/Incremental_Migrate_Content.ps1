﻿$dt = Get-Date 
$mth = $dt.Month
if($mth -eq 1 -or $mth -eq 2 -or $mth -eq 3 -or $mth -eq 4 -or $mth -eq  5 -or $mth -eq 6 -or $mth -eq 7 -or $mth -eq 8 -or $mth -eq 9)
{
$mth = "0"+$mth;
}
$dte = $dt.Day.ToString()+ '_' + $mth.ToString() + '_' + $dt.Year.ToString() +'_'+ $dt.Hour.ToString() + '_' + $dt.Minute.ToString() + '_' + $dt.Second.ToString();

$trPath = "C:\SharegateMigrationReports\Step3\Output\Batch3_Wave2\Set3\Incremental\MigrationLog_" + $dte + ".txt"
$timeStamp = "C:\SharegateMigrationReports\Step3\Output\Batch3_Wave2\Set3\Incremental\MigrationTimeLog_" + $dte + ".csv"
New-Item -Path $timeStamp -ItemType file -Force
Add-Content -Path $timeStamp -Value "SiteURL,MigrationTime"

Start-Transcript $trPath
$startTime = Get-Date
Import-Module Sharegate
#Path of user mapping file to be used during sharegate migration
$mappings = Import-UserAndGroupMapping -Path "C:\SharegateMigrationReports\UserandGroupMappings.sgum"

$copysettings = New-CopySettings -OnContentItemExists IncrementalUpdate

#Path of site objects mapping file to be used during sharegate migration
$csvFile = "C:\SharegateMigrationReports\Step3\Incremental_SiteList_1.csv"
$table = Import-Csv $csvFile -Delimiter "^"

$srcCred = Get-Credential -Message "Credentials for Source Site.."

$dstCred = Get-Credential -Message "Credentials for Destination Site.."
$excludedlist = @(
    "Site Assets",
    "Engagement Library Status",
    "EngagementTools",
    "App Links",
    "Contacts",
    "Site Pages",
    "Web Part Gallery",
    "MicroFeed",
    "Style Library",
    "Master Page Gallery",
    "Form Templates",
    "appdata",
    "Composed Looks",
    "Content type publishing error log",
    "Converted Forms",
    "List Template Gallery",
    "Search Config List",
    "Solution Gallery",
    "TaxonomyHiddenList",
    "Theme Gallery",
    "Search Config List",
    "wfpub",
    "Workflows"
    )

$srcSiteAddress = "";
$result = "";

Set-Variable dstSite, dstList
$indx = 1;
$ttl = $table.Length

foreach ($row in $table) {
    $ListTitle = $row.Title
    if($excludedlist.Contains($ListTitle) -or $ListTitle -like "*_Tools*")
        {
            Write-Host "Executing Row Number: $indx of total: $ttl" -BackgroundColor Green
            $indx++;
            Write-Host $ListTitle " is excluded from migration process" -BackgroundColor Magenta
 
        }
    else
        {
            Write-Host "Executing Row Number: $indx of total: $ttl" -BackgroundColor Green
            $indx++;

            if($srcSiteAddress -eq $row.SiteAddress){
            
            #Get list from the previous source site object
            $srcList = Get-List -Site $srcSite -name $ListTitle
            #Get list from the previous source site object                                    
            $dstList = Get-List -Name $ListTitle -Site $dstSite
          
            Write-Host "Copying Content Incrementally.." -BackgroundColor DarkYellow
            Copy-Content -SourceList $srcList -DestinationList $dstList -InsaneMode -CopySettings $copysettings
            
            $msg = "Incremental Migration completed for List: " + $ListTitle;
            Write-Host $msg -BackgroundColor Green
            
            
            }
            
        else
            {
            $nowTime = Get-Date
            if($srcSiteAddress -ne "")
            {
                $tdiff = $nowTime - $prevTime
                $stamp = $srcSiteAddress + "," + $tdiff
                Add-Content -Path $timeStamp -Value $stamp
            }

            #Get Source site address from CSV
            $srcSiteAddress = $row.SiteAddress
            $srcSite = $null
            $dstSite = $null
            #Get source site from URL if it is unique
            $srcSite = Connect-Site -Url $srcSiteAddress -Username $srcCred.UserName -Password $srcCred.Password
                        
            #Desitnation site address
            $destinationSite = $row.DestinationAddress
            $dstSite = Connect-Site -Url $destinationSite -Username $dstCred.UserName -Password $dstCred.Password 
                        
            $prevTime = Get-Date

            $srcList = Get-List -Site $srcSite -name $ListTitle
            $dstList = Get-List -Name $ListTitle -Site $dstSite

            $msg2 = "Incremental Migration started for List " + $ListTitle + " - Site URL: " + $srcSiteAddress
            Write-Host $msg2 -BackgroundColor Magenta
            
            Write-Host "Copying Content.." -BackgroundColor DarkYellow
            Copy-Content -SourceList $srcList -DestinationList $dstList -InsaneMode -CopySettings $copysettings
            
            $msg = "Incremental Migration completed for List: " + $ListTitle;
            Write-Host $msg -BackgroundColor Green
            
            
            }
            
        }

    
}
 
$endTime = Get-Date
$tdiff = $endTime - $prevTime
$stamp = $srcSiteAddress + "," + $tdiff
Add-Content -Path $timeStamp -Value $stamp
$runtime = $endTime - $startTime

$totalTime = "Total Execution Time," + $runtime
Write-Host $totalTime
Add-Content -Path $timeStamp -Value $totalTime
Stop-Transcript