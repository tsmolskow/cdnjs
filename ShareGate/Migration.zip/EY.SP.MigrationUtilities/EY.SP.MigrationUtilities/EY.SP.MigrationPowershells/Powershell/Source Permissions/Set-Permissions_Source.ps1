#--------------------------------------------------------------------------------------------------
# Load SharePoint PowerShell cmdlets, if missing.
#--------------------------------------------------------------------------------------------------
if (!(Get-PsSnapin | Where-Object {$_.Name -match "Microsoft.SharePoint.PowerShell"}))
{Add-PsSnapin Microsoft.SharePoint.PowerShell}


function FixPerms {

Param (
[Parameter(Mandatory = $True)] $web,
[Parameter(Mandatory = $True)] $permissions,
[Parameter(Mandatory = $True)] $logFilePath)

    Try{
    
    $ContriRole = $web.RoleDefinitions[�Contribute�]
    $ReadRole = $web.RoleDefinitions[�Read�]
    $RnPRole = $web.RoleDefinitions[�Read and Personalize"]
    $ViewRole = $web.RoleDefinitions[�View Only"]
    
    foreach ($assignment in $permissions) {
        
        if($assignment.RoleDefinitionBindings.Contains($ReadRole) -or $assignment.RoleDefinitionBindings.Contains($RnPRole) -or $assignment.RoleDefinitionBindings.Contains($ViewRole))
        {
            $temp = "Skipping this one since it is a Read Role : " + $assignment.Member.Name;
            Add-Content -Path $logFilePath -Value $temp
        }
        else{
            
            $assignment.RoleDefinitionBindings.RemoveAll()    
            $assignment.RoleDefinitionBindings.Add($ContriRole);
            $assignment.Update()        
        }
        
    }   
    Add-Content -Path $logFilePath -Value "Fixed permissions"
    Add-Content -Path $logFilePath -Value "=================================="
    }

    Catch{
        Add-Content -Path $logFilePath -Value $_.Exception
    }
}

Function Remove-LibraryPermissions{

Param (
[Parameter(Mandatory = $True)] $web,
[Parameter(Mandatory = $True)] [string]$logFilePath)

        Try{
        foreach ($lib in $web.lists) {
    
            Add-Content -Path $logFilePath -Value "Checking list/library: $lib"
    
            #check list/library permissions
            if ($lib.HasUniqueRoleAssignments -eq "True") {
                Add-Content -Path $logFilePath -Value "Need to fix library perms: $lib"
                $permissions = $lib.RoleAssignments;
                FixPerms -permissions $permissions -web $web -logFilePath $logFilePath;
            }
           Add-Content -Path $logFilePath -Value "`================"
        }
            }

        Catch{
            Add-Content -Path $logFilePath -Value $_.Exception
        }
}

Function Remove-WebPermissions{

Param (
[Parameter(Mandatory = $True)] $web,
[Parameter(Mandatory = $True)] [string]$logFilePath)
    
        Try{
        
        Add-Content -Path $logFilePath -Value "Checking for Web: $web"
        $groups = $web.SiteGroups;
        foreach($group in $groups)
        {
            $permissions = $group.ParentWeb.RoleAssignments;
            FixPerms -permissions $permissions -web $web -logFilePath $logFilePath;
        }
        
        Add-Content -Path $logFilePath -Value "`================"}

        Catch{
         Add-Content -Path $logFilePath -Value $_.Exception
        }
}

Function Remove-SourcePermissions{

Param (
[Parameter(Mandatory = $True)] [string]$SiteURL,
[Parameter(Mandatory = $True)] [string]$logFilePath)

    Try{
    
    $site = Get-SPSite $SiteURL

    foreach($web in  $site.AllWebs )
    {

         Remove-WebPermissions -web $web -logFilePath $logFilePath
         Remove-LibraryPermissions -web $web -logFilePath $logFilePath
    }
    }

    Catch{
         Add-Content -Path $logFilePath -Value $_.Exception
    }

}

Function Get-CSV{
    
    Param (
    [Parameter(Mandatory = $True)] [string]$CSVLocation)
        
        $csv = Import-CSV -Path $CSVLocation

        $SC = ($csv | Where-Object -Property Type -Like 'Site Collection').URL | Select-Object -unique
        
        $SC | ForEach-Object{
             $fileName = $_.Split('/')[4]
             $filepath = ".\"+$fileName+".txt"
  
            if(Test-Path $filepath){
                $fileName = $fileName + "_1"
                $filepath = ".\"+$fileName+".txt"
            }            

            New-Item -Path $filepath -ItemType file -Force
            Remove-SourcePermissions -SiteURL $_ -logFilePath $filepath

        }

}

Get-CSV