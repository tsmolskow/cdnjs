console.log("Executing custom action"); if ("undefined" != typeof g_MinimalDownload && g_MinimalDownload && (window.location.pathname.toLowerCase()).endsWith("/_layouts/15/start.aspx") && "undefined" != typeof asyncDeltaManager) {
														 // Register script for MDS if possible
														 RegisterModuleInit("banner.js", RemoteManager_Inject); //MDS registration
														 RemoteManager_Inject(); //non MDS run
													 } else {
														 RemoteManager_Inject();
													 }

                function RemoteManager_Inject() {
                    console.log("calling RemoteManager_Inject");
                    //if (IsOnPage("/sitepages/", ".aspx")) {
                    console.log("calling sitespages");
                        
                        SP.SOD.executeOrDelayUntilScriptLoaded(function () { 
                            ReadPropertyBag();
                            },'sp.js');
                   // }
                }

                function insertElement(id, destUrl, migrationDate, bannerColor,rootSite,callback)
                {
                    var poops = setInterval(function(){
                            if(document.getElementById(id)){
                                var elt = document.getElementById(id);
                                console.log("Div found");
                                
                                var date = migrationDate;
                                
                                var newDiv = document.createElement("div");
                                
                                var informationLink = "https://sites.ey.com/sites/EYOSEnablement/SitePages/CanadaInfo.aspx";
                                if (rootSite) {
                                    if (bannerColor == "RED") {
                                        var message = '<span><img class="iconClassRed" src="/sites/cdn/SiteAssets/BannerIcons/warning-icon.png"></img></span>';
                                        message += '<span style="vertical-align: top;">This site is in the process of being migrated to the EYI - My Documents Cloud platform. Please, do not make any content or structural changes until you are contacted by your site administrators.</span>';

                                        newDiv.className = "redBg";
                                    }
                                    else {
                                        if (bannerColor == "ORANGE") {
                                            var message = '<span><img class="iconClass" src="/sites/cdn/SiteAssets/BannerIcons/information-icon.png"></img></span>';
                                            message += '<span style="vertical-align: top;">This site will be migrated on ' + date + ' to the EYI - My Documents Cloud platform. <a target="_blank" data-interception="off" rel="noopener noreferrer" href="' + informationLink + '">More Information</a> </span>';

                                            newDiv.className = "orangeBg";

                                        }
                                        else if (bannerColor == "YELLOW") {
                                            var message = '<span><img class="iconClass" src="/sites/cdn/SiteAssets/BannerIcons/information-icon.png"></img></span>';
                                            message += '<span style="vertical-align: top;">This site will be migrated on ' + date + ' to the EYI - My Documents Cloud platform. <a target="_blank" data-interception="off" rel="noopener noreferrer" href="' + informationLink + '">More Information</a> </span>';

                                            newDiv.className = "yellowBg";

                                        }
                                        else {
                                            var message = '<span><img class="iconClass" src="/sites/cdn/SiteAssets/BannerIcons/information-icon.png"></img></span>';
                                            message += '<span style="vertical-align: top;">This site has been migrated to the EYI - My Documents Cloud platform and has passed initial testing. <a target="_blank" data-interception="off" rel="noopener noreferrer" href="' + destUrl + '">Explore your newly migrated site.</a></span>';

                                            newDiv.className = "grayBg";
                                        }

                                    }
                                }
                                else {
                                    if (bannerColor == "RED") {
                                        var message = '<span><img class="iconClassRedSub" src="/sites/cdn/SiteAssets/BannerIcons/warning-icon.png"></img></span>';
                                        message += '<span style="vertical-align: top; padding-left: 8px;">This site is in the process of being migrated to the EYI - My Documents Cloud platform. Please, do not make any content or structural changes until you are contacted by your site administrators.</span>';

                                        newDiv.className = "redBgSub";
                                    }
                                    else {
                                        if (bannerColor == "ORANGE") {
                                            var message = '<span><img class="iconClassSub" src="/sites/cdn/SiteAssets/BannerIcons/information-icon.png"></img></span>';
                                            message += '<span style="vertical-align: top; padding-left: 8px;">This site will be migrated on ' + date + ' to the EYI - My Documents Cloud platform. <a target="_blank" data-interception="off" rel="noopener noreferrer" href="' + informationLink + '">More Information</a> </span>';

                                            newDiv.className = "orangeBgSub";

                                        }
                                        else if (bannerColor == "YELLOW") {
                                            var message = '<span><img class="iconClassSub" src="/sites/cdn/SiteAssets/BannerIcons/information-icon.png"></img></span>';
                                            message += '<span style="vertical-align: top; padding-left: 8px;">This site will be migrated on ' + date + ' to the EYI - My Documents Cloud platform. <a target="_blank" data-interception="off" rel="noopener noreferrer" href="' + informationLink + '">More Information</a> </span>';

                                            newDiv.className = "yellowBgSub";

                                        }
                                        else {
                                            var message = '<span><img class="iconClassSub" src="/sites/cdn/SiteAssets/BannerIcons/information-icon.png"></img></span>';
                                            message += '<span style="vertical-align: top; padding-left: 8px;">This site has been migrated to the EYI - My Documents Cloud platform and has passed initial testing. <a target="_blank" data-interception="off" rel="noopener noreferrer" href="' + destUrl + '">Explore your newly migrated site.</a></span>';

                                            newDiv.className = "grayBgSub";
                                        }

                                    }
                                }
                                newDiv.innerHTML = message;
                                elt.insertBefore(newDiv, elt.firstChild);
                                
                                clearInterval(poops);
                                callback();
                            }
                        }, 100);


                }

                function ReadPropertyBag() {  
                  //Get Client Context and Web object.  
                  clientContext= new SP.ClientContext.get_current();  
                  var oWeb= clientContext.get_web();  
                    
                  //Get property bag collection  
                  oPropBag= oWeb.get_allProperties();  
                    clientContext.load(oWeb);
                  //Load client context and execute the batch  
                  clientContext.load(oPropBag);  
                    //clientContext.executeQueryAsync(Success,Failure);  
                    clientContext.executeQueryAsync(function(){ Success(clientContext.get_url()); }, Failure);  
               }  

               function Success(url){
                  try
                  {
                      console.log("Property Bag Value - " + oPropBag.get_fieldValues()["DestUrl"]);
                      var rootSite = true;
                      var destUrl = oPropBag.get_fieldValues()["DestinationUrl"];
                      var migrationDate = oPropBag.get_fieldValues()["MigrationDate"];
                      var bannerColor = oPropBag.get_fieldValues()["BannerColor"];
                      console.log("Excecution working");
                      console.log(url);
                      if (url.split("/").length>3) {
                          rootSite = false;
                      }
                      
                      if(typeof(destUrl) !== 'undefined' && destUrl !== "" && typeof(migrationDate) !== 'undefined' && migrationDate !== "")
                      {
                      insertElement("s4-bodyContainer",destUrl,migrationDate,bannerColor,rootSite,function(){
                                console.log("s4-bodyContainer is loaded..");});
                      }
                  }
                 catch(ex)
                 {
                      console.log("Error occured while fetching Property Bag value");
                      console.log(ex.message);  
                 }

               }  

               function Failure(sender, args) {  
                  console.log("Request failed. " + args.get_message() + "\n" + args.get_stackTrace());  
               } 

            function IsOnPage(path, pageName) {
                    console.log("calling IsOnPage");
                    if (window.location.href.toLowerCase().indexOf(path.toLowerCase()) > -1 && 
                        window.location.href.toLowerCase().indexOf(pageName.toLowerCase()) > -1 &&
                        window.location.href.toLowerCase().indexOf("/forms/") == -1) {
                        return true;
                    } else {
                        return false;
                    }
                }