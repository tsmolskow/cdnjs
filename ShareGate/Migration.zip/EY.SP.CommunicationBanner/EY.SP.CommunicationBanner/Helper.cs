﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Client.UserProfiles;
using Microsoft.SharePoint.Client.Workflow;
using File = Microsoft.SharePoint.Client.File;

namespace EY.SP.CommunicationBanner
{
    class Helper
    {
        public static void AddPropertyBag(ClientContext context, string destinationUrl, string migrationDate, string bannerColor)
        {

            try
            {
                Web oWebsite = context.Web;
                context.Load(oWebsite);
                context.ExecuteQuery();
                Console.WriteLine("Adding PropertyBag for site: {0}", oWebsite.Url);
                WriteToLog("Adding PropertyBag for site: " + oWebsite.Url);
                PropertyValues props = oWebsite.AllProperties;

                if (!props.IsPropertyAvailable("DestinationUrl"))
                {
                    props["DestinationUrl"] = destinationUrl.Trim();
                    oWebsite.Update();
                    context.ExecuteQuery();
                    Console.WriteLine("Property value 'DestinationUrl' added for site: {0}", oWebsite.Url);
                    WriteToLog("Property value 'DestinationUrl' added for site: " + oWebsite.Url);
                }
                if (!props.IsPropertyAvailable("MigrationDate"))
                {
                    props["MigrationDate"] = migrationDate.Trim();
                    oWebsite.Update();
                    context.ExecuteQuery();
                    Console.WriteLine("Property value 'MigrationDate' added for site: {0}", oWebsite.Url);
                    WriteToLog("Property value 'MigrationDate' added for site: " + oWebsite.Url);
                }
                if (!props.IsPropertyAvailable("MigrationDate"))
                {
                    props["BannerColor"] = bannerColor.Trim();
                    oWebsite.Update();
                    context.ExecuteQuery();
                    Console.WriteLine("Property value 'BannerColor' added for site: {0}", oWebsite.Url);
                    WriteToLog("Property value 'BannerColor' added for site: " + oWebsite.Url);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception occured while adding Property Bag: {0}", ex.Message);
                WriteToLog(ex.Message);
                WriteToLog(ex.StackTrace);
            }
        }

        public static void RemovePropertyBag(ClientContext context)
        {

            try
            {
                Web oWebsite = context.Web;
                context.Load(oWebsite);
                context.ExecuteQuery();
                Console.WriteLine("Removing PropertyBag for site: {0}", oWebsite.Url);
                WriteToLog("Removing PropertyBag for site: " + oWebsite.Url);
                PropertyValues props = oWebsite.AllProperties;


                props["DestinationUrl"] = null;
                oWebsite.Update();
                context.ExecuteQuery();
                Console.WriteLine("Property value 'DestinationUrl' removed for site: {0}", oWebsite.Url);
                WriteToLog("Property value 'DestinationUrl' removed for site: " + oWebsite.Url);

                props["MigrationDate"] = null;
                oWebsite.Update();
                context.ExecuteQuery();
                Console.WriteLine("Property value 'MigrationDate' removed for site: {0}", oWebsite.Url);
                WriteToLog("Property value 'MigrationDate' removed for site: " + oWebsite.Url);

                props["BannerColor"] = null;
                oWebsite.Update();
                context.ExecuteQuery();
                Console.WriteLine("Property value 'BannerColor' removed for site: {0}", oWebsite.Url);
                WriteToLog("Property value 'BannerColor' removed for site: " + oWebsite.Url);

            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception occured while removing Property Bag due to Property may not exist: {0}", ex.Message);
                WriteToLog(ex.Message);
                WriteToLog(ex.StackTrace);
            }

        }
        public static void DisplayPropertyBag(ClientContext context)
        {
            try
            {
                Web oWebsite = context.Web;
                context.Load(oWebsite);
                context.ExecuteQuery();
                Console.WriteLine("Displaying PropertyBag for site: {0}", oWebsite.Url);
                WriteToLog("Displaying PropertyBag for site: " + oWebsite.Url);
                PropertyValues props = oWebsite.AllProperties;
                context.Load(props);
                context.ExecuteQuery();
                Console.WriteLine("Site Url is: {0}", oWebsite.Url);
                WriteToLog("Site Url is: " + oWebsite.Url);
                Console.WriteLine("DestinationUrl Property value for above site is : {0}", props["DestinationUrl"]);
                WriteToLog("DestinationUrl Property value for above site is : " + props["DestinationUrl"]);
                Console.WriteLine("MigrationDate Property value for above site is : {0}", props["MigrationDate"]);
                WriteToLog("MigrationDate Property value for above site is : " + props["MigrationDate"]);
                Console.WriteLine("BannerColor Property value for above site is : {0}", props["BannerColor"]);
                WriteToLog("BannerColor Property value for above site is : " + props["BannerColor"]);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception occured while displaying Property Bag value due to Property may not exist: {0}", ex.Message);
                WriteToLog(ex.Message);
                WriteToLog(ex.StackTrace);
            }

        }

        public static void AddSiteLevelCustomActions(ClientContext clientContext)
        {
            string js = @"$(document).ready(function(){$(""<script/>"",
                                {type:""text/javascript"", src: window.location.protocol+""//""+window.location.hostname+""/sites/cdn/SiteAssets/BannerUserCustomAction.js""}).
                            appendTo(""head"");
                            $(""<link/>"",
                                {rel:""stylesheet"",type:""text/css"", href: window.location.protocol+""//""+window.location.hostname+""/sites/cdn/SiteAssets/BannerStyleSheet.css""}).
                            appendTo(""head"");
                                });";
            Microsoft.SharePoint.Client.UserCustomActionCollection collUserCustomAction = clientContext.Site.UserCustomActions;
            UserCustomAction newcustomaAction = collUserCustomAction.Add();
            newcustomaAction.Location = "ScriptLink";
            newcustomaAction.Sequence = 3112;
            newcustomaAction.Name = "BannerJS";
            newcustomaAction.Description = "Banner msg added to top";
            newcustomaAction.ScriptBlock = js;
            newcustomaAction.Update();
            clientContext.ExecuteQuery();
            Console.WriteLine("Custom action added");
            WriteToLog("Custom action added for site: " + clientContext.Url);
            Console.WriteLine("Title: {0}, Location: {1}, Sequence :{2}", newcustomaAction.Name, newcustomaAction.Location, newcustomaAction.Sequence);
        }
        public static void ListSiteLevelCustomActions(ClientContext clientContext)
        {
            var siteCustomActions = clientContext.Site.UserCustomActions;
            clientContext.Load(siteCustomActions);
            clientContext.ExecuteQuery();
            Console.WriteLine("Listing custom actions:");
            foreach (var customAction in siteCustomActions)
            {
                Console.WriteLine("Name: {0}, Location: {1}, Sequence :{2}", customAction.Name, customAction.Location, customAction.Sequence);
            }
        }

        public static void RemoveSiteLevelCustomActions(ClientContext clientContext, String customActionName)
        {
            Helper.LogInfoMessage("Removing custom action started");
            WriteToLog("Removing custom action started for site: " + clientContext.Url);
            var siteCustomActions = clientContext.Site.UserCustomActions;
            clientContext.Load(siteCustomActions);
            clientContext.ExecuteQuery();

            UserCustomAction customActionToDelete = null;
            foreach (var customAction in siteCustomActions)
            {
                Console.WriteLine("Listing custom actions:");
                Console.WriteLine("Name: {0}, Location: {1}, Sequence: {2}", customAction.Name, customAction.Location, customAction.Sequence);
                if (customAction.Name.Equals(customActionName))
                {
                    customActionToDelete = customAction;
                    break;
                }
            }
            if (customActionToDelete != null)
            {
                customActionToDelete.DeleteObject();
                clientContext.ExecuteQuery();
                Helper.LogInfoMessage("Custom action removed");
                WriteToLog("Custom action removed for site: " + clientContext.Url);
            }
        }

        #region SharePoint Context Functions

        private static SecureString ConvertToSecureString(string password)
        {
            if (password == null)
                throw new ArgumentNullException("password");

            var securePassword = new SecureString();

            foreach (char c in password)
                securePassword.AppendChar(c);

            securePassword.MakeReadOnly();
            return securePassword;
        }


        public static ClientContext GetClientContext(string siteURL, Credential cred, bool isSPO = false)
        {
            try
            {
                var context = new ClientContext(GetSafeURL(siteURL));


                context.ExecutingWebRequest += Ctx_ExecutingWebRequest;
                System.Net.NetworkCredential SrcCredential = new System.Net.NetworkCredential(cred.UserId, cred.Password);
                context.Credentials = SrcCredential;
                context.RequestTimeout = -1;
                context.PendingRequest.RequestExecutor.RequestKeepAlive = true;
                context.PendingRequest.RequestExecutor.WebRequest.KeepAlive = false;
                context.PendingRequest.RequestExecutor.WebRequest.Timeout = -1;
                context.PendingRequest.RequestExecutor.WebRequest.ReadWriteTimeout = -1;
                return context;
            }
            catch (Exception ex)
            {
                LogErrorMessage("Error occured in GetClientContext. Error details- " + ex.Message);
                WriteToLog("Error occured in GetClientContext method. Error details- " + ex.Message);
                return null;
            }
        }

        private static void Ctx_ExecutingWebRequest(object sender, WebRequestEventArgs e)
        {
            if (e != null)
            {
                e.WebRequestExecutor.WebRequest.Headers.Add("X-FORMS_BASED_AUTH_ACCEPTED", "f");
            }
        }

        public static ClientContext CheckIfSiteExistsAndGetContext(string siteURL, Credential cred, bool isSPO = false)
        {
            ClientContext context = GetClientContext(GetSafeURL(siteURL), cred, isSPO);
            try
            {
                Web oWebsite = context.Web;
                context.Load(oWebsite);
                context.ExecuteQuery();
                if (oWebsite != null)
                {
                    LogInfoMessage(siteURL + " exists.");
                    return context;
                }
                else
                    return null;

            }
            catch (Exception ex)
            {
                LogErrorMessage(siteURL + " doesn't exists.");
                LogErrorMessage("Exception : " + ex.Message);
                LogErrorMessage("Stack Trace : " + ex.StackTrace);
                return null;
            }
        }

        /// <summary>
        /// Removes last index of '/' to get the safe url object
        /// </summary>
        /// <param name="url">e.g. http://www.ey.com</param>
        /// <returns></returns>
        public static string GetSafeURL(string url)
        {
            if (url.Trim().EndsWith("/"))
                return url.TrimEnd('/');
            else
                return url;
        }

        /// <summary>
        /// Returns url of root web
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public static string GetRootWebURL(string url)
        {
            url = url.ToLower();
            return url.Split(new string[] { "/sites" }, StringSplitOptions.None)[0];
        }
        #endregion

        #region Logger Methods

        /// <summary>
        /// Add success message
        /// </summary>
        /// <param name="message"></param>
        public static void LogSuccsessMessage(string message)
        {
            Console.Write("\r\n");
            Console.ForegroundColor = Common.colSuccess;
            Console.WriteLine(message);
            Console.ResetColor();
            Logger.LogInformation(message);
        }

        /// <summary>
        /// Add error message
        /// </summary>
        /// <param name="message"></param>
        public static void LogErrorMessage(string message)
        {
            Console.Write("\r\n");
            Console.ForegroundColor = Common.colError;
            Console.WriteLine(message);
            Console.ResetColor();
            Logger.LogError(message);
        }

        /// <summary>
        /// Add info messsage
        /// </summary>
        /// <param name="message"></param>
        public static void LogInfoMessage(string message)
        {
            Console.Write("\r\n");
            Console.ForegroundColor = Common.colInfo;
            Console.WriteLine(message);
            Console.ResetColor();
            Logger.LogInformation(message);
        }

        /// <summary>
        /// Add warning messsage
        /// </summary>
        /// <param name="message"></param>
        public static void LogWarningMessage(string message)
        {
            Console.Write("\r\n");
            Console.ForegroundColor = Common.colWarning;
            Console.WriteLine(message);
            Console.ResetColor();
            Logger.LogInformation(message);
        }
        #endregion

        public static void WriteToFile(StringBuilder prgLog, string filepath)
        {
            try
            {
                System.IO.Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + "/Reports");

                System.IO.File.AppendAllText(filepath, prgLog.ToString());
            }
            catch (Exception ex)
            {
                LogErrorMessage("Error occured in WriteToFile. Error details- " + ex.Message);
                LogErrorMessage(ex.StackTrace);

            }
        }

        public static void WriteToLog(string message)
        {
            //common funtion which is used to write the output in to CSV file.
            try
            {
                string exepath = System.Reflection.Assembly.GetExecutingAssembly().Location;
                string exedir = System.IO.Path.GetDirectoryName(exepath);
                if (!System.IO.Directory.Exists(exedir + "\\Logging"))
                {
                    System.IO.Directory.CreateDirectory(exedir + "\\Logging");
                }
                if (!System.IO.Directory.Exists(exedir + "\\Logging\\" + DateTime.Today.ToString("yyyyMMdd")))
                {
                    System.IO.Directory.CreateDirectory(exedir + "\\Logging\\" + DateTime.Today.ToString("yyyyMMdd"));
                }
                exedir = exedir + "\\Logging\\" + DateTime.Today.ToString("yyyyMMdd") + "\\";

                string filePath = exedir + "log.txt";

                if (!System.IO.File.Exists(filePath))
                {
                    System.IO.File.Create(filePath).Close();
                }
                //When we write any output report the delimeter will be power symbel(^) separated.
                StringBuilder sb = new StringBuilder();
                string currentUserID = ",Time: " + DateTime.Now + ",LoggedIn UserId: " + System.Environment.UserDomainName + "\\" + System.Environment.UserName;
                sb.AppendLine(message + currentUserID);
                System.IO.File.AppendAllText(filePath, sb.ToString());
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception occured while writing Logs, Message: " + ex.Message);
            }
        }


    }
}
