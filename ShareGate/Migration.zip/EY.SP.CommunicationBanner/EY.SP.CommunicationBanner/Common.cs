﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EY.SP.CommunicationBanner
{
    public static class Common
    {
        public const string SRC_USERNAME = "SRC_USERNAME";
        public const string SRC_PASSWORD = "SRC_PASSWORD";

        public const string DEST_USERNAME = "DEST_USERNAME";
        public const string DEST_PASSWORD = "DEST_PASSWORD";

        public static string CSV_FILE_PATH = AppDomain.CurrentDomain.BaseDirectory + "/inputFile.csv";

        private static string REPORTS_FOLDER = "/Reports";

        public static string LIST_ITEMS_COUNT_AUDIT_REPORT_CSV_FILE = AppDomain.CurrentDomain.BaseDirectory + REPORTS_FOLDER + "/ListItemCountAuditReport_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".csv";

        public const ConsoleColor colInfo = ConsoleColor.White;
        public const ConsoleColor colSuccess = ConsoleColor.Green;
        public const ConsoleColor colError = ConsoleColor.Red;
        public const ConsoleColor colWarning = ConsoleColor.Yellow;

        public static StringBuilder prgLog = new StringBuilder();
    }

    public class Migrate
    {
        public string Source { get; set; }
        public string Destination { get; set; }

        public string MigrationDate { get; set; }

        public string BannerColor { get; set; }
    }

    public static class ReportConfig
    {
        public static Config config { get; set; }
    }

    public class Config
    {
        public string BannerJs { get; set; }
        public string PreMigrateBannerJSLink { get; set; }
        public string MigrateBannerLink { get; set; }
        public string BannerDiscription { get; set; }
        
    }

    
}
