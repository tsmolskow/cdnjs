﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EY.SP.CommunicationBanner
{
    public static class Logger
    {
        private static log4net.ILog Log { get; set; }

        static Logger()
        {
            Log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        }

        public static void LogError(string msg)
        {
            Log.Error(msg);
        }

        public static void LogError(Exception ex, string msg)
        {
            Log.Error(msg, ex);
        }

        public static void LogError(Exception ex)
        {
            Log.Error(ex.Message, ex);
        }

        public static void LogInformation(string msg)
        {
            Log.Info(msg);
        }

        public static void LogWarning(string msg)
        {
            Log.Warn(msg);
        }
    }
}
