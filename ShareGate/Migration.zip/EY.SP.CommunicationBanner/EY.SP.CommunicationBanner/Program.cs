﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using Microsoft.SharePoint.Client;
using System.Security;

namespace EY.SP.CommunicationBanner
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Helper.LogInfoMessage("Execution Started.");
                Helper.WriteToLog("Execution Started.");
                var allUrls = ReadCSV();

                LoadConfig();
                Credential cred = GetCredential();


                Helper.LogInfoMessage("Batch Urls Count : " + allUrls.Count);
                Helper.WriteToLog("Batch Urls Count : " + allUrls.Count);
                if (allUrls.Count > 0)
                {
                    Console.WriteLine("Please Enter option to invoke operation : ");
                    Console.WriteLine("1 --> List site level custom actions");
                    Console.WriteLine("2 --> Add site level custom action");
                    Console.WriteLine("3 --> Remove site level custom action");
                    Console.WriteLine("4 --> Add Property Bag Values");
                    Console.WriteLine("5 --> Display Property Bag values");
                    Console.WriteLine("6 --> Remove Property Bag values");

                    var choice = Console.ReadLine();

                    switch (choice)
                    {
                        case "1":
                            ListSiteLevelCustomActions(allUrls, cred);
                            break;
                        case "2":
                            AddSiteLevelCustomActions(allUrls, cred);
                            break;
                        case "3":
                            RemoveSiteLevelCustomActions(allUrls, cred);
                            break;
                        case "4":
                            AddPropertyBagValues(allUrls, cred);
                            break;
                        case "5":
                            DisplayPropertyBagValues(allUrls,cred);
                            break;
                        case "6":
                            RemovePropertyBagValues(allUrls, cred);
                            break;
                    }
                }
                else
                {
                    Helper.LogWarningMessage("No Urls in batch.");
                    Helper.WriteToLog("No Urls in batch.");
                }

            }
            catch (Exception ex)
            {
                Helper.LogErrorMessage(ex.Message);
                Helper.WriteToLog(ex.Message);
                Helper.LogErrorMessage(ex.StackTrace);
                Helper.WriteToLog(ex.StackTrace);
            }
            finally
            {
                Helper.LogInfoMessage("Execution Completed.");
                Helper.WriteToLog("Execution Completed.");
                Console.WriteLine("Press any key to exit");
                Console.ReadLine();
            }
        }

        static void AddPropertyBagValues(List<Migrate> allUrls,Credential cred)
        {
            Helper.LogInfoMessage("-----------------------------------------------------------------------");
            Helper.LogInfoMessage("---------Adding PropertyBag Values-----------------");
            Helper.LogInfoMessage("-----------------------------------------------------------------------");


            foreach (var url in allUrls)
            {
                try
                {
                    var ctx = Helper.CheckIfSiteExistsAndGetContext(url.Source, cred);
                    if (null != ctx)
                    {
                        Helper.AddPropertyBag(ctx, url.Destination, url.MigrationDate,url.BannerColor);
                        ctx.Dispose();
                    }
                }
                catch (Exception ex)
                {
                    Helper.LogErrorMessage(ex.Message);
                    Helper.LogErrorMessage(ex.StackTrace);
                }
            }
        }
        static void DisplayPropertyBagValues(List<Migrate> allUrls,Credential cred)
        {
            Helper.LogInfoMessage("-----------------------------------------------------------------------");
            Helper.LogInfoMessage("---------Displaying PropertyBag Values-----------------");
            Helper.LogInfoMessage("-----------------------------------------------------------------------");


            foreach (var url in allUrls)
            {
                try
                {
                    //var ctx = Helper.CheckIfSiteExistsAndGetContext(url.Source);
                    var ctx = Helper.CheckIfSiteExistsAndGetContext(url.Source,cred);
                    if (null != ctx)
                    {
                        Helper.DisplayPropertyBag(ctx);
                        ctx.Dispose();
                    }
                }
                catch (Exception ex)
                {
                    Helper.LogErrorMessage(ex.Message);
                    Helper.LogErrorMessage(ex.StackTrace);
                }
            }
        }
        static void RemovePropertyBagValues(List<Migrate> allUrls, Credential cred)
        {
            Helper.LogInfoMessage("-----------------------------------------------------------------------");
            Helper.LogInfoMessage("---------Removing PropertyBag Values-----------------");
            Helper.LogInfoMessage("-----------------------------------------------------------------------");


            foreach (var url in allUrls)
            {
                try
                {
                    var ctx = Helper.CheckIfSiteExistsAndGetContext(url.Source,cred);
                    if (null != ctx)
                    {
                        Helper.RemovePropertyBag(ctx);
                        ctx.Dispose();
                    }
                }
                catch (Exception ex)
                {
                    Helper.LogErrorMessage(ex.Message);
                    Helper.LogErrorMessage(ex.StackTrace);
                }
            }
        }
        static void AddSiteLevelCustomActions(List<Migrate> allUrls, Credential cred)
        {
            Helper.LogInfoMessage("-----------------------------------------------------------------------");
            Helper.LogInfoMessage("---------Adding site level custom action-----------------");
            Helper.LogInfoMessage("-----------------------------------------------------------------------");


            foreach (var url in allUrls)
            {
                try
                {
                    var ctx = Helper.CheckIfSiteExistsAndGetContext(url.Source,cred);
                    if (null != ctx)
                    {
                        Helper.AddSiteLevelCustomActions(ctx);
                        ctx.Dispose();
                    }
                }
                catch (Exception ex)
                {
                    Helper.LogErrorMessage(ex.Message);
                    Helper.LogErrorMessage(ex.StackTrace);
                }
            }
        }

        static void ListSiteLevelCustomActions(List<Migrate> allUrls, Credential cred)
        {
            Helper.LogInfoMessage("-----------------------------------------------------------------------");
            Helper.LogInfoMessage("--------- List site level custom action-----------------");
            Helper.LogInfoMessage("-----------------------------------------------------------------------");


            foreach (var url in allUrls)
            {
                try
                {
                    var ctx = Helper.CheckIfSiteExistsAndGetContext(url.Source,cred);
                    if (null != ctx)
                    {
                        Helper.ListSiteLevelCustomActions(ctx);
                        ctx.Dispose();
                    }
                }
                catch (Exception ex)
                {
                    Helper.LogErrorMessage(ex.Message);
                    Helper.LogErrorMessage(ex.StackTrace);
                }
            }
        }
        static void RemoveSiteLevelCustomActions(List<Migrate> allUrls,Credential cred)
        {
            Helper.LogInfoMessage("-----------------------------------------------------------------------");
            Helper.LogInfoMessage("---------Remove Site Level Custom Actions-----------------");
            Helper.LogInfoMessage("-----------------------------------------------------------------------");


            foreach (var url in allUrls)
            {
                try
                {
                    var ctx = Helper.CheckIfSiteExistsAndGetContext(url.Source, cred);
                    if (null != ctx)
                    {
                        Helper.RemoveSiteLevelCustomActions(ctx, ReportConfig.config.BannerJs);
                        ctx.Dispose();
                    }
                }
                catch (Exception ex)
                {
                    Helper.LogErrorMessage(ex.Message);
                    Helper.LogErrorMessage(ex.StackTrace);
                }
            }
        }



        /// <summary>
        /// Read CSV file contents
        /// </summary>
        /// <returns></returns>
        public static List<Migrate> ReadCSV()
        {
            try
            {
                Helper.LogInfoMessage("CSV loading...");
                List<Migrate> migrateSiteUrls = new List<Migrate>();
                using (var reader = new StreamReader(Common.CSV_FILE_PATH))
                {
                    int i = 0;
                    while (!reader.EndOfStream)
                    {
                        var url = reader.ReadLine();
                        if (i > 0)
                        {
                            var splitInput = url.Split(',');
                            migrateSiteUrls.Add(new Migrate()
                            {
                                Source = splitInput[0],
                                Destination = splitInput[1],
                                MigrationDate = splitInput[2],
                                BannerColor = splitInput[3]
                            });
                        }
                        i++;
                    }
                }
                Helper.LogInfoMessage("CSV loaded successfully...");
                return migrateSiteUrls;
            }
            catch (Exception ex)
            {
                Helper.LogErrorMessage("Error occured in ReadCSV. Error details- " + ex.Message);
                return null;
            }
        }

        public static void LoadConfig()
        {
            try
            {
                Helper.LogInfoMessage("Loading Config file");

                ReportConfig.config = JsonConvert.DeserializeObject<Config>(System.IO.File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "/EYOS_TemplateArtefacts.json"));

                Helper.LogInfoMessage("Config File Loaded");
            }
            catch (Exception ex)
            {
                Helper.LogErrorMessage(ex.Message);
                Helper.LogErrorMessage(ex.StackTrace);
            }
        }

        public static Credential GetCredential()
        {
            Credential cred = new Credential();
            Console.WriteLine("Enter User ID: ");
            string userId = Console.ReadLine();
            SecureString password = new SecureString();
            Console.WriteLine("Enter password: ");

            ConsoleKeyInfo nextKey = Console.ReadKey(true);

            while (nextKey.Key != ConsoleKey.Enter)
            {
                if (nextKey.Key == ConsoleKey.Backspace)
                {
                    if (password.Length > 0)
                    {
                        password.RemoveAt(password.Length - 1);
                        Console.Write(nextKey.KeyChar);
                        Console.Write(" ");
                        Console.Write(nextKey.KeyChar);
                    }
                }
                else
                {
                    password.AppendChar(nextKey.KeyChar);
                    Console.Write("*");
                }
                nextKey = Console.ReadKey(true);
            }
            password.MakeReadOnly();
            cred.UserId = userId;
            cred.Password = password;
            return cred;
        }
    }

    public  class Credential
    {
        public string UserId { get; set; }
        public SecureString Password { get; set; }

        
    }
}
