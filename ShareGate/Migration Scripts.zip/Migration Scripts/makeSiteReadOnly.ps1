﻿
#EYTestAdmin@M365B742352.onmicrosoft.com
#EYTestAdmin1@M365x715372.onmicrosoft.com
#Cognizantadmin123!

cls

#Set Parameters
$AdminCenterURL="https://m365b742352-admin.sharepoint.com"
#$SiteURL = "https://m365b742352.sharepoint.com/MigrateSubsite"
$SiteURL = "https://m365b742352.sharepoint.com/sites/TestMigration0329"
#$SiteURL = "https://m365x715372.sharepoint.com/"
 
#Connect to SharePoint Online
Connect-SPOService -Url $AdminCenterURL -Credential (Get-Credential)
 
#PowerShell to set sharepoint online site to read only
#Set-SPOSite -Identity $SiteURL -LockState ReadOnly

#Unlock site from read only mode
Set-SPOSite -Identity $SiteURL -LockState Unlock