﻿# Set All SP On-Premise Lists Permissions
# spSetAllListsPermissions
# As of: 6/3/2021
# Developer: Tom Molskow, Cognizant

cls

Add-PSSnapin Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue

# File Output Path - Modify This Path Variable to Reflect the Local Environment
$ReportPath ="C:\Test\"

# CSV List Input File - Modify This Path Variable to Reflect the Local Environment
# !!!The 'spopPermissions.csv' File Must Exist Prior to Running!!!
$csvFile = "C:\Test\spopPermissions.csv" 

# Table Variable
$table = Import-Csv $csvFile -Delimiter ","

# ID,fk_site,fk_batch,TypeOfContent,SiteName,SourceURL,Inheritance,UserGroup,Principaltype,Accountname,ContentPermissions

    
try{

    foreach ($row in $table)
    {
    
    # Site Name
    $siteName = $row.SiteName
    Write-Host "Site Name: " $siteName 

    # Site URL
    $siteURL = $row.SourceURL 
    Write-Host "Site URL: " $siteURL

    # Site Inheritance
    $groupInherit = $row.Inheritance
    Write-Host "Inheritance: " $groupInherit

    # User Group
    $listGroup = $row.UserGroup
    Write-Host "User Group: " $listGroup

    # Account Name
    $accountName = $row.Accountname
    Write-Host "Account Name: " $accountName

    # Permissions
    $accountPermissions = ($row.ContentPermissions).Replace(";","")
    Write-Host "Permissions: " $accountPermissions

    Write-Host "---------------------------------"
            
    #$web = get-spweb $siteURL
    #$group = $web.SiteGroups["Owners"]
    #$ra = $group.ParentWeb.RoleAssignments.GetAssignmentByPrincipal($group)
    #$rd = $group.ParentWeb.RoleDefinitions[$accountPermissions]
    #$ra.RoleDefinitionBindings.Remove($rd)
    #$ra.Update()
    #$group.Update()
    #$web.Dispose()

    Write-Host "Permission Changed"
    Write-Host "---------------------------------"
       
    }
} catch {

    $ErrorMessage = $_.Exception.Message
    Write-Host "Error has occurred:" $ErrorMessage

}

