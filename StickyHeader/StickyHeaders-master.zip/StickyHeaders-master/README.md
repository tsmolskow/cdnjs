# StickyHeaders
Sticky headers for SharePoint lists and document libraries

<img alt="sticky Header Demo" src="http://spoodoo.com/wp-content/uploads/2016/03/stickyHeaderDemo3.gif">

Check http://spoodoo.com/products/stickyheaders-for-sharepoint/ for details!
